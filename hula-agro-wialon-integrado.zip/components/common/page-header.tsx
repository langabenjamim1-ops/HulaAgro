import { ReactNode } from 'react'

interface PageHeaderProps {
  title: string
  description?: string
  icon?: string
  badge?: string
  children?: ReactNode
}

function PageHeaderComponent({ title, description, icon, badge, children }: PageHeaderProps) {
  return (
    <div className="mb-12">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-4">
          {icon && <span className="text-5xl">{icon}</span>}
          <div>
            <div className="flex items-center gap-2 mb-2">
              <h1 className="text-4xl font-bold text-slate-900">{title}</h1>
              {badge && (
                <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-semibold">
                  {badge}
                </span>
              )}
            </div>
            {description && <p className="text-lg text-slate-600 max-w-2xl">{description}</p>}
          </div>
        </div>
      </div>
      {children}
    </div>
  )
}

export { PageHeaderComponent as PageHeader }
export default PageHeaderComponent
