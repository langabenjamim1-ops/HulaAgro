'use client'

import { Edit2, Trash2, ChevronRight } from 'lucide-react'
import Link from 'next/link'

interface Column {
  key: string
  label: string
  render?: (value: any, row: any) => React.ReactNode
}

interface CRUDTableProps {
  columns: Column[]
  data: any[]
  onEdit: (id: string) => void
  onDelete: (id: string) => void
  loading?: boolean
}

export default function CRUDTable({ columns, data, onEdit, onDelete, loading }: CRUDTableProps) {
  if (loading) {
    return (
      <div className="bg-white border border-[#C7C2AB] p-6 text-center">
        <p className="text-sm text-[#777E5C]">Carregando...</p>
      </div>
    )
  }

  if (!data || data.length === 0) {
    return (
      <div className="bg-white border border-[#C7C2AB] p-6 text-center">
        <p className="text-sm text-[#777E5C]">Nenhum registro encontrado</p>
      </div>
    )
  }

  return (
    <div className="w-full overflow-x-auto bg-white border border-[#C7C2AB]">
      <table className="w-full font-montserrat text-sm">
        <thead className="bg-[#F5F4F1] border-b border-[#C7C2AB]">
          <tr>
            {columns.map((col) => (
              <th
                key={col.key}
                className="px-4 py-3 text-left font-semibold text-[#283106] text-xs"
              >
                {col.label}
              </th>
            ))}
            <th className="px-4 py-3 text-center font-semibold text-[#283106] text-xs">
              Ações
            </th>
          </tr>
        </thead>
        <tbody>
          {data.map((row, idx) => (
            <tr
              key={row.id || idx}
              className="border-b border-[#D1D8BD] hover:bg-[#F9F8F5] transition-colors"
            >
              {columns.map((col) => (
                <td key={col.key} className="px-4 py-3 text-[#283106]">
                  {col.render ? col.render(row[col.key], row) : row[col.key] || '-'}
                </td>
              ))}
              <td className="px-4 py-3 flex items-center justify-center gap-2">
                <button
                  onClick={() => onEdit(row.id)}
                  className="p-2 hover:bg-[#D1D8BD] rounded transition-colors"
                  title="Editar"
                >
                  <Edit2 className="w-4 h-4 text-[#283106]" />
                </button>
                <button
                  onClick={() => onDelete(row.id)}
                  className="p-2 hover:bg-red-100 rounded transition-colors"
                  title="Deletar"
                >
                  <Trash2 className="w-4 h-4 text-red-600" />
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
