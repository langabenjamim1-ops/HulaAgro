'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { TrendingDown, TrendingUp, AlertCircle, CheckCircle } from 'lucide-react'

interface ProductionData {
  flockId: string
  flockName: string
  birds: number
  mortality: number
  mortalityRate: number
  feedConsumption: number
  fcr: number
  avgWeight: number
  status: 'good' | 'warning' | 'critical'
}

export function ProductionDashboard() {
  const [data, setData] = useState<ProductionData[]>([])
  const [loading, setLoading] = useState(true)
  const [summary, setSummary] = useState<any>(null)

  useEffect(() => {
    async function loadData() {
      try {
        // Aqui você chamaria a API para obter dados reais
        // const response = await fetch('/api/ai/farm-summary')
        // const farmData = await response.json()
        
        // Por enquanto, dados de exemplo
        setData([
          {
            flockId: 'HLA-2026-01',
            flockName: 'Lote 01',
            birds: 4875,
            mortality: 125,
            mortalityRate: 2.5,
            feedConsumption: 2450,
            fcr: 1.92,
            avgWeight: 1680,
            status: 'good'
          },
          {
            flockId: 'HLA-2026-02',
            flockName: 'Lote 02',
            birds: 4680,
            mortality: 120,
            mortalityRate: 2.5,
            feedConsumption: 2380,
            fcr: 1.95,
            avgWeight: 1620,
            status: 'good'
          }
        ])
        
        setSummary({
          totalFlocks: 2,
          totalBirds: 9555,
          avgMortality: 2.5,
          avgFCR: 1.94
        })
      } catch (error) {
        console.error('Error loading production data:', error)
      } finally {
        setLoading(false)
      }
    }

    loadData()
  }, [])

  if (loading) {
    return <div className="text-center py-8">Carregando dados de produção...</div>
  }

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="text-sm text-gray-600">Lotes Ativos</div>
            <div className="text-3xl font-bold text-[#283106]">{summary?.totalFlocks || 0}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="text-sm text-gray-600">Total de Aves</div>
            <div className="text-3xl font-bold text-[#283106]">{summary?.totalBirds?.toLocaleString('pt-BR') || 0}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="text-sm text-gray-600">Mortalidade Média</div>
            <div className="text-3xl font-bold text-red-600">{summary?.avgMortality?.toFixed(2) || 0}%</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="text-sm text-gray-600">FCR Médio</div>
            <div className="text-3xl font-bold text-[#283106]">{summary?.avgFCR?.toFixed(2) || 0}</div>
          </CardContent>
        </Card>
      </div>

      {/* Flocks Detailed View */}
      <div className="space-y-4">
        <h3 className="text-xl font-bold text-[#283106]">Detalhes por Lote</h3>
        
        {data.map((flock) => (
          <Card key={flock.flockId} className="overflow-hidden">
            <CardHeader className="bg-[#F5F5F0] border-b">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg text-[#283106]">{flock.flockName}</CardTitle>
                <div className="flex items-center gap-2">
                  {flock.status === 'good' ? (
                    <CheckCircle className="w-5 h-5 text-green-600" />
                  ) : (
                    <AlertCircle className="w-5 h-5 text-yellow-600" />
                  )}
                  <span className="text-xs font-semibold text-[#6b7d3f]">
                    {flock.status === 'good' ? 'Saudável' : 'Atenção'}
                  </span>
                </div>
              </div>
            </CardHeader>
            
            <CardContent className="pt-6">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                <div>
                  <p className="text-xs text-gray-600">Aves Ativas</p>
                  <p className="text-2xl font-bold text-[#283106]">{flock.birds.toLocaleString('pt-BR')}</p>
                </div>
                
                <div>
                  <p className="text-xs text-gray-600">Mortalidade</p>
                  <div className="flex items-center gap-1 mt-1">
                    <TrendingDown className="w-4 h-4 text-red-600" />
                    <p className="text-2xl font-bold text-red-600">{flock.mortalityRate.toFixed(2)}%</p>
                  </div>
                </div>
                
                <div>
                  <p className="text-xs text-gray-600">Consumo Ração</p>
                  <p className="text-2xl font-bold text-[#283106]">{flock.feedConsumption.toLocaleString('pt-BR')}kg</p>
                </div>
                
                <div>
                  <p className="text-xs text-gray-600">FCR</p>
                  <div className="flex items-center gap-1 mt-1">
                    {flock.fcr < 2.0 ? (
                      <TrendingUp className="w-4 h-4 text-green-600" />
                    ) : (
                      <TrendingDown className="w-4 h-4 text-yellow-600" />
                    )}
                    <p className="text-2xl font-bold text-[#283106]">{flock.fcr.toFixed(2)}</p>
                  </div>
                </div>
              </div>
              
              <div className="mt-6 pt-6 border-t border-[#E8E8E8]">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Peso Médio</span>
                  <span className="font-bold text-[#283106]">{flock.avgWeight}g</span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* AI Insights */}
      <Card className="bg-blue-50 border-blue-200">
        <CardHeader>
          <CardTitle className="text-[#283106] flex items-center gap-2">
            💡 Insights da IA
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-gray-700">
            Abra o assistente de IA (💬) para obter análises detalhadas sobre:
          </p>
          <ul className="mt-3 space-y-2 text-sm text-gray-600">
            <li>✓ Análise de mortalidade e recomendações</li>
            <li>✓ Projeção de ração necessária</li>
            <li>✓ Análise financeira do ciclo</li>
            <li>✓ Alertas inteligentes e riscos</li>
            <li>✓ Relatórios automáticos de produção</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}
