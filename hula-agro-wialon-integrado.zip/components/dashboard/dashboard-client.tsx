'use client'

import { Settings, Bird, Egg, AlertCircle, DollarSign } from 'lucide-react'
import Sidebar from '@/components/sidebar/sidebar'
import ModulesOverview from '@/components/dashboard/modules-overview'
import FarmHeader from '@/components/dashboard/farm-header'
import KPICard from '@/components/dashboard/kpi-card'
import PerformanceChart from '@/components/dashboard/performance-chart'
import ConsumptionChart from '@/components/dashboard/consumption-chart'
import AviculturalMetrics from '@/components/dashboard/avicultural-metrics'
import WialonMapPanel from '@/components/wialon/wialon-map-panel'

export default function DashboardClient() {
  return (
    <div className="min-h-screen w-screen bg-[#DFE0DC] flex fixed inset-0 overflow-hidden font-montserrat flex-col md:flex-row">
      {/* Sidebar - Hidden on mobile, visible on md and up */}
      <div className="hidden md:flex">
        <Sidebar />
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col relative overflow-hidden">
        {/* Top Navigation Bar */}
        <div className="border-b border-[#C7C2AB] bg-white px-4 sm:px-6 md:px-7 py-3 flex justify-between items-center">
          <h2 className="text-xs sm:text-sm font-montserrat font-semibold text-[#283106]">Dashboard</h2>
          <div className="flex items-center gap-2 sm:gap-3">
            <button className="p-1 hover:bg-[#F5F4F1] transition-colors rounded">
              <Settings className="w-4 h-4 text-[#777E5C]" />
            </button>
            <div className="w-8 h-8 rounded-full bg-[#283106] flex items-center justify-center cursor-pointer hover:bg-[#1F2C00] transition-colors">
              <span className="text-white font-montserrat font-bold text-xs">L</span>
            </div>
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto bg-[#DFE0DC]">
          <div className="px-4 sm:px-6 md:px-7 py-4 sm:py-5 space-y-4 sm:space-y-5">
            {/* Line 1: Farm Header */}
            <FarmHeader />

            {/* Line 2: Main KPIs - Responsive Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-2 sm:gap-4">
              <KPICard
                title="Aves Ativas"
                value="-"
                percentage={0}
                status="green"
                icon={<Bird className="w-4 h-4 sm:w-5 sm:h-5 text-[#777E5C]" />}
              />
              <KPICard
                title="Ovos Hoje"
                value="-"
                percentage={0}
                status="green"
                icon={<Egg className="w-4 h-4 sm:w-5 sm:h-5 text-[#777E5C]" />}
              />
              <KPICard
                title="Mortalidade"
                value="-"
                percentage={0}
                status="green"
                icon={<AlertCircle className="w-4 h-4 sm:w-5 sm:h-5 text-[#777E5C]" />}
              />
              <KPICard
                title="Receita Hoje"
                value="-"
                percentage={0}
                status="green"
                icon={<DollarSign className="w-4 h-4 sm:w-5 sm:h-5 text-[#777E5C]" />}
                isCurrency
              />
            </div>

            {/* Line 3: Performance Charts - Responsive */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <PerformanceChart />
              <ConsumptionChart />
            </div>

            {/* Line 4: Wialon / Telemetria */}
            <WialonMapPanel />

            {/* Line 5: Avicultural Metrics */}
            <AviculturalMetrics />

            {/* Line 6: Module Access */}
            <div>
              <h3 className="text-xs font-semibold text-[#283106] mb-3 font-montserrat uppercase tracking-wide">Acesso Rápido aos Módulos</h3>
              <ModulesOverview />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
