'use client'

import { useState } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { usePathname } from 'next/navigation'
import { ChevronDown, ChevronRight, BarChart3, Bird, Heart, Briefcase, Settings } from 'lucide-react'

export default function Sidebar() {
  const pathname = usePathname()
  const [expandedSections, setExpandedSections] = useState<string[]>(['producao', 'saude', 'administrativo', 'sistema'])

  const toggleSection = (section: string) => {
    setExpandedSections((prev) =>
      prev.includes(section)
        ? prev.filter((s) => s !== section)
        : [...prev, section]
    )
  }

  const isActive = (href: string) => pathname === href

  const menuItems = [
    { 
      id: 'producao', 
      label: 'PRODUÇÃO',
      icon: Bird,
      items: [
        { name: 'Gestão de Lotes', href: '/modules/batches', icon: Bird },
        { name: 'Produção', href: '/modules/production', icon: Settings },
        { name: 'Análise Produção', href: '/modules/production-analysis', icon: BarChart3 },
      ] 
    },
    { 
      id: 'saude', 
      label: 'SAÚDE',
      icon: Heart,
      items: [
        { name: 'Sanidade', href: '/modules/health', icon: Settings },
        { name: 'Ambiência', href: '/modules/environment', icon: Settings },
        { name: 'Alertas', href: '/modules/alerts', icon: Settings },
      ] 
    },
    { 
      id: 'administrativo', 
      label: 'ADMINISTRATIVO',
      icon: Briefcase,
      items: [
        { name: 'Recursos Humanos', href: '/modules/hr', icon: Settings },
        { name: 'Compras', href: '/modules/purchases', icon: Settings },
        { name: 'Custos', href: '/modules/costs', icon: Settings },
      ] 
    },
    { 
      id: 'sistema', 
      label: 'SISTEMA',
      icon: Settings,
      items: [
        { name: 'Configurações', href: '/modules/configuration', icon: Settings },
        { name: 'Ração & Nutrição', href: '/modules/nutrition', icon: Settings },
        { name: 'Manejo Diário', href: '/modules/daily-management', icon: Settings },
      ] 
    },
  ]

  return (
    <aside className="w-64 bg-[#283106] text-white flex flex-col overflow-hidden font-montserrat border-r border-[#3D4A2C]">
      {/* Header with Logo */}
      <div className="p-5 border-b border-[#3D4A2C]">
        <Link href="/dashboard" className="flex items-center gap-3 hover:opacity-80 transition-opacity">
          <Image src="/logo-hula-agro.png" alt="HULA Agro" width={40} height={40} className="w-10 h-10" />
          <div>
            <h1 className="font-montserrat font-bold text-base text-white">HULA Agro</h1>
            <p className="text-xs text-[#D1D8BD] font-normal">Gestão Integrada</p>
          </div>
        </Link>
      </div>

      {/* Dashboard Link */}
      <Link href="/dashboard" className={`flex items-center gap-3 px-5 py-3 text-sm font-montserrat font-medium transition-colors border-l-4 ${ isActive('/dashboard') ? 'border-[#D1D8BD] text-white' : 'border-transparent text-[#C7C2AB] hover:text-white'}`}>
        <BarChart3 className="w-5 h-5" />
        Dashboard
      </Link>

      {/* Menu Sections */}
      <div className="flex-1 overflow-y-auto px-0 py-2">
        {menuItems.map((section) => {
          const SectionIcon = section.icon
          return (
            <div key={section.id}>
              {/* Section Header */}
              <button
                onClick={() => toggleSection(section.id)}
                className="flex items-center justify-between w-full px-5 py-2.5 text-sm font-montserrat font-semibold text-white hover:bg-[#3D4A2C] transition-colors gap-2"
              >
                <div className="flex items-center gap-2">
                  <SectionIcon className="w-4 h-4" />
                  {section.label}
                </div>
                {expandedSections.includes(section.id) ? (
                  <ChevronDown className="w-4 h-4" />
                ) : (
                  <ChevronRight className="w-4 h-4" />
                )}
              </button>

              {/* Menu Items */}
              {expandedSections.includes(section.id) && (
                <div className="space-y-0">
                  {section.items.map((item) => {
                    const ItemIcon = item.icon
                    const active = isActive(item.href)
                    return (
                      <Link
                        key={item.href}
                        href={item.href}
                        className={`flex items-center gap-3 px-5 py-2.5 text-sm font-montserrat transition-colors border-l-2 ml-4 ${ active ? 'bg-[#3D4A2C] border-l-[#D1D8BD] text-white' : 'border-l-transparent text-[#C7C2AB] hover:text-white'}`}
                      >
                        <ItemIcon className="w-4 h-4" />
                        {item.name}
                      </Link>
                    )
                  })}
                </div>
              )}
            </div>
          )
        })}
      </div>
    </aside>
  )
}
