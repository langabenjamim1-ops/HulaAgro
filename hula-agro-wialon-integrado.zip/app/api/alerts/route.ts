export const dynamic = 'force-dynamic'

import { createClient } from '@supabase/supabase-js'
import { NextRequest, NextResponse } from 'next/server'

function getSupabase() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL || '',
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ''
  )
}

export async function GET(request: NextRequest) {
  try {
    const facilityId = request.nextUrl.searchParams.get('facility_id')
    const priority = request.nextUrl.searchParams.get('priority')
    const supabase = getSupabase()
    
    let query = supabase.from('alerts').select('*')
    
    if (facilityId) {
      query = query.eq('facility_id', facilityId)
    }
    
    if (priority) {
      query = query.eq('priority', priority)
    }
    
    const { data, error } = await query.order('created_at', { ascending: false })
    
    if (error) {
      console.error('[v0] GET /api/alerts error:', error)
      return NextResponse.json([], { status: 200 })
    }
    
    return NextResponse.json(data || [], { status: 200 })
  } catch (error) {
    console.error('[v0] GET /api/alerts error:', error)
    return NextResponse.json([], { status: 200 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    
    const supabase = getSupabase()
    const { data, error } = await supabase
      .from('alerts')
      .insert([body])
      .select()
    
    if (error) throw error
    
    return NextResponse.json(data[0], { status: 201 })
  } catch (error) {
    console.error('[v0] POST /api/alerts error:', error)
    return NextResponse.json({ error: 'Failed to create alert' }, { status: 500 })
  }
}
