export const dynamic = 'force-dynamic'

import { createClient } from '@supabase/supabase-js'
import { NextRequest, NextResponse } from 'next/server'

function getSupabase() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL || '',
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ''
  )
}


export async function GET(request: NextRequest) {
  try {
    const farmId = request.nextUrl.searchParams.get('farm_id')
    const sensorType = request.nextUrl.searchParams.get('type')
    const supabase = getSupabase()
    
    let query = supabase.from('sensors').select('*')
    
    if (farmId) {
      query = query.eq('farm_id', farmId)
    }
    
    if (sensorType) {
      query = query.eq('sensor_type', sensorType)
    }
    
    const { data, error } = await query.order('created_at', { ascending: false })
    
    if (error) {
      console.error('[v0] GET /api/sensors error:', error)
      return NextResponse.json([], { status: 200 })
    }
    
    return NextResponse.json(data || [], { status: 200 })
  } catch (error) {
    console.error('[v0] GET /api/sensors error:', error)
    return NextResponse.json([], { status: 200 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    
    const supabase = getSupabase()
    const { data, error } = await supabase
      .from('sensors')
      .insert([body])
      .select()
      .single()
    
    if (error) throw error
    
    return NextResponse.json(data, { status: 201 })
  } catch (error) {
    console.error('[v0] POST /api/sensors error:', error)
    return NextResponse.json({ error: 'Failed to create sensor' }, { status: 500 })
  }
}
