export const dynamic = 'force-dynamic'

import { createClient } from '@supabase/supabase-js'
import { NextRequest, NextResponse } from 'next/server'

function getSupabase() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL || '',
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ''
  )
}

export async function GET(request: NextRequest) {
  try {
    const facilityId = request.nextUrl.searchParams.get('facility_id')
    const monitoringType = request.nextUrl.searchParams.get('type')
    const supabase = getSupabase()
    
    let query = supabase.from('environmental_monitoring').select('*')
    
    if (facilityId) {
      query = query.eq('facility_id', facilityId)
    }
    
    if (monitoringType) {
      query = query.eq('monitoring_type', monitoringType)
    }
    
    const { data, error } = await query.order('recorded_at', { ascending: false }).limit(100)
    
    if (error) {
      console.error('[v0] GET /api/environmental-monitoring error:', error)
      return NextResponse.json([], { status: 200 })
    }
    
    return NextResponse.json(data || [], { status: 200 })
  } catch (error) {
    console.error('[v0] GET /api/environmental-monitoring error:', error)
    return NextResponse.json([], { status: 200 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    
    const supabase = getSupabase()
    const { data, error } = await supabase
      .from('environmental_monitoring')
      .insert([body])
      .select()
    
    if (error) throw error
    
    return NextResponse.json(data[0], { status: 201 })
  } catch (error) {
    console.error('[v0] POST /api/environmental-monitoring error:', error)
    return NextResponse.json({ error: 'Failed to create environmental record' }, { status: 500 })
  }
}
