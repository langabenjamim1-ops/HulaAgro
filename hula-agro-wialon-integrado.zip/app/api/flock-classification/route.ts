export const dynamic = 'force-dynamic'

import { createClient } from '@supabase/supabase-js'
import { NextRequest, NextResponse } from 'next/server'

function getSupabase() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL || '',
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ''
  )
}

export async function GET(request: NextRequest) {
  try {
    const batchId = request.nextUrl.searchParams.get('batch_id')
    const classificationType = request.nextUrl.searchParams.get('type')
    const supabase = getSupabase()
    
    let query = supabase.from('flock_classifications').select('*')
    
    if (batchId) {
      query = query.eq('batch_id', batchId)
    }
    
    if (classificationType) {
      query = query.eq('classification_type', classificationType)
    }
    
    const { data, error } = await query.order('classification_date', { ascending: false })
    
    if (error) {
      console.error('[v0] GET /api/flock-classification error:', error)
      return NextResponse.json([], { status: 200 })
    }
    
    return NextResponse.json(data || [], { status: 200 })
  } catch (error) {
    console.error('[v0] GET /api/flock-classification error:', error)
    return NextResponse.json([], { status: 200 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    
    const supabase = getSupabase()
    const { data, error } = await supabase
      .from('flock_classifications')
      .insert([body])
      .select()
    
    if (error) throw error
    
    return NextResponse.json(data[0], { status: 201 })
  } catch (error) {
    console.error('[v0] POST /api/flock-classification error:', error)
    return NextResponse.json({ error: 'Failed to create flock classification' }, { status: 500 })
  }
}
