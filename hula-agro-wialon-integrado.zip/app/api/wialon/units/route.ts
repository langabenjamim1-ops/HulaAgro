import { NextResponse } from 'next/server'
import { getWialonUnits } from '@/lib/wialon'

export const dynamic = 'force-dynamic'

export async function GET() {
  try {
    const units = await getWialonUnits()

    return NextResponse.json({
      ok: true,
      source: 'wialon',
      updatedAt: new Date().toISOString(),
      units,
    })
  } catch (error) {
    console.error('[Wialon] GET /api/wialon/units:', error)

    return NextResponse.json(
      {
        ok: false,
        source: 'wialon',
        error: error instanceof Error ? error.message : 'Falha ao consultar Wialon',
        units: [],
      },
      { status: 503 }
    )
  }
}
