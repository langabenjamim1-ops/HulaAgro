export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import Anthropic from '@anthropic-ai/sdk'
import { farmAnalysisTools } from '@/lib/ai/tools'
import {
  getFlockData,
  getMortalityData,
  getFeedConsumption,
  getInventoryLevels,
  getVaccinationRecords,
  getFinancialSummary,
  generateFarmSummary,
} from '@/lib/ai/farm-data'

const systemPrompt = `Você é um especialista em avicultura com acesso a dados reais da fazenda. Você tem a capacidade de:

1. Analisar dados de lotes ativos, contagem de aves, taxa de mortalidade
2. Calcular consumo de ração, FCR (Índice de Conversão Alimentar)
3. Analisar registros de vacinação e saúde
4. Fazer análises financeiras (receita, despesas, lucro)
5. Gerar relatórios automatizados
6. Criar alertas inteligentes para problemas na fazenda

Sempre que o usuário fizer uma pergunta sobre dados da fazenda, use as ferramentas disponíveis para obter informações reais.
Forneça análises baseadas em dados, com observações, riscos e recomendações.
Estruture suas respostas com:
- Observações (o que você encontrou)
- Riscos (potenciais problemas)
- Recomendações (ações sugeridas)
- Nível de prioridade

Você é especialista em:
- Bem-estar animal e alojamento
- Nutrição e alimentação de aves
- Saúde e prevenção de doenças
- Produção de ovos e carne
- Reprodução e genética
- Economia e gestão da fazenda
- Qualidade da água
- Controle ambiental (temperatura, umidade, ventilação)
- Biossegurança
- Gestão de resíduos`

interface Message {
  role: 'user' | 'assistant'
  content: string
}

async function processToolCall(toolName: string, toolInput: Record<string, any>): Promise<string> {
  try {
    switch (toolName) {
      case 'get_flock_data':
        const flocks = await getFlockData()
        return JSON.stringify({
          success: true,
          data: flocks,
          summary: `${flocks.length} lotes encontrados`,
        })

      case 'get_mortality_analysis':
        const mortality = await getMortalityData(toolInput.batch_id)
        if (mortality.length === 0) {
          return JSON.stringify({ success: true, data: [], message: 'Nenhum dado de mortalidade encontrado' })
        }
        const avgMortality =
          mortality.reduce((sum: number, m: any) => sum + (m.mortality_count || 0), 0) / mortality.length
        return JSON.stringify({
          success: true,
          data: mortality,
          analysis: {
            average_daily_mortality: avgMortality.toFixed(2),
            total_records: mortality.length,
          },
        })

      case 'get_feed_analysis':
        const feedData = await getFeedConsumption(toolInput.batch_id)
        const totalFeed = feedData.reduce((sum: number, f: any) => sum + (f.feed_consumption || 0), 0)
        return JSON.stringify({
          success: true,
          data: feedData,
          analysis: {
            total_consumption: totalFeed.toFixed(2),
            avg_daily: (totalFeed / feedData.length).toFixed(2),
            records: feedData.length,
          },
        })

      case 'get_inventory_status':
        const inventory = await getInventoryLevels()
        return JSON.stringify({
          success: true,
          data: inventory,
          summary: `${inventory.length} itens de inventário`,
        })

      case 'get_health_status':
        const vacrecords = await getVaccinationRecords(toolInput.batch_id)
        return JSON.stringify({
          success: true,
          data: vacrecords,
          summary: `${vacrecords.length} registros de vacinação encontrados`,
        })

      case 'get_financial_analysis':
        const financial = await getFinancialSummary()
        const totalExpenses = financial.reduce((sum: number, f: any) => sum + (f.amount || 0), 0)
        return JSON.stringify({
          success: true,
          data: financial,
          analysis: {
            total_expenses: totalExpenses.toFixed(2),
            avg_daily: (totalExpenses / financial.length).toFixed(2),
          },
        })

      case 'generate_report':
        const summary = await generateFarmSummary()
        return JSON.stringify({
          success: true,
          report_type: toolInput.report_type,
          format: toolInput.format || 'text',
          data: summary,
        })

      case 'get_smart_alerts':
        const farmData = await generateFarmSummary()
        const alerts = []
        if (farmData && farmData.recentMortality.length > 0) {
          const recentMort = farmData.recentMortality[0] as any
          if (recentMort.mortality_count > 5) {
            alerts.push({
              type: 'high_mortality',
              severity: 'critical',
              message: 'Mortalidade elevada detectada',
            })
          }
        }
        if (farmData && farmData.inventory && farmData.inventory.length === 0) {
          alerts.push({
            type: 'low_inventory',
            severity: 'high',
            message: 'Revisar níveis de estoque',
          })
        }
        return JSON.stringify({
          success: true,
          alerts,
          total: alerts.length,
        })

      default:
        return JSON.stringify({ error: `Ferramenta desconhecida: ${toolName}` })
    }
  } catch (error) {
    console.error(`Erro ao processar ferramenta ${toolName}:`, error)
    return JSON.stringify({ error: `Erro ao processar ${toolName}` })
  }
}

export async function POST(request: NextRequest) {
  try {
    const { messages } = await request.json()

    if (!messages || !Array.isArray(messages)) {
      return NextResponse.json({ error: 'Invalid messages format' }, { status: 400 })
    }

    if (!process.env.ANTHROPIC_API_KEY) {
      console.error('[v0] ANTHROPIC_API_KEY is not set')
      return NextResponse.json({ error: 'AI service not configured' }, { status: 500 })
    }

    const client = new Anthropic({
      apiKey: process.env.ANTHROPIC_API_KEY,
    })

    let conversationMessages = [...(messages as Message[])]
    let response = await client.messages.create({
      model: 'claude-3-5-sonnet-20241022',
      max_tokens: 2048,
      system: systemPrompt,
      tools: farmAnalysisTools as any,
      messages: conversationMessages as any,
    })

    // Process tool calls in a loop until done
    while (response.stop_reason === 'tool_use') {
      const toolUseBlock = response.content.find((block: any) => block.type === 'tool_use')
      if (!toolUseBlock) break

      const toolResult = await processToolCall(toolUseBlock.name, toolUseBlock.input)

      conversationMessages = [
        ...conversationMessages,
        {
          role: 'assistant',
          content: response.content as any,
        },
        {
          role: 'user',
          content: [
            {
              type: 'tool_result',
              tool_use_id: toolUseBlock.id,
              content: toolResult,
            },
          ],
        },
      ]

      response = await client.messages.create({
        model: 'claude-3-5-sonnet-20241022',
        max_tokens: 2048,
        system: systemPrompt,
        tools: farmAnalysisTools as any,
        messages: conversationMessages as any,
      })
    }

    const textContent = response.content.find((block: any) => block.type === 'text')
    const text = textContent && textContent.type === 'text' ? textContent.text : ''

    return NextResponse.json({
      content: text,
      role: 'assistant',
    })
  } catch (error) {
    console.error('[v0] Error in advanced-chat API:', error)
    return NextResponse.json({ error: 'Failed to process message' }, { status: 500 })
  }
}
