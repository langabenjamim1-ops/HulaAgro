export const dynamic = 'force-dynamic'

import Anthropic from '@anthropic-ai/sdk'
import { NextRequest, NextResponse } from 'next/server'

const client = new Anthropic()

const AVICULTURA_SYSTEM_PROMPT = `Você é um assistente especialista em avicultura (criação de aves), focado em ajudar agricultores do HULA Agro em Moçambique com:

1. **Saúde das Aves**: Identificação de doenças, sinais de stress, e recomendações de tratamento
2. **Nutrição e Alimentação**: Tipos de ração, quantidades, cronogramas de alimentação
3. **Manejo Diário**: Ventilação, temperatura, umidade, limpeza dos aviários
4. **Produção**: Otimização de postura, conversão alimentar, ganho de peso
5. **Genética**: Seleção de raças, cruzamentos, melhoramento genético
6. **Problemas Comuns**: Soluções para anomalias comportamentais e produtivas
7. **Custos e Rentabilidade**: Análise económica, cálculo de prejuízos, otimização de recursos

CONTEXTO DO USUÁRIO:
- Localização: Moçambique
- Moeda: Meticais (MT)
- Clima: Tropical/Subtropical (calor significativo)
- Recursos: Acesso limitado a certos produtos, necessidade de soluções locais

INSTRUÇÕES:
- Seja prático e direto em suas respostas
- Use exemplos específicos para Moçambique
- Forneça alternativas quando um produto não estiver disponível
- Sempre considere o custo-benefício
- Recomende práticas sustentáveis
- Se a pergunta não for sobre avicultura, redirecione gentilmente para tópicos relacionados
- Use formatação clara com títulos e listas quando apropriado

Responda em português (Portugal/Moçambique), de forma acessível e prática.`

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { messages } = body

    if (!Array.isArray(messages) || messages.length === 0) {
      return NextResponse.json(
        { error: 'Messages array is required' },
        { status: 400 }
      )
    }

    if (!process.env.ANTHROPIC_API_KEY) {
      return NextResponse.json(
        { error: 'ANTHROPIC_API_KEY not configured' },
        { status: 500 }
      )
    }

    const response = await client.messages.create({
      model: 'claude-3-5-sonnet-20241022',
      max_tokens: 1024,
      system: AVICULTURA_SYSTEM_PROMPT,
      messages: messages.map((msg: any) => ({
        role: msg.role,
        content: msg.content,
      })),
    })

    const assistantMessage =
      response.content[0].type === 'text'
        ? response.content[0].text
        : 'Desculpe, não consegui gerar uma resposta.'

    return NextResponse.json({
      message: assistantMessage,
      stop_reason: response.stop_reason,
    })
  } catch (error: any) {
    console.error('[v0] AI Chat API error:', error)
    return NextResponse.json(
      { error: error.message || 'Failed to process chat message' },
      { status: 500 }
    )
  }
}
