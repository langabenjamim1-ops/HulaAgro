'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'

const batches = [
  { id: '1', name: 'Lote A - Jan/2024', type: 'Poedeira', birds: 5000, days: 180 },
  { id: '2', name: 'Lote B - Feb/2024', type: 'Poedeira', birds: 5000, days: 120 },
  { id: '3', name: 'Lote C - Mar/2024', type: 'Frango de Corte', birds: 10000, days: 45 },
]

const comparisonData = [
  { week: '1', loteA: 2.5, loteB: 2.3, loteC: 180 },
  { week: '2', loteA: 3.2, loteB: 3.0, loteC: 350 },
  { week: '3', loteA: 4.1, loteB: 3.8, loteC: 580 },
  { week: '4', loteA: 4.8, loteB: 4.5, loteC: 850 },
  { week: '5', loteA: 5.2, loteB: 4.9, loteC: 1200 },
  { week: '6', loteA: 5.5, loteB: 5.1, loteC: 1650 },
]

const performanceMetrics = [
  {
    metric: 'Taxa de Postura',
    loteA: '92.5%',
    loteB: '91.8%',
    loteC: 'N/A',
    advantage: 'Lote A',
  },
  {
    metric: 'Conversão Alimentar',
    loteA: '2.1',
    loteB: '2.15',
    loteC: '1.85',
    advantage: 'Lote C',
  },
  {
    metric: 'Ganho de Peso/dia',
    loteA: '5.2g',
    loteB: '4.9g',
    loteC: '35g',
    advantage: 'Lote C',
  },
  {
    metric: 'Mortalidade',
    loteA: '0.8%',
    loteB: '1.2%',
    loteC: '2.1%',
    advantage: 'Lote A',
  },
]

export default function BatchComparisonPage() {
  const [selectedBatches, setSelectedBatches] = useState(['1', '2'])

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900">Comparação Entre Lotes</h1>
          <p className="text-gray-600 mt-2">Analise o desempenho e compare indicadores entre diferentes lotes</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Lote 1</CardTitle>
            </CardHeader>
            <CardContent>
              <Select value={selectedBatches[0]} onValueChange={(value) => setSelectedBatches([value, selectedBatches[1]])}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {batches.map((batch) => (
                    <SelectItem key={batch.id} value={batch.id}>
                      {batch.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Lote 2</CardTitle>
            </CardHeader>
            <CardContent>
              <Select value={selectedBatches[1]} onValueChange={(value) => setSelectedBatches([selectedBatches[0], value])}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {batches.map((batch) => (
                    <SelectItem key={batch.id} value={batch.id}>
                      {batch.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </CardContent>
          </Card>
        </div>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Produção ao Longo do Tempo</CardTitle>
            <CardDescription>Comparativo de produção semanal entre lotes</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={comparisonData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="week" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="loteA" stroke="#3b82f6" name="Lote A" />
                <Line type="monotone" dataKey="loteB" stroke="#10b981" name="Lote B" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Indicadores de Desempenho</CardTitle>
            <CardDescription>Comparação de métricas zootécnicas</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {performanceMetrics.map((metric, idx) => (
                <div key={idx} className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-semibold text-gray-900">{metric.metric}</h3>
                    <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">
                      Melhor: {metric.advantage}
                    </span>
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-center">
                      <p className="text-sm text-gray-600">Lote A</p>
                      <p className="text-lg font-bold text-blue-600">{metric.loteA}</p>
                    </div>
                    <div className="text-center">
                      <p className="text-sm text-gray-600">Lote B</p>
                      <p className="text-lg font-bold text-green-600">{metric.loteB}</p>
                    </div>
                    <div className="text-center">
                      <p className="text-sm text-gray-600">Lote C</p>
                      <p className="text-lg font-bold text-purple-600">{metric.loteC}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
