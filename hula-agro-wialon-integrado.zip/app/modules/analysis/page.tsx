'use client'

import Link from 'next/link'
import { ArrowLeft, Plus } from 'lucide-react'

const sections = [
  { title: 'Lote vs Lote', description: 'Compare desempenho', href: '/modules/analysis/batch-comparison', icon: '🔄' },
  { title: 'Ração A vs B', description: 'Analise rações', href: '/modules/analysis/feed-comparison', icon: '🌽' },
  { title: 'Genética A vs B', description: 'Compare genéticas', href: '/modules/analysis/genetics-comparison', icon: '🧬' },
  { title: 'KPIs Zootécnicos', description: 'Indicadores chave', href: '/modules/analysis/kpis', icon: '📊' },
]

export default function AnalysisPage() {
  return (
    <div className="w-full font-montserrat">
      <div className="mb-8 flex items-start justify-between">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <Link href="/dashboard" className="p-1 hover:bg-gray-100 rounded transition-colors">
              <ArrowLeft className="w-5 h-5 text-gray-600" />
            </Link>
            <span className="text-3xl">📊</span>
          </div>
          <h1 className="text-2xl font-montserrat font-bold text-gray-900">Análises & Comparações</h1>
          <p className="text-gray-600 text-sm mt-1">Compare desempenho entre lotes, rações e genéticas</p>
        </div>
        <button className="px-4 py-2 bg-[#22C55E] text-white rounded hover:bg-[#16a34a] transition-colors font-montserrat font-semibold text-sm flex items-center gap-2">
          <Plus className="w-4 h-4" /> Novo
        </button>
      </div>
      <div className="grid grid-cols-4 gap-4">
        {sections.map((s) => (
          <Link key={s.href} href={s.href} className="group">
            <div className="bg-white border border-gray-200 rounded-lg p-5 hover:shadow-md hover:border-[#22C55E] transition-all h-full flex flex-col items-center text-center">
              <div className="text-5xl mb-3">{s.icon}</div>
              <h3 className="font-montserrat font-semibold text-gray-900 text-xs mb-1 leading-tight">{s.title}</h3>
              <p className="text-xs text-gray-500 font-montserrat leading-tight">{s.description}</p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  )
}
