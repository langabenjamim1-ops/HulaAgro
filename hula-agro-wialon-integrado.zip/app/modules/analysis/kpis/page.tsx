'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts'
import { Badge } from '@/components/ui/badge'

const kpiData = [
  { month: 'Jan', producao: 92.5, mortalidade: 1.2, conversao: 2.1, viabilidade: 98.8 },
  { month: 'Fev', producao: 93.2, mortalidade: 1.0, conversao: 2.08, viabilidade: 99.0 },
  { month: 'Mar', producao: 94.1, mortalidade: 0.8, conversao: 2.05, viabilidade: 99.2 },
  { month: 'Abr', producao: 93.8, mortalidade: 1.1, conversao: 2.06, viabilidade: 98.9 },
  { month: 'Mai', producao: 94.5, mortalidade: 0.9, conversao: 2.04, viabilidade: 99.1 },
]

const kpiIndicators = [
  {
    name: 'Taxa de Postura',
    value: '94.5%',
    meta: '92%',
    status: 'Acima',
    color: 'text-green-600',
    bgColor: 'bg-green-50',
  },
  {
    name: 'Conversão Alimentar',
    value: '2.04',
    meta: '2.10',
    status: 'Acima',
    color: 'text-green-600',
    bgColor: 'bg-green-50',
  },
  {
    name: 'Mortalidade',
    value: '0.9%',
    meta: '2%',
    status: 'Acima',
    color: 'text-green-600',
    bgColor: 'bg-green-50',
  },
  {
    name: 'Viabilidade',
    value: '99.1%',
    meta: '97%',
    status: 'Acima',
    color: 'text-green-600',
    bgColor: 'bg-green-50',
  },
  {
    name: 'Peso Médio',
    value: '2.085kg',
    meta: '2.00kg',
    status: 'Acima',
    color: 'text-green-600',
    bgColor: 'bg-green-50',
  },
  {
    name: 'Uniformidade',
    value: '92%',
    meta: '90%',
    status: 'Acima',
    color: 'text-green-600',
    bgColor: 'bg-green-50',
  },
]

const productionBreakdown = [
  { name: 'Ovos Tipo A', value: 45 },
  { name: 'Ovos Tipo B', value: 35 },
  { name: 'Ovos Refugo', value: 20 },
]

const COLORS = ['#3b82f6', '#10b981', '#f59e0b']

export default function KPIsPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-amber-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900">KPIs Zootécnicos</h1>
          <p className="text-gray-600 mt-2">Acompanhe os indicadores-chave de desempenho da sua produção</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
          {kpiIndicators.map((kpi, idx) => (
            <Card key={idx} className={`${kpi.bgColor}`}>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">{kpi.name}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-end justify-between">
                  <div>
                    <p className={`text-3xl font-bold ${kpi.color}`}>{kpi.value}</p>
                    <p className="text-xs text-gray-500 mt-1">Meta: {kpi.meta}</p>
                  </div>
                  <Badge className="bg-green-100 text-green-800">{kpi.status}</Badge>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Evolução dos KPIs</CardTitle>
              <CardDescription>Acompanhamento dos principais indicadores ao longo do tempo</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={kpiData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis yAxisId="left" />
                  <YAxis yAxisId="right" orientation="right" />
                  <Tooltip />
                  <Legend />
                  <Line yAxisId="left" type="monotone" dataKey="producao" stroke="#3b82f6" name="Produção %" />
                  <Line yAxisId="left" type="monotone" dataKey="viabilidade" stroke="#10b981" name="Viabilidade %" />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Distribuição de Produtos</CardTitle>
              <CardDescription>Classificação de ovos (%)</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={productionBreakdown}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, value }) => `${name}: ${value}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {productionBreakdown.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Conversão Alimentar Mensal</CardTitle>
              <CardDescription>Eficiência no aproveitamento de ração</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={kpiData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="conversao" fill="#3b82f6" name="Conversão Alimentar" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Mortalidade Mensal</CardTitle>
              <CardDescription>Taxa de mortalidade (%)</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={kpiData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="mortalidade" fill="#ef4444" name="Mortalidade %" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
