'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'

const feedData = [
  { week: '1', racaoA: 2.1, racaoB: 2.0, custo_a: 45, custo_b: 48 },
  { week: '2', racaoA: 3.0, racaoB: 2.8, custo_a: 90, custo_b: 96 },
  { week: '3', racaoA: 4.0, racaoB: 3.7, custo_a: 135, custo_b: 144 },
  { week: '4', racaoA: 4.8, racaoB: 4.4, custo_a: 180, custo_b: 192 },
  { week: '5', racaoA: 5.3, racaoB: 4.9, custo_a: 225, custo_b: 240 },
]

const feedMetrics = [
  { metric: 'Conversão Alimentar', racaoA: '2.05', racaoB: '2.15', melhor: 'Ração A' },
  { metric: 'Ganho de Peso/dia', racaoA: '35.2g', racaoB: '32.8g', melhor: 'Ração A' },
  { metric: 'Consumo Médio', racaoA: '72.1g/ave', racaoB: '70.6g/ave', melhor: 'Ração B' },
  { metric: 'Custo/kg Ganho', racaoA: 'R$ 4.19', racaoB: 'R$ 4.56', melhor: 'Ração A' },
]

export default function FeedComparisonPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900">Comparação Ração A vs B</h1>
          <p className="text-gray-600 mt-2">Analise o desempenho de diferentes tipos de ração e seu impacto no custo</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          <Card>
            <CardHeader>
              <CardTitle>Ração A</CardTitle>
              <CardDescription>Fórmula Premium com 22% PB</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              <div>
                <p className="text-sm text-gray-600">Proteína Bruta</p>
                <p className="text-lg font-bold text-blue-600">22%</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Custo por Kg</p>
                <p className="text-lg font-bold text-blue-600">R$ 1.85</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Fornecedor</p>
                <p className="text-sm text-gray-900">Nutrição Premium</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Ração B</CardTitle>
              <CardDescription>Fórmula Econômica com 20% PB</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              <div>
                <p className="text-sm text-gray-600">Proteína Bruta</p>
                <p className="text-lg font-bold text-green-600">20%</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Custo por Kg</p>
                <p className="text-lg font-bold text-green-600">R$ 1.65</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Fornecedor</p>
                <p className="text-sm text-gray-900">Agro Solutions</p>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Ganho de Peso ao Longo do Tempo</CardTitle>
            <CardDescription>Comparativo de ganho de peso semanal</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={feedData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="week" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="racaoA" stroke="#3b82f6" name="Ração A" />
                <Line type="monotone" dataKey="racaoB" stroke="#10b981" name="Ração B" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Custo Acumulado</CardTitle>
            <CardDescription>Comparativo de custo total por ave</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={feedData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="week" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="custo_a" fill="#3b82f6" name="Custo Ração A (R$)" />
                <Bar dataKey="custo_b" fill="#10b981" name="Custo Ração B (R$)" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Indicadores Comparativos</CardTitle>
            <CardDescription>Resumo dos principais indicadores</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {feedMetrics.map((metric, idx) => (
                <div key={idx} className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-semibold text-gray-900">{metric.metric}</h3>
                    <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">
                      Melhor: {metric.melhor}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-600">Ração A</p>
                      <p className="text-lg font-bold text-blue-600">{metric.racaoA}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Ração B</p>
                      <p className="text-lg font-bold text-green-600">{metric.racaoB}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
