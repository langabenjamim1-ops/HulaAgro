'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'

const geneticsData = [
  { week: '1', linhagem_a: 45, linhagem_b: 42, linhagem_c: 40 },
  { week: '2', linhagem_a: 95, linhagem_b: 90, linhagem_c: 85 },
  { week: '3', linhagem_a: 155, linhagem_b: 148, linhagem_c: 140 },
  { week: '4', linhagem_a: 225, linhagem_b: 215, linhagem_c: 205 },
  { week: '5', linhagem_a: 305, linhagem_b: 290, linhagem_c: 275 },
]

const geneticsMetrics = [
  { metric: 'Peso Final Médio', linhagem_a: '2.100kg', linhagem_b: '2.000kg', linhagem_c: '1.950kg', melhor: 'Linhagem A' },
  { metric: 'Taxa de Postura', linhagem_a: '94.5%', linhagem_b: '92.3%', linhagem_c: '90.1%', melhor: 'Linhagem A' },
  { metric: 'Conversão Alimentar', linhagem_a: '2.05', linhagem_b: '2.12', linhagem_c: '2.18', melhor: 'Linhagem A' },
  { metric: 'Viabilidade', linhagem_a: '98.5%', linhagem_b: '97.8%', linhagem_c: '97.2%', melhor: 'Linhagem A' },
  { metric: 'Uniformidade', linhagem_a: '92%', linhagem_b: '90%', linhagem_c: '88%', melhor: 'Linhagem A' },
]

export default function GeneticsComparisonPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900">Comparação Genética A vs B vs C</h1>
          <p className="text-gray-600 mt-2">Analise o desempenho de diferentes linhagens genéticas</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          <Card>
            <CardHeader>
              <CardTitle>Linhagem A</CardTitle>
              <CardDescription>Genética Premium</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              <div>
                <p className="text-sm text-gray-600">Origem</p>
                <p className="text-sm text-gray-900">Gallus Genética</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Custo/Ave</p>
                <p className="text-lg font-bold text-blue-600">R$ 8.50</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Performance</p>
                <p className="text-sm text-green-600">Excelente</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Linhagem B</CardTitle>
              <CardDescription>Genética Padrão</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              <div>
                <p className="text-sm text-gray-600">Origem</p>
                <p className="text-sm text-gray-900">Avigen Brasil</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Custo/Ave</p>
                <p className="text-lg font-bold text-green-600">R$ 7.20</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Performance</p>
                <p className="text-sm text-green-600">Bom</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Linhagem C</CardTitle>
              <CardDescription>Genética Econômica</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              <div>
                <p className="text-sm text-gray-600">Origem</p>
                <p className="text-sm text-gray-900">Poultry Genetics</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Custo/Ave</p>
                <p className="text-lg font-bold text-orange-600">R$ 5.80</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Performance</p>
                <p className="text-sm text-yellow-600">Aceitável</p>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Ganho de Peso ao Longo do Tempo</CardTitle>
            <CardDescription>Comparativo de ganho de peso semanal entre linhagens</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={geneticsData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="week" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="linhagem_a" stroke="#3b82f6" name="Linhagem A" />
                <Line type="monotone" dataKey="linhagem_b" stroke="#10b981" name="Linhagem B" />
                <Line type="monotone" dataKey="linhagem_c" stroke="#f59e0b" name="Linhagem C" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Indicadores de Performance</CardTitle>
            <CardDescription>Comparação detalhada de indicadores zootécnicos</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {geneticsMetrics.map((metric, idx) => (
                <div key={idx} className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-semibold text-gray-900">{metric.metric}</h3>
                    <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">
                      {metric.melhor}
                    </span>
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <p className="text-sm text-gray-600">Linhagem A</p>
                      <p className="text-lg font-bold text-blue-600">{metric.linhagem_a}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Linhagem B</p>
                      <p className="text-lg font-bold text-green-600">{metric.linhagem_b}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Linhagem C</p>
                      <p className="text-lg font-bold text-orange-600">{metric.linhagem_c}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
