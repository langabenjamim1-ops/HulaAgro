'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'
import { Calendar, Trash2 } from 'lucide-react'

interface ProductionRecord {
  id: string
  record_date: string
  average_weight?: number
  feed_consumption?: number
  notes?: string
}

export default function BroilersPage() {
  const [records, setRecords] = useState<ProductionRecord[]>([])
  const [loading, setLoading] = useState(true)
  const [dateFilter, setDateFilter] = useState('')
  const [open, setOpen] = useState(false)
  const [formData, setFormData] = useState({ average_weight: '', feed_consumption: '', batch: '', avgWeight: '', weightGain: '', fcr: '' })

  useEffect(() => {
    fetchRecords()
  }, [])

  async function fetchRecords() {
    try {
      setLoading(true)
      const response = await fetch('/api/production')
      const data = await response.json()
      if (Array.isArray(data)) {
        setRecords(data.filter((r: any) => r.notes?.includes('broilers') || true))
      }
    } catch (error) {
      console.error('[v0] Error fetching records:', error)
    } finally {
      setLoading(false)
    }
  }

  async function handleAdd() {
    if (!formData.average_weight) return
    
    try {
      const response = await fetch('/api/production', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          record_date: new Date().toISOString().split('T')[0],
          average_weight: Number(formData.average_weight),
          feed_consumption: Number(formData.feed_consumption) || 0,
          notes: 'broilers'
        })
      })
      
      if (response.ok) {
        await fetchRecords()
        setFormData({ average_weight: '', feed_consumption: '' })
        setOpen(false)
      }
    } catch (error) {
      console.error('[v0] Error adding record:', error)
    }
  }

  async function handleDelete(id: string) {
    if (!confirm('Apagar este registro?')) return
    
    try {
      const response = await fetch(`/api/production/${id}`, {
        method: 'DELETE'
      })
      
      if (response.ok) {
        await fetchRecords()
      }
    } catch (error) {
      console.error('[v0] Error deleting record:', error)
    }
  }
  const filteredRecords = dateFilter
    ? records.filter(r => r.record_date === dateFilter)
    : records

  const chartData = filteredRecords.slice().reverse().map((r) => ({
    date: new Date(r.record_date).toLocaleDateString('pt-BR', { month: '2-digit', day: '2-digit' }),
    peso: r.average_weight || 0,
    consumo: r.feed_consumption || 0,
  }))

  const avgWeight = filteredRecords.length > 0
    ? Math.round(filteredRecords.reduce((sum, r) => sum + (r.average_weight || 0), 0) / filteredRecords.length)
    : 0
  const totalConsumption = filteredRecords.reduce((sum, r) => sum + (r.feed_consumption || 0), 0).toFixed(1)
  const avgFCR = filteredRecords.length > 0
    ? (Number(totalConsumption) / filteredRecords.length).toFixed(2)
    : 0

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Produção - Corte</h1>
          <p className="text-gray-600 mt-2">Registre ganho de peso e desempenho</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button>+ Registrar Desempenho</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Registrar Desempenho - Corte</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Lote</label>
                <select
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  value={formData.batch}
                  onChange={(e) => setFormData({ ...formData, batch: e.target.value })}
                >
                  <option value="">Selecionar lote</option>
                  <option value="Lote Corte 001">Lote Corte 001</option>
                  <option value="Lote Corte 002">Lote Corte 002</option>
                </select>
              </div>
              <div>
                <label className="text-sm font-medium">Peso Médio (g)</label>
                <Input
                  type="number"
                  placeholder="2450"
                  value={formData.avgWeight}
                  onChange={(e) => setFormData({ ...formData, avgWeight: e.target.value })}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Ganho Diário (g)</label>
                <Input
                  type="number"
                  placeholder="52"
                  value={formData.weightGain}
                  onChange={(e) => setFormData({ ...formData, weightGain: e.target.value })}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Conversão Alimentar (CA)</label>
                <Input
                  type="number"
                  step="0.01"
                  placeholder="1.85"
                  value={formData.fcr}
                  onChange={(e) => setFormData({ ...formData, fcr: e.target.value })}
                />
              </div>
              <Button onClick={handleAdd} className="w-full">Registrar</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Peso Médio</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-600">{avgWeight}g</div>
            <p className="text-sm text-gray-600 mt-1">últimos {records.length} dias</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">CA Média</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">{avgFCR}</div>
            <p className="text-sm text-gray-600 mt-1">conversão alimentar</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Ganho Hoje</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-purple-600">{records[0]?.weightGain || 0}g</div>
            <p className="text-sm text-gray-600 mt-1">por ave</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Evolução de Peso e Ganho</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis yAxisId="left" />
              <YAxis yAxisId="right" orientation="right" />
              <Tooltip />
              <Legend />
              <Bar yAxisId="left" dataKey="peso" fill="#3b82f6" name="Peso (g)" />
              <Bar yAxisId="right" dataKey="ganho" fill="#10b981" name="Ganho (g/dia)" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Histórico de Desempenho</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-100 border-b">
                <tr>
                  <th className="text-left px-4 py-2">Data</th>
                  <th className="text-left px-4 py-2">Lote</th>
                  <th className="text-right px-4 py-2">Peso Médio (g)</th>
                  <th className="text-right px-4 py-2">Ganho Diário (g)</th>
                  <th className="text-right px-4 py-2">CA</th>
                </tr>
              </thead>
              <tbody>
                {records.map((record) => (
                  <tr key={record.id} className="border-b hover:bg-gray-50">
                    <td className="px-4 py-2">{new Date(record.record_date).toLocaleDateString('pt-BR')}</td>
                    <td className="px-4 py-2 font-medium">Corte 001</td>
                    <td className="px-4 py-2 text-right">{record.average_weight || 0}g</td>
                    <td className="px-4 py-2 text-right">52g</td>
                    <td className="px-4 py-2 text-right font-semibold text-green-600">1.85</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
