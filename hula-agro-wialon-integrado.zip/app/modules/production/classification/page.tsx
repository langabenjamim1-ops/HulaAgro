'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'

export default function ClassificationPage() {
  const [classifications, setClassifications] = useState([
    { id: 1, name: 'Extra', minWeight: 65, maxWeight: 75, price: 6.50, color: '#d4af37' },
    { id: 2, name: 'Tipo A', minWeight: 55, maxWeight: 65, price: 5.80, color: '#c0c0c0' },
    { id: 3, name: 'Tipo B', minWeight: 45, maxWeight: 55, price: 4.90, color: '#cd7f32' },
  ])
  const [open, setOpen] = useState(false)
  const [formData, setFormData] = useState({ name: '', minWeight: '', maxWeight: '', price: '', color: '#000000' })

  const handleAdd = () => {
    if (formData.name && formData.minWeight && formData.maxWeight) {
      setClassifications([
        ...classifications,
        {
          id: Date.now(),
          name: formData.name,
          minWeight: Number(formData.minWeight),
          maxWeight: Number(formData.maxWeight),
          price: Number(formData.price),
          color: formData.color,
        },
      ])
      setFormData({ name: '', minWeight: '', maxWeight: '', price: '', color: '#000000' })
      setOpen(false)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Classificação</h1>
          <p className="text-gray-600 mt-2">Gerencie as classes de produtos</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button>+ Nova Classe</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Adicionar Classificação</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Nome da Classe</label>
                <Input
                  placeholder="Ex: Extra"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-sm font-medium">Peso Mín (g)</label>
                  <Input
                    type="number"
                    placeholder="65"
                    value={formData.minWeight}
                    onChange={(e) => setFormData({ ...formData, minWeight: e.target.value })}
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Peso Máx (g)</label>
                  <Input
                    type="number"
                    placeholder="75"
                    value={formData.maxWeight}
                    onChange={(e) => setFormData({ ...formData, maxWeight: e.target.value })}
                  />
                </div>
              </div>
              <div>
                <label className="text-sm font-medium">Preço (R$/ovo)</label>
                <Input
                  type="number"
                  step="0.01"
                  placeholder="6.50"
                  value={formData.price}
                  onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Cor</label>
                <input
                  type="color"
                  value={formData.color}
                  onChange={(e) => setFormData({ ...formData, color: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                />
              </div>
              <Button onClick={handleAdd} className="w-full">Adicionar</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {classifications.map((c) => (
          <Card key={c.id}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>{c.name}</CardTitle>
                <div className="w-6 h-6 rounded" style={{ backgroundColor: c.color }} />
              </div>
            </CardHeader>
            <CardContent className="space-y-2">
              <div>
                <p className="text-sm text-gray-600">Peso</p>
                <p className="text-lg font-semibold">{c.minWeight}g - {c.maxWeight}g</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Preço</p>
                <p className="text-lg font-semibold text-green-600">R$ {c.price.toFixed(2)}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Tabela de Classificações</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-100 border-b">
                <tr>
                  <th className="text-left px-4 py-2">Classe</th>
                  <th className="text-left px-4 py-2">Intervalo Peso</th>
                  <th className="text-right px-4 py-2">Preço</th>
                  <th className="text-left px-4 py-2">Cor</th>
                </tr>
              </thead>
              <tbody>
                {classifications.map((c) => (
                  <tr key={c.id} className="border-b hover:bg-gray-50">
                    <td className="px-4 py-2 font-medium">{c.name}</td>
                    <td className="px-4 py-2">{c.minWeight}g - {c.maxWeight}g</td>
                    <td className="px-4 py-2 text-right font-semibold text-green-600">R$ {c.price.toFixed(2)}</td>
                    <td className="px-4 py-2">
                      <div className="w-4 h-4 rounded" style={{ backgroundColor: c.color }} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
