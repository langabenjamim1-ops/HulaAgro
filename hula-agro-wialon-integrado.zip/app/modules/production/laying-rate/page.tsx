'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'

export default function LayingRatePage() {
  const data = [
    { week: '1', rate: 45, target: 50, accumulated: 45 },
    { week: '2', rate: 62, target: 65, accumulated: 107 },
    { week: '3', rate: 75, target: 78, accumulated: 182 },
    { week: '4', rate: 85, target: 88, accumulated: 267 },
    { week: '5', rate: 92, target: 94, accumulated: 359 },
    { week: '6', rate: 95, target: 96, accumulated: 454 },
    { week: '7', rate: 96, target: 97, accumulated: 550 },
    { week: '8', rate: 97, target: 97, accumulated: 647 },
  ]

  const stats = [
    {
      label: 'Taxa Atual',
      value: '97%',
      color: 'text-green-600',
      description: 'Dentro do esperado',
    },
    {
      label: 'Acumulado',
      value: '647 ovos/100 aves',
      color: 'text-blue-600',
      description: 'até a data',
    },
    {
      label: 'Versus Meta',
      value: '+0%',
      color: 'text-purple-600',
      description: 'cumprimento',
    },
    {
      label: 'Pico de Postura',
      value: '97%',
      color: 'text-yellow-600',
      description: 'semana 8',
    },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Taxa de Postura</h1>
        <p className="text-gray-600 mt-2">Acompanhe indicadores de produção de ovos</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {stats.map((stat, idx) => (
          <Card key={idx}>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">{stat.label}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${stat.color}`}>{stat.value}</div>
              <p className="text-xs text-gray-600 mt-1">{stat.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Curva de Postura - Meta vs Real</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="week" label={{ value: 'Semana', position: 'insideBottomRight', offset: -5 }} />
              <YAxis label={{ value: 'Taxa (%)', angle: -90, position: 'insideLeft' }} />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="target" stroke="#94a3b8" strokeDasharray="5 5" name="Meta" />
              <Line type="monotone" dataKey="rate" stroke="#10b981" strokeWidth={2} name="Real" />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Acumulado de Ovos</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={data}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="week" />
              <YAxis />
              <Tooltip />
              <Area type="monotone" dataKey="accumulated" fill="#3b82f6" stroke="#1e40af" />
            </AreaChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Indicadores por Semana</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-100 border-b">
                <tr>
                  <th className="text-left px-4 py-2">Semana</th>
                  <th className="text-right px-4 py-2">Taxa Real (%)</th>
                  <th className="text-right px-4 py-2">Meta (%)</th>
                  <th className="text-center px-4 py-2">Status</th>
                  <th className="text-right px-4 py-2">Acumulado</th>
                </tr>
              </thead>
              <tbody>
                {data.map((row) => {
                  const status = row.rate >= row.target ? '✓' : '✗'
                  const statusColor = row.rate >= row.target ? 'text-green-600' : 'text-red-600'
                  return (
                    <tr key={row.week} className="border-b hover:bg-gray-50">
                      <td className="px-4 py-2 font-medium">Semana {row.week}</td>
                      <td className="px-4 py-2 text-right font-semibold">{row.rate}%</td>
                      <td className="px-4 py-2 text-right">{row.target}%</td>
                      <td className={`px-4 py-2 text-center font-bold ${statusColor}`}>{status}</td>
                      <td className="px-4 py-2 text-right">{row.accumulated} ovos</td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
