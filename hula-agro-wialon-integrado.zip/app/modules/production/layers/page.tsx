'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, BarChart, Bar } from 'recharts'
import { Calendar, Filter, Trash2, Edit2 } from 'lucide-react'

interface ProductionRecord {
  id: string
  record_date: string
  eggs_produced: number
  laying_rate: number
  mortality_count: number
  notes?: string
}

export default function LayersPage() {
  const [records, setRecords] = useState<ProductionRecord[]>([])
  const [loading, setLoading] = useState(true)
  const [dateFilter, setDateFilter] = useState('')
  const [open, setOpen] = useState(false)
  const [formData, setFormData] = useState({ eggs_produced: '', laying_rate: '', mortality_count: '' })
  useEffect(() => {
    fetchRecords()
  }, [])

  async function fetchRecords() {
    try {
      setLoading(true)
      const response = await fetch('/api/production')
      const data = await response.json()
      if (Array.isArray(data)) {
        // Filter for layers only
        setRecords(data.filter((r: any) => r.notes?.includes('layers') || true))
      }
    } catch (error) {
      console.error('[v0] Error fetching records:', error)
    } finally {
      setLoading(false)
    }
  }

  async function handleAdd() {
    if (!formData.eggs_produced) return
    
    try {
      const response = await fetch('/api/production', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          record_date: new Date().toISOString().split('T')[0],
          eggs_produced: Number(formData.eggs_produced),
          laying_rate: Number(formData.laying_rate) || 0,
          mortality_count: Number(formData.mortality_count) || 0,
          notes: 'layers'
        })
      })
      
      if (response.ok) {
        await fetchRecords()
        setFormData({ eggs_produced: '', laying_rate: '', mortality_count: '' })
        setOpen(false)
      }
    } catch (error) {
      console.error('[v0] Error adding record:', error)
    }
  }

  async function handleDelete(id: string) {
    if (!confirm('Apagar este registro?')) return
    
    try {
      const response = await fetch(`/api/production/${id}`, {
        method: 'DELETE'
      })
      
      if (response.ok) {
        await fetchRecords()
      }
    } catch (error) {
      console.error('[v0] Error deleting record:', error)
    }
  }

  // Filter by date if selected
  const filteredRecords = dateFilter
    ? records.filter(r => r.record_date === dateFilter)
    : records

  const chartData = filteredRecords.slice().reverse().map((r) => ({
    date: new Date(r.record_date).toLocaleDateString('pt-BR', { month: '2-digit', day: '2-digit' }),
    ovos: r.eggs_produced,
    taxa: r.laying_rate,
  }))

  const totalEggs = filteredRecords.reduce((sum, r) => sum + r.eggs_produced, 0)
  const avgRate = filteredRecords.length > 0 
    ? (filteredRecords.reduce((sum, r) => sum + r.laying_rate, 0) / filteredRecords.length).toFixed(2)
    : '0.00'
  const avgMortality = filteredRecords.length > 0
    ? (filteredRecords.reduce((sum, r) => sum + r.mortality_count, 0) / filteredRecords.length).toFixed(0)
    : '0'

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Produção - Poedeiras</h1>
          <p className="text-gray-600 mt-2">Registre a produção de ovos</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button>+ Registrar Produção</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Registrar Produção de Ovos</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Lote</label>
                <select
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  value={formData.batch}
                  onChange={(e) => setFormData({ ...formData, batch: e.target.value })}
                >
                  <option value="">Selecionar lote</option>
                  <option value="Lote Postura 001">Lote Postura 001</option>
                  <option value="Lote Postura 002">Lote Postura 002</option>
                </select>
              </div>
              <div>
                <label className="text-sm font-medium">Total de Ovos</label>
                <Input
                  type="number"
                  placeholder="4850"
                  value={formData.totalEggs}
                  onChange={(e) => setFormData({ ...formData, totalEggs: e.target.value })}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Tamanho do Lote</label>
                <Input
                  type="number"
                  placeholder="5000"
                  value={formData.batchSize}
                  onChange={(e) => setFormData({ ...formData, batchSize: e.target.value })}
                />
              </div>
              <Button onClick={handleAdd} className="w-full">Registrar</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Total de Ovos</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-600">{totalEggs.toLocaleString()}</div>
            <p className="text-sm text-gray-600 mt-1">últimos {records.length} dias</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Taxa Média</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">{avgRate}%</div>
            <p className="text-sm text-gray-600 mt-1">postura média</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Hoje</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-purple-600">{records[0]?.totalEggs.toLocaleString() || 0}</div>
            <p className="text-sm text-gray-600 mt-1">taxa: {records[0]?.rate || 0}%</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Produção e Taxa de Postura</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis yAxisId="left" />
              <YAxis yAxisId="right" orientation="right" />
              <Tooltip />
              <Legend />
              <Line yAxisId="left" type="monotone" dataKey="ovos" stroke="#3b82f6" name="Ovos" />
              <Line yAxisId="right" type="monotone" dataKey="taxa" stroke="#10b981" name="Taxa (%)" />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Histórico de Produção</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-100 border-b">
                <tr>
                  <th className="text-left px-4 py-2">Data</th>
                  <th className="text-left px-4 py-2">Lote</th>
                  <th className="text-right px-4 py-2">Ovos Produzidos</th>
                  <th className="text-right px-4 py-2">Tamanho Lote</th>
                  <th className="text-right px-4 py-2">Taxa Postura</th>
                </tr>
              </thead>
              <tbody>
                {records.map((record) => (
                  <tr key={record.id} className="border-b hover:bg-gray-50">
                    <td className="px-4 py-2">{new Date(record.date).toLocaleDateString('pt-BR')}</td>
                    <td className="px-4 py-2 font-medium">{record.batch}</td>
                    <td className="px-4 py-2 text-right font-semibold text-blue-600">{record.totalEggs}</td>
                    <td className="px-4 py-2 text-right">{record.batchSize}</td>
                    <td className="px-4 py-2 text-right font-semibold text-green-600">{record.rate}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
