'use client'

import Link from 'next/link'
import { ArrowLeft, Plus } from 'lucide-react'

export default function ProductionPage() {
  const submodules = [
    { title: 'Poedeiras', description: 'Produção de ovos', href: '/modules/production/layers', icon: '🐔' },
    { title: 'Corte', description: 'Ganho de peso', href: '/modules/production/broilers', icon: '🍗' },
    { title: 'Classificação', description: 'Classes de produtos', href: '/modules/production/classification', icon: '📊' },
    { title: 'Taxa Postura', description: 'Indicadores produção', href: '/modules/production/laying-rate', icon: '📈' },
  ]

  return (
    <div className="w-full font-montserrat">
      <div className="mb-8 flex items-start justify-between">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <Link href="/dashboard" className="p-1 hover:bg-gray-100 rounded transition-colors">
              <ArrowLeft className="w-5 h-5 text-gray-600" />
            </Link>
            <span className="text-3xl">📊</span>
          </div>
          <h1 className="text-2xl font-montserrat font-bold text-gray-900">Produção</h1>
          <p className="text-gray-600 text-sm mt-1">Registre e acompanhe a produção das suas aves</p>
        </div>
        <button className="px-4 py-2 bg-[#22C55E] text-white rounded hover:bg-[#16a34a] transition-colors font-montserrat font-semibold text-sm flex items-center gap-2">
          <Plus className="w-4 h-4" /> Novo
        </button>
      </div>
      <div className="grid grid-cols-4 gap-4">
        {submodules.map((m) => (
          <Link key={m.href} href={m.href} className="group">
            <div className="bg-white border border-gray-200 rounded-lg p-5 hover:shadow-md hover:border-[#22C55E] transition-all h-full flex flex-col items-center text-center">
              <div className="text-5xl mb-3">{m.icon}</div>
              <h3 className="font-montserrat font-semibold text-gray-900 text-xs mb-1 leading-tight">{m.title}</h3>
              <p className="text-xs text-gray-500 font-montserrat leading-tight">{m.description}</p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  )
}
