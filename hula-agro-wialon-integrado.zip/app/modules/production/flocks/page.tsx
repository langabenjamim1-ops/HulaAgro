'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Plus, Calendar, Users, TrendingUp, AlertCircle } from 'lucide-react'

interface Flock {
  id: string
  name: string
  startDate: string
  birds: number
  birdType: 'broiler' | 'layer' | 'other'
  status: 'active' | 'planning' | 'completed'
  mortality: number
  healthStatus: 'good' | 'warning' | 'critical'
}

export default function FlocksPage() {
  const [flocks, setFlocks] = useState<Flock[]>([
    {
      id: 'HLA-2026-01',
      name: 'Lote 01 - Frangos de Corte',
      startDate: '2026-01-15',
      birds: 5000,
      birdType: 'broiler',
      status: 'active',
      mortality: 125,
      healthStatus: 'good'
    },
    {
      id: 'HLA-2026-02',
      name: 'Lote 02 - Frangos de Corte',
      startDate: '2026-01-22',
      birds: 4800,
      birdType: 'broiler',
      status: 'active',
      mortality: 85,
      healthStatus: 'good'
    },
    {
      id: 'HLA-2026-03',
      name: 'Lote 03 - Poedeiras',
      startDate: '2025-11-10',
      birds: 3200,
      birdType: 'layer',
      status: 'active',
      mortality: 32,
      healthStatus: 'warning'
    }
  ])

  const getStatusColor = (status: string) => {
    switch(status) {
      case 'active': return 'bg-green-100 text-green-800'
      case 'planning': return 'bg-blue-100 text-blue-800'
      case 'completed': return 'bg-gray-100 text-gray-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const getHealthIcon = (health: string) => {
    switch(health) {
      case 'good': return '✓'
      case 'warning': return '⚠️'
      case 'critical': return '🔴'
      default: return '−'
    }
  }

  const mortalityRate = (mortality: number, birds: number) => {
    return ((mortality / birds) * 100).toFixed(2)
  }

  const getDaysInFlock = (startDate: string) => {
    const start = new Date(startDate)
    const today = new Date()
    const days = Math.floor((today.getTime() - start.getTime()) / (1000 * 60 * 60 * 24))
    return days
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-[#283106]">Gerenciamento de Lotes</h1>
          <p className="text-[#6b7d3f] mt-1">Acompanhe todos os seus lotes em produção</p>
        </div>
        <button className="bg-[#283106] text-white px-4 py-2 rounded-lg hover:bg-[#3D4A2C] flex items-center gap-2">
          <Plus className="w-5 h-5" />
          Novo Lote
        </button>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="text-sm text-[#6b7d3f]">Lotes Ativos</div>
            <div className="text-3xl font-bold text-[#283106] mt-2">{flocks.filter(f => f.status === 'active').length}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="text-sm text-[#6b7d3f]">Total de Aves</div>
            <div className="text-3xl font-bold text-[#283106] mt-2">
              {flocks.reduce((sum, f) => sum + f.birds, 0).toLocaleString('pt-BR')}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="text-sm text-[#6b7d3f]">Mortalidade Total</div>
            <div className="text-3xl font-bold text-red-600 mt-2">
              {flocks.reduce((sum, f) => sum + f.mortality, 0)}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="text-sm text-[#6b7d3f]">Taxa Média</div>
            <div className="text-3xl font-bold text-orange-600 mt-2">
              {(flocks.reduce((sum, f) => sum + ((f.mortality / f.birds) * 100), 0) / flocks.length).toFixed(2)}%
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Flocks List */}
      <div className="space-y-4">
        {flocks.map((flock) => (
          <Card key={flock.id} className="hover:shadow-md transition-shadow cursor-pointer">
            <CardHeader className="pb-3 border-b border-[#E8E8E8]">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3">
                    <CardTitle className="text-lg text-[#283106]">{flock.name}</CardTitle>
                    <span className={`text-xs font-semibold px-2 py-1 rounded-full ${getStatusColor(flock.status)}`}>
                      {flock.status === 'active' ? 'Ativo' : 'Planejado'}
                    </span>
                  </div>
                  <p className="text-sm text-[#6b7d3f] mt-1">ID: {flock.id}</p>
                </div>
                <div className="text-right">
                  <div className="text-2xl">{getHealthIcon(flock.healthStatus)}</div>
                  <p className="text-xs text-[#6b7d3f]">
                    {flock.healthStatus === 'good' ? 'Saudável' : flock.healthStatus === 'warning' ? 'Atenção' : 'Crítico'}
                  </p>
                </div>
              </div>
            </CardHeader>

            <CardContent className="pt-6">
              <div className="grid grid-cols-2 md:grid-cols-5 gap-6">
                {/* Days */}
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Calendar className="w-4 h-4 text-[#6b7d3f]" />
                    <span className="text-xs text-[#6b7d3f]">Dias</span>
                  </div>
                  <p className="text-2xl font-bold text-[#283106]">{getDaysInFlock(flock.startDate)}</p>
                </div>

                {/* Birds */}
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Users className="w-4 h-4 text-[#6b7d3f]" />
                    <span className="text-xs text-[#6b7d3f]">Aves</span>
                  </div>
                  <p className="text-2xl font-bold text-[#283106]">{flock.birds.toLocaleString('pt-BR')}</p>
                </div>

                {/* Mortality */}
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <AlertCircle className="w-4 h-4 text-red-600" />
                    <span className="text-xs text-[#6b7d3f]">Mortas</span>
                  </div>
                  <p className="text-2xl font-bold text-red-600">{flock.mortality}</p>
                  <p className="text-xs text-gray-500">{mortalityRate(flock.mortality, flock.birds)}%</p>
                </div>

                {/* Type */}
                <div>
                  <span className="text-xs text-[#6b7d3f]">Tipo</span>
                  <p className="text-lg font-bold text-[#283106] mt-1">
                    {flock.birdType === 'broiler' ? 'Corte' : 'Postura'}
                  </p>
                </div>

                {/* Action */}
                <div>
                  <span className="text-xs text-[#6b7d3f]">Ação</span>
                  <button className="text-sm font-bold text-[#283106] hover:text-[#3D4A2C] mt-1">
                    Detalhes →
                  </button>
                </div>
              </div>

              {/* Health Warning */}
              {flock.healthStatus === 'warning' && (
                <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <p className="text-sm text-yellow-800">
                    ⚠️ Este lote requer atenção. Verifique com seu assistente de IA para recomendações.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* AI Recommendation */}
      <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
        <CardContent className="pt-6">
          <p className="text-sm font-semibold text-[#283106] mb-2">💡 Dica: Use o Assistente de IA</p>
          <p className="text-sm text-[#6b7d3f]">
            Abra o assistente de IA (💬) e faça perguntas como "Qual lote tem melhor taxa de crescimento?" 
            ou "Por que a mortalidade aumentou no lote 03?" para obter análises detalhadas baseadas em dados reais.
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
