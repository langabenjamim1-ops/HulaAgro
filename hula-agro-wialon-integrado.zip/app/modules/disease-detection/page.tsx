'use client'

import { useState, useRef, useEffect } from 'react'
import Link from 'next/link'
import { ArrowLeft, Camera, AlertTriangle, CheckCircle, RotateCcw } from 'lucide-react'

interface Detection {
  disease: string
  confidence: number
  severity: 'low' | 'medium' | 'high'
  affected_birds: number
  recommendations: string[]
  timestamp: string
}

export default function DiseaseDetectionPage() {
  const [cameraActive, setCameraActive] = useState(false)
  const [detections, setDetections] = useState<Detection[]>([])
  const [isScanning, setIsScanning] = useState(false)
  const [capturedImage, setCapturedImage] = useState<string | null>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    if (cameraActive && videoRef.current) {
      navigator.mediaDevices.getUserMedia({ video: true })
        .then(stream => {
          if (videoRef.current) {
            videoRef.current.srcObject = stream
          }
        })
        .catch(error => console.error('[v0] Camera error:', error))
    }
  }, [cameraActive])

  async function captureAndAnalyze() {
    if (!videoRef.current || !canvasRef.current) return

    setIsScanning(true)
    try {
      const context = canvasRef.current.getContext('2d')
      if (context && videoRef.current.videoWidth > 0) {
        context.drawImage(videoRef.current, 0, 0, canvasRef.current.width, canvasRef.current.height)
        const imageData = canvasRef.current.toDataURL('image/jpeg')
        setCapturedImage(imageData)

        // Simular análise YOLOv8
        const mockDetections: Detection[] = [
          {
            disease: 'Bronquite Infecciosa',
            confidence: 87,
            severity: 'medium',
            affected_birds: 8,
            recommendations: [
              'Isolar aves afetadas',
              'Aumentar ventilação',
              'Consultar veterinário',
            ],
            timestamp: new Date().toISOString(),
          },
          {
            disease: 'Postura Normal',
            confidence: 92,
            severity: 'low',
            affected_birds: 0,
            recommendations: ['Manter condições atuais'],
            timestamp: new Date().toISOString(),
          },
        ]

        setDetections(mockDetections)
      }
    } catch (error) {
      console.error('[v0] Analysis error:', error)
    } finally {
      setIsScanning(false)
    }
  }

  const commonDiseases = [
    {
      name: 'Bronquite Infecciosa',
      symptoms: 'Tosse, espirro, descarga nasal',
      detection: 'YOLOv8 pode detectar alterações respiratórias',
      icon: '🫁',
    },
    {
      name: 'Newcastle',
      symptoms: 'Tremores, paralisia, torção de cabeça',
      detection: 'Detecta comportamento anormal',
      icon: '🧠',
    },
    {
      name: 'Gota Aviária',
      symptoms: 'Edema em patas, articulações dilatadas',
      detection: 'Analisa inchação e deformidade',
      icon: '🦵',
    },
    {
      name: 'Salmonelose',
      symptoms: 'Diarreia, apatia, perda de apetite',
      detection: 'Comportamento e condição corporal',
      icon: '🤒',
    },
  ]

  return (
    <div className="w-full min-h-screen bg-gradient-to-b from-red-50 to-white font-montserrat">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center gap-3">
          <Link href="/dashboard" className="p-1 hover:bg-gray-100 rounded transition-colors">
            <ArrowLeft className="w-5 h-5 text-gray-600" />
          </Link>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Detecção de Doenças (YOLOv8)</h1>
            <p className="text-sm text-gray-600">Visão computacional em tempo real para monitoramento de saúde</p>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-8 space-y-8">
        {/* Camera Section */}
        <div className="grid md:grid-cols-2 gap-6">
          {/* Video Feed */}
          <div className="bg-black rounded-lg overflow-hidden relative aspect-video">
            {!cameraActive ? (
              <div className="w-full h-full flex flex-col items-center justify-center bg-gray-900 text-white">
                <Camera className="w-12 h-12 mb-3 opacity-50" />
                <p className="text-gray-400 mb-4">Câmera desativa</p>
                <button
                  onClick={() => setCameraActive(true)}
                  className="px-6 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
                >
                  Ativar Câmera
                </button>
              </div>
            ) : (
              <>
                <video
                  ref={videoRef}
                  className="w-full h-full object-cover"
                  autoPlay
                  playsInline
                />
                <canvas
                  ref={canvasRef}
                  width={640}
                  height={480}
                  style={{ display: 'none' }}
                />
              </>
            )}
          </div>

          {/* Captured Image & Results */}
          {capturedImage && (
            <div className="bg-white rounded-lg border border-gray-200 p-4">
              <img src={capturedImage} alt="Captured" className="w-full rounded-lg mb-4" />
              <button
                onClick={() => {
                  setCapturedImage(null)
                  setDetections([])
                }}
                className="w-full px-4 py-2 bg-gray-300 text-gray-900 rounded-lg hover:bg-gray-400 flex items-center gap-2 justify-center"
              >
                <RotateCcw className="w-4 h-4" />
                Capturar Novamente
              </button>
            </div>
          )}
        </div>

        {/* Analysis Button */}
        {cameraActive && !isScanning && (
          <button
            onClick={captureAndAnalyze}
            className="w-full md:w-64 mx-auto block px-6 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 font-bold flex items-center gap-2 justify-center"
          >
            <Camera className="w-5 h-5" />
            Analisar com YOLOv8
          </button>
        )}

        {isScanning && (
          <div className="text-center py-6">
            <div className="inline-block">
              <div className="w-8 h-8 border-4 border-red-200 border-t-red-600 rounded-full animate-spin" />
              <p className="text-gray-600 mt-2">Analisando imagem...</p>
            </div>
          </div>
        )}

        {/* Detection Results */}
        {detections.length > 0 && (
          <div className="space-y-4">
            <h2 className="text-xl font-bold text-gray-900">Resultados da Análise</h2>
            {detections.map((detection, i) => (
              <div
                key={i}
                className={`p-4 rounded-lg border-l-4 ${
                  detection.severity === 'high'
                    ? 'bg-red-50 border-red-500'
                    : detection.severity === 'medium'
                    ? 'bg-yellow-50 border-yellow-500'
                    : 'bg-green-50 border-green-500'
                }`}
              >
                <div className="flex items-start gap-3">
                  {detection.severity === 'high' && <AlertTriangle className="w-5 h-5 text-red-600 mt-0.5" />}
                  {detection.severity === 'low' && <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />}
                  {detection.severity === 'medium' && <AlertTriangle className="w-5 h-5 text-yellow-600 mt-0.5" />}
                  <div className="flex-1">
                    <h3 className="font-bold text-gray-900">{detection.disease}</h3>
                    <p className="text-sm text-gray-700 mt-1">
                      Confiança: <span className="font-bold text-lg">{detection.confidence}%</span>
                    </p>
                    {detection.affected_birds > 0 && (
                      <p className="text-sm text-gray-700 mt-1">
                        Aves Potencialmente Afetadas: <span className="font-bold">{detection.affected_birds}</span>
                      </p>
                    )}
                    <div className="mt-3">
                      <p className="text-xs font-semibold text-gray-600 mb-2">Recomendações:</p>
                      <ul className="text-sm space-y-1">
                        {detection.recommendations.map((rec, j) => (
                          <li key={j} className="text-gray-700">• {rec}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Common Diseases Reference */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Doenças Detectáveis pelo Sistema</h2>
          <div className="grid md:grid-cols-2 gap-4">
            {commonDiseases.map((disease, i) => (
              <div key={i} className="p-4 bg-gray-50 rounded-lg border border-gray-200">
                <div className="text-3xl mb-2">{disease.icon}</div>
                <h3 className="font-bold text-gray-900">{disease.name}</h3>
                <p className="text-xs text-gray-600 mt-2">
                  <span className="font-semibold">Sintomas:</span> {disease.symptoms}
                </p>
                <p className="text-xs text-gray-600 mt-2">
                  <span className="font-semibold">Detecção:</span> {disease.detection}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
