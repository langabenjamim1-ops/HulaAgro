'use client'

import { ChevronLeft } from 'lucide-react'
import Link from 'next/link'
import { Card, CardContent } from '@/components/ui/card'

const feedConsumption = [
  { batch: 'Lote 001', ration: 'Premium Plus', consumed: 2.850, per_bird: 125, cost: 'R$ 1.710' },
  { batch: 'Lote 002', ration: 'Padrão', consumed: 2.650, per_bird: 121, cost: 'R$ 1.325' },
  { batch: 'Lote 003', ration: 'Premium Plus', consumed: 2.920, per_bird: 128, cost: 'R$ 1.752' },
]

export default function FeedConsumptionPage() {
  return (
    <div className="space-y-8">
      <div>
        <Link href="/modules/production-analysis" className="text-green-600 hover:text-green-700 flex items-center gap-2 mb-4">
          <ChevronLeft className="w-4 h-4" /> Voltar
        </Link>
        <h1 className="text-3xl font-bold text-gray-900">Consumo de Ração</h1>
        <p className="text-gray-600 mt-2">Análise de consumo por lote e ração</p>
      </div>

      <div className="overflow-x-auto bg-white rounded-lg border border-green-200">
        <table className="w-full">
          <thead className="bg-green-50 border-b border-green-200">
            <tr>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Lote</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Ração</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Consumo Total</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Por Ave</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Custo</th>
            </tr>
          </thead>
          <tbody>
            {feedConsumption.map((item, idx) => (
              <tr key={idx} className="border-b border-green-100 hover:bg-green-50">
                <td className="px-6 py-4 text-sm text-gray-900">{item.batch}</td>
                <td className="px-6 py-4 text-sm text-gray-600">{item.ration}</td>
                <td className="px-6 py-4 text-sm text-gray-600">{item.consumed} kg</td>
                <td className="px-6 py-4 text-sm text-gray-600">{item.per_bird} g</td>
                <td className="px-6 py-4 text-sm font-semibold text-gray-900">{item.cost}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
