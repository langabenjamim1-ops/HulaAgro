'use client'

import { ChevronLeft } from 'lucide-react'
import Link from 'next/link'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'

const reports = [
  { id: 1, name: 'Relatório Semanal - Fevereiro', date: '2024-02-05', type: 'PDF', size: '2.5 MB' },
  { id: 2, name: 'Análise Mensal - Janeiro', date: '2024-02-01', type: 'Excel', size: '1.2 MB' },
  { id: 3, name: 'Comparativo Lotes', date: '2024-01-28', type: 'PDF', size: '3.1 MB' },
]

export default function ReportsPage() {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <Link href="/modules/production-analysis" className="text-green-600 hover:text-green-700 flex items-center gap-2 mb-4">
            <ChevronLeft className="w-4 h-4" /> Voltar
          </Link>
          <h1 className="text-3xl font-bold text-gray-900">Relatórios</h1>
          <p className="text-gray-600 mt-2">Geração e histórico de relatórios</p>
        </div>
        <Button className="bg-green-600 hover:bg-green-700">+ Gerar Relatório</Button>
      </div>

      <div className="space-y-4">
        {reports.map((report) => (
          <Card key={report.id} className="bg-white border-green-200">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-gray-900">{report.name}</h3>
                  <p className="text-sm text-gray-600 mt-2">{report.date} • {report.type} • {report.size}</p>
                </div>
                <Button variant="outline" size="sm">Baixar</Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
