'use client'

import { ChevronLeft } from 'lucide-react'
import Link from 'next/link'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'

const timeBank = [
  { id: 1, employee: 'João Silva', hoursWorked: 160, hoursUsed: 8, balance: '+8h', status: 'Positivo' },
  { id: 2, employee: 'Maria Santos', hoursWorked: 165, hoursUsed: 0, balance: '+16.5h', status: 'Positivo' },
  { id: 3, employee: 'Pedro Oliveira', hoursWorked: 158, hoursUsed: 6, balance: '-8h', status: 'Negativo' },
  { id: 4, employee: 'Ana Costa', hoursWorked: 120, hoursUsed: 40, balance: 'Equilibrado', status: 'Equilibrado' },
]

export default function TimeBankPage() {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <Link href="/modules/hr" className="text-green-600 hover:text-green-700 flex items-center gap-2 mb-4">
            <ChevronLeft className="w-4 h-4" /> Voltar
          </Link>
          <h1 className="text-3xl font-bold text-gray-900">Banco de Horas</h1>
          <p className="text-gray-600 mt-2">Controle de horas extras e compensação</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {timeBank.map((record) => (
          <Card key={record.id} className="bg-white border-green-200">
            <CardContent className="pt-6">
              <h3 className="font-semibold text-gray-900">{record.employee}</h3>
              <div className="mt-4 space-y-2">
                <p className="text-sm text-gray-600">Horas Trabalhadas: <span className="font-semibold text-gray-900">{record.hoursWorked}h</span></p>
                <p className="text-sm text-gray-600">Horas Usadas: <span className="font-semibold text-gray-900">{record.hoursUsed}h</span></p>
                <div className="pt-2 border-t border-green-200">
                  <p className="text-sm text-gray-600">Saldo</p>
                  <p className={`text-xl font-bold ${
                    record.status === 'Positivo' ? 'text-green-600' :
                    record.status === 'Negativo' ? 'text-red-600' :
                    'text-blue-600'
                  }`}>
                    {record.balance}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
