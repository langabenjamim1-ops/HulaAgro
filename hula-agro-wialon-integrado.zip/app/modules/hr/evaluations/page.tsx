'use client'

import { ChevronLeft } from 'lucide-react'
import Link from 'next/link'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'

const evaluationsData = [
  { id: 1, employee: 'João Silva', date: '2024-01-15', rating: 4.5, reviewer: 'Diretoria', status: 'Completa' },
  { id: 2, employee: 'Maria Santos', date: '2024-01-20', rating: 4.8, reviewer: 'Gerência', status: 'Completa' },
  { id: 3, employee: 'Pedro Oliveira', date: '2024-02-01', rating: 4.0, reviewer: 'Gerência', status: 'Pendente' },
]

export default function EvaluationsPage() {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <Link href="/modules/hr" className="text-green-600 hover:text-green-700 flex items-center gap-2 mb-4">
            <ChevronLeft className="w-4 h-4" /> Voltar
          </Link>
          <h1 className="text-3xl font-bold text-gray-900">Avaliações</h1>
          <p className="text-gray-600 mt-2">Sistema de avaliações de desempenho</p>
        </div>
        <Button className="bg-green-600 hover:bg-green-700">+ Nova Avaliação</Button>
      </div>

      <div className="space-y-4">
        {evaluationsData.map((evaluation) => (
          <Card key={evaluation.id} className="bg-white border-green-200">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-gray-900">{evaluation.employee}</h3>
                  <p className="text-sm text-gray-600 mt-2">Data: {evaluation.date} • Avaliador: {evaluation.reviewer}</p>
                </div>
                <div className="flex items-center gap-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">{evaluation.rating}</div>
                    <p className="text-xs text-gray-600">{'⭐'.repeat(Math.round(evaluation.rating))}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${evaluation.status === 'Completa' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>
                      {evaluation.status}
                    </span>
                    <Button variant="outline" size="sm">Ver</Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
