'use client'

import { ChevronLeft } from 'lucide-react'
import Link from 'next/link'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'

const employees = [
  { id: 1, name: 'João Silva', position: 'Gerente Geral', department: 'Administração', startDate: '2021-01-15', status: 'Ativo' },
  { id: 2, name: 'Maria Santos', position: 'Zootecnista', department: 'Produção', startDate: '2020-06-20', status: 'Ativo' },
  { id: 3, name: 'Pedro Oliveira', position: 'Operador', department: 'Produção', startDate: '2022-03-10', status: 'Ativo' },
  { id: 4, name: 'Ana Costa', position: 'Técnica em Saúde', department: 'Saúde', startDate: '2021-09-05', status: 'Licença' },
]

export default function EmployeesPage() {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <Link href="/modules/hr" className="text-green-600 hover:text-green-700 flex items-center gap-2 mb-4">
            <ChevronLeft className="w-4 h-4" /> Voltar
          </Link>
          <h1 className="text-3xl font-bold text-gray-900">Gestão de Funcionários</h1>
          <p className="text-gray-600 mt-2">Cadastro e dados dos funcionários</p>
        </div>
        <Button className="bg-green-600 hover:bg-green-700">+ Novo Funcionário</Button>
      </div>

      <div className="space-y-4">
        {employees.map((emp) => (
          <Card key={emp.id} className="bg-white border-green-200">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-gray-900">{emp.name}</h3>
                  <p className="text-sm text-gray-600 mt-1">{emp.position} • {emp.department}</p>
                  <p className="text-xs text-gray-500 mt-2">Desde: {emp.startDate}</p>
                </div>
                <div className="flex items-center gap-4">
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${emp.status === 'Ativo' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>
                    {emp.status}
                  </span>
                  <Button variant="outline" size="sm">Detalhes</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
