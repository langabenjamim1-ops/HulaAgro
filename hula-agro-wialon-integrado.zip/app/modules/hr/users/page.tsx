'use client'

import { ChevronLeft } from 'lucide-react'
import Link from 'next/link'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'

const users = [
  { id: 1, name: 'João Silva', email: 'joao@hula.com', role: 'Administrador', status: 'Ativo', lastLogin: '2024-02-05' },
  { id: 2, name: 'Maria Santos', email: 'maria@hula.com', role: 'Gerente', status: 'Ativo', lastLogin: '2024-02-04' },
  { id: 3, name: 'Pedro Oliveira', email: 'pedro@hula.com', role: 'Operador', status: 'Ativo', lastLogin: '2024-02-03' },
]

export default function UsersPage() {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <Link href="/modules/hr" className="text-green-600 hover:text-green-700 flex items-center gap-2 mb-4">
            <ChevronLeft className="w-4 h-4" /> Voltar
          </Link>
          <h1 className="text-3xl font-bold text-gray-900">Usuários da Empresa</h1>
          <p className="text-gray-600 mt-2">Gestão de acesso e permissões</p>
        </div>
        <Button className="bg-green-600 hover:bg-green-700">+ Novo Usuário</Button>
      </div>

      <div className="overflow-x-auto bg-white rounded-lg border border-green-200">
        <table className="w-full">
          <thead className="bg-green-50 border-b border-green-200">
            <tr>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Nome</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Email</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Função</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Status</th>
              <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Último Acesso</th>
              <th className="px-6 py-3 text-right text-sm font-semibold text-gray-900">Ações</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user) => (
              <tr key={user.id} className="border-b border-green-100 hover:bg-green-50">
                <td className="px-6 py-4 text-sm text-gray-900">{user.name}</td>
                <td className="px-6 py-4 text-sm text-gray-600">{user.email}</td>
                <td className="px-6 py-4 text-sm text-gray-600">{user.role}</td>
                <td className="px-6 py-4"><span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">{user.status}</span></td>
                <td className="px-6 py-4 text-sm text-gray-600">{user.lastLogin}</td>
                <td className="px-6 py-4 text-right text-sm"><Button variant="outline" size="sm">Editar</Button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
