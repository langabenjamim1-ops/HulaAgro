'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { ArrowLeft, TrendingUp, AlertTriangle, CheckCircle } from 'lucide-react'
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'

interface Prediction {
  date: string
  metric: string
  predicted_value: number
  confidence: number
  actual_value?: number
  trend: 'up' | 'down' | 'stable'
}

export default function AIPredictionsPage() {
  const [predictions, setPredictions] = useState<Prediction[]>([])
  const [selectedMetric, setSelectedMetric] = useState('mortality')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchPredictions()
  }, [selectedMetric])

  async function fetchPredictions() {
    try {
      setLoading(true)
      // Simulando dados de predição baseado em histórico
      const mockPredictions: Prediction[] = [
        { date: '2026-04-17', metric: 'mortality', predicted_value: 2.1, confidence: 92, actual_value: 2.0, trend: 'down' },
        { date: '2026-04-18', metric: 'mortality', predicted_value: 2.3, confidence: 88, trend: 'up' },
        { date: '2026-04-19', metric: 'mortality', predicted_value: 2.2, confidence: 85, trend: 'stable' },
        { date: '2026-04-20', metric: 'feed_consumption', predicted_value: 128.5, confidence: 89, trend: 'down' },
        { date: '2026-04-21', metric: 'feed_consumption', predicted_value: 130.2, confidence: 91, trend: 'up' },
        { date: '2026-04-22', metric: 'growth', predicted_value: 2150, confidence: 94, trend: 'up' },
      ]
      setPredictions(mockPredictions.filter(p => p.metric === selectedMetric))
    } catch (error) {
      console.error('[v0] Error fetching predictions:', error)
    } finally {
      setLoading(false)
    }
  }

  const predictions_by_metric = [
    { id: 'mortality', name: 'Mortalidade (%)', icon: '💀', unit: '%', color: '#EF4444' },
    { id: 'feed_consumption', name: 'Consumo de Ração (g/ave)', icon: '🌾', unit: 'g', color: '#F59E0B' },
    { id: 'growth', name: 'Crescimento (g)', icon: '📈', unit: 'g', color: '#10B981' },
    { id: 'laying_rate', name: 'Taxa de Postura (%)', icon: '🥚', unit: '%', color: '#3B82F6' },
  ]

  const selectedMetricData = predictions_by_metric.find(m => m.id === selectedMetric)

  // Simular dados para gráfico
  const chartData = [
    { date: '11 Apr', predicted: 2.1, actual: 2.0, confidence: 92 },
    { date: '12 Apr', predicted: 2.3, actual: 2.2, confidence: 88 },
    { date: '13 Apr', predicted: 2.2, actual: 2.3, confidence: 85 },
    { date: '14 Apr', predicted: 2.0, actual: 1.9, confidence: 89 },
    { date: '15 Apr', predicted: 1.8, actual: 1.7, confidence: 91 },
    { date: '16 Apr', predicted: 1.7, actual: null, confidence: 94 },
    { date: '17 Apr', predicted: 1.6, actual: null, confidence: 92 },
  ]

  const alerts = [
    { severity: 'warning', message: 'Risco de aumentar mortalidade em 48h se temperatura cair abaixo de 22°C' },
    { severity: 'info', message: 'Consumo de ração pode reduzir 5-8% com redução de umidade' },
    { severity: 'success', message: 'Condições ideais previstas para postura nos próximos 3 dias' },
  ]

  return (
    <div className="w-full min-h-screen bg-gradient-to-b from-blue-50 to-white font-montserrat">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center gap-3">
          <Link href="/dashboard" className="p-1 hover:bg-gray-100 rounded transition-colors">
            <ArrowLeft className="w-5 h-5 text-gray-600" />
          </Link>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Previsões Inteligentes (ML)</h1>
            <p className="text-sm text-gray-600">Análise preditiva baseada em histórico de dados</p>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
        {/* Metric Selection */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {predictions_by_metric.map(metric => (
            <button
              key={metric.id}
              onClick={() => setSelectedMetric(metric.id)}
              className={`p-4 rounded-lg border-2 transition-all text-left ${
                selectedMetric === metric.id
                  ? 'border-blue-500 bg-blue-50'
                  : 'border-gray-200 bg-white hover:border-gray-300'
              }`}
            >
              <div className="text-3xl mb-2">{metric.icon}</div>
              <h3 className="font-bold text-gray-900">{metric.name}</h3>
              <p className="text-xs text-gray-600 mt-1">Unidade: {metric.unit}</p>
            </button>
          ))}
        </div>

        {/* Alerts */}
        <div className="space-y-3">
          {alerts.map((alert, i) => (
            <div
              key={i}
              className={`p-4 rounded-lg border-l-4 ${
                alert.severity === 'warning'
                  ? 'bg-yellow-50 border-yellow-500'
                  : alert.severity === 'info'
                  ? 'bg-blue-50 border-blue-500'
                  : 'bg-green-50 border-green-500'
              }`}
            >
              <div className="flex items-start gap-3">
                {alert.severity === 'warning' && <AlertTriangle className="w-5 h-5 text-yellow-600 mt-0.5" />}
                {alert.severity === 'success' && <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />}
                {alert.severity === 'info' && <TrendingUp className="w-5 h-5 text-blue-600 mt-0.5" />}
                <p className="text-sm text-gray-800">{alert.message}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Prediction Chart */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h2 className="text-lg font-bold text-gray-900 mb-6">Previsão vs Real - Últimos 7 dias</h2>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="predicted" stroke="#3B82F6" strokeWidth={2} name="Previsto" />
              <Line type="monotone" dataKey="actual" stroke="#10B981" strokeWidth={2} name="Real" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Confidence Chart */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h2 className="text-lg font-bold text-gray-900 mb-6">Índice de Confiança das Predições</h2>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis domain={[0, 100]} />
              <Tooltip formatter={(value) => `${value}%`} />
              <Bar dataKey="confidence" fill="#6366F1" name="Confiança (%)" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Predictions Table */}
        <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="px-6 py-3 text-left font-semibold text-gray-700">Data</th>
                <th className="px-6 py-3 text-left font-semibold text-gray-700">Previsto</th>
                <th className="px-6 py-3 text-left font-semibold text-gray-700">Real</th>
                <th className="px-6 py-3 text-left font-semibold text-gray-700">Confiança</th>
                <th className="px-6 py-3 text-left font-semibold text-gray-700">Tendência</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {predictions.map((pred, i) => (
                <tr key={i} className="hover:bg-gray-50">
                  <td className="px-6 py-3 text-sm">{new Date(pred.date).toLocaleDateString('pt-MZ')}</td>
                  <td className="px-6 py-3 font-bold">{pred.predicted_value.toFixed(2)} {selectedMetricData?.unit}</td>
                  <td className="px-6 py-3">
                    {pred.actual_value !== undefined ? `${pred.actual_value.toFixed(2)} ${selectedMetricData?.unit}` : 'Aguardando'}
                  </td>
                  <td className="px-6 py-3">
                    <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                      pred.confidence >= 90 ? 'bg-green-100 text-green-800' :
                      pred.confidence >= 80 ? 'bg-yellow-100 text-yellow-800' :
                      'bg-red-100 text-red-800'
                    }`}>
                      {pred.confidence}%
                    </span>
                  </td>
                  <td className="px-6 py-3">
                    <span className={`text-lg ${
                      pred.trend === 'up' ? 'text-red-600' :
                      pred.trend === 'down' ? 'text-green-600' :
                      'text-gray-600'
                    }`}>
                      {pred.trend === 'up' ? '📈' : pred.trend === 'down' ? '📉' : '➡️'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
