'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { CheckCircle2 } from 'lucide-react'

const suggestions = [
  {
    id: '1',
    title: 'Aumentar Ventilação',
    description: 'A temperatura do galpão está 3.2°C acima do esperado. Aumentar a ventilação pode ajudar a normalizar a temperatura.',
    priority: 'alta',
    category: 'Ambiência',
    impact: 'Melhoria de 2-3% na taxa de postura',
    galpao: 'Galpão C',
    estimatedTime: '30 minutos',
    implemented: false,
  },
  {
    id: '2',
    title: 'Revisar Teor de Proteína',
    description: 'A conversão alimentar está acima do esperado (2.28 vs 2.10). Considere aumentar o teor de proteína da ração.',
    priority: 'alta',
    category: 'Nutrição',
    impact: 'Melhoria de 5-8% na conversão alimentar',
    galpao: 'Galpão A',
    estimatedTime: '3-5 dias',
    implemented: false,
  },
  {
    id: '3',
    title: 'Verificar Sistema de Bebedouro',
    description: 'O consumo de água está abaixo do esperado. Verifique se há entupimento ou falta de pressão.',
    priority: 'alta',
    category: 'Manejo',
    impact: 'Normalizar consumo de água',
    galpao: 'Galpão B',
    estimatedTime: '15 minutos',
    implemented: false,
  },
  {
    id: '4',
    title: 'Aumentar Frequência de Limpeza',
    description: 'A mortalidade está elevada (1.5% vs 0.8%). Aumentar a frequência de limpeza pode reduzir doenças.',
    priority: 'alta',
    category: 'Biossegurança',
    impact: 'Redução de 0.5-0.7% na mortalidade',
    galpao: 'Galpão D',
    estimatedTime: 'Imediato',
    implemented: false,
  },
  {
    id: '5',
    title: 'Ajustar Programa de Luz',
    description: 'Considere ajustar o programa de luz para 16h diárias para estimular a postura.',
    priority: 'média',
    category: 'Manejo',
    impact: 'Aumento de 1-2% na taxa de postura',
    galpao: 'Galpão A',
    estimatedTime: '1 dia',
    implemented: false,
  },
]

export default function SuggestionsPage() {
  const [implemented, setImplemented] = useState<string[]>([])

  const handleImplement = (id: string) => {
    setImplemented([...implemented, id])
  }

  const filteredSuggestions = suggestions.filter((s) => !implemented.includes(s.id))

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900">Sugestões de Ajuste</h1>
          <p className="text-gray-600 mt-2">Recomendações inteligentes para melhorar o desempenho da sua produção</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Total de Sugestões</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{suggestions.length}</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Pendentes</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-orange-600">{filteredSuggestions.length}</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Implementadas</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-green-600">{implemented.length}</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Alta Prioridade</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-red-600">
                {filteredSuggestions.filter((s) => s.priority === 'alta').length}
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-4">
          {filteredSuggestions.map((suggestion) => (
            <Card key={suggestion.id} className="border-2">
              <CardContent className="pt-6">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="font-semibold text-lg text-gray-900">{suggestion.title}</h3>
                      <Badge variant={suggestion.priority === 'alta' ? 'destructive' : 'secondary'}>
                        {suggestion.priority.toUpperCase()}
                      </Badge>
                    </div>
                    <p className="text-gray-600 text-sm mb-4">{suggestion.description}</p>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div>
                        <p className="text-xs text-gray-600">Categoria</p>
                        <p className="text-sm font-semibold text-gray-900">{suggestion.category}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-600">Galpão</p>
                        <p className="text-sm font-semibold text-gray-900">{suggestion.galpao}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-600">Tempo Estimado</p>
                        <p className="text-sm font-semibold text-gray-900">{suggestion.estimatedTime}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-600">Impacto Esperado</p>
                        <p className="text-sm font-semibold text-green-600">{suggestion.impact}</p>
                      </div>
                    </div>
                  </div>
                  <Button onClick={() => handleImplement(suggestion.id)} className="whitespace-nowrap">
                    Implementar
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredSuggestions.length === 0 && (
          <Card>
            <CardContent className="pt-6 text-center">
              <CheckCircle2 className="w-12 h-12 text-green-600 mx-auto mb-4" />
              <p className="text-gray-900 font-semibold">Parabéns!</p>
              <p className="text-gray-600">Todas as sugestões foram implementadas</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
