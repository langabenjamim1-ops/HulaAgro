'use client'

import { useState, useEffect } from 'react'
import { AlertTriangle, Loader } from 'lucide-react'

interface Alert {
  id: string
  title: string
  facility_name: string
  bird_count: number
  created_at: string
  required_action: string
  impact: string
  priority: string
}

export default function AlertasPage() {
  const [alerts, setAlerts] = useState<Alert[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchAlerts()
  }, [])

  async function fetchAlerts() {
    try {
      setLoading(true)
      const response = await fetch('/api/alerts?priority=critico')
      if (!response.ok) throw new Error('Failed to fetch')
      const data = await response.json()
      setAlerts(Array.isArray(data) ? data : [])
    } catch (error) {
      console.error('[v0] Fetch error:', error)
      setAlerts([])
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="p-8 bg-gray-50 min-h-screen">

      {/* Título */}
      <div className="mb-8">
        <h1 className="text-3xl font-semibold text-gray-900">
          Alertas & Monitoramento
        </h1>

        <p className="text-gray-500 mt-1">
          Monitoramento em tempo real da granja
        </p>
      </div>


      {/* Estatísticas */}
      <div className="grid grid-cols-3 gap-6 mb-10">

        <div className="bg-white p-6 rounded-xl shadow-sm border">
          <p className="text-sm text-gray-500">Alertas ativos</p>
          <h2 className="text-3xl font-bold text-red-600">{alerts.length}</h2>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border">
          <p className="text-sm text-gray-500">Aves afetadas</p>
          <h2 className="text-3xl font-bold text-gray-900">{alerts.reduce((sum, a) => sum + (a.bird_count || 0), 0).toLocaleString('pt-BR')}</h2>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border">
          <p className="text-sm text-gray-500">Status geral</p>
          <h2 className="text-3xl font-bold text-red-600">Crítico</h2>
        </div>

      </div>


      {/* Lista de alertas */}
      <div className="space-y-6">

        {loading ? (
          <div className="flex justify-center py-12">
            <Loader className="h-8 w-8 animate-spin text-red-600" />
          </div>
        ) : alerts.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-xl border">
            <p className="text-gray-500">Nenhum alerta crítico no momento</p>
          </div>
        ) : (
          alerts.map((alerta) => (

            <div
              key={alerta.id}
              className="bg-white rounded-xl shadow-sm border-l-4 border-red-500 p-6 hover:shadow-md transition"
            >

              {/* Cabeçalho */}
              <div className="flex justify-between items-start">

                <div>

                  <div className="flex items-center gap-2 text-red-600 font-medium text-sm">
                    <AlertTriangle size={18} />
                    Alerta detectado
                  </div>

                  <h2 className="text-xl font-semibold text-gray-900 mt-1">
                    {alerta.title}
                  </h2>

                  <p className="text-gray-500 mt-1">
                    {alerta.facility_name} • {alerta.bird_count} aves
                  </p>

                  <p className="text-sm text-gray-400 mt-1">
                    Detectado em {new Date(alerta.created_at).toLocaleDateString('pt-BR')} às {new Date(alerta.created_at).toLocaleTimeString('pt-BR')}
                  </p>

                </div>


                {/* Botão */}
                <button className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-md text-sm font-medium transition">
                  Resolver alerta
                </button>

              </div>


              {/* Informações */}
              <div className="grid grid-cols-2 gap-4 mt-6">

                <div className="bg-yellow-50 p-4 rounded-md">
                  <p className="text-xs text-gray-500 uppercase">
                    Ação necessária
                  </p>

                  <p className="text-sm font-medium text-gray-900">
                    {alerta.required_action}
                  </p>
                </div>


                <div className="bg-red-50 p-4 rounded-md">
                  <p className="text-xs text-gray-500 uppercase">
                    Impacto
                  </p>

                  <p className="text-sm font-medium text-gray-900">
                    {alerta.impact}
                  </p>
                </div>

              </div>

            </div>

          ))
        )}

      </div>

    </div>
  )
}
