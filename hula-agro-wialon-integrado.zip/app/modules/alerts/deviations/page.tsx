'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { AlertCircle, TrendingDown, Thermometer, Droplets } from 'lucide-react'

const deviations = [
  {
    id: '1',
    type: 'Taxa de Postura',
    expected: '92%',
    actual: '88.5%',
    deviation: '-3.5%',
    severity: 'alto',
    date: '2024-02-04',
    galpao: 'Galpão A',
    lote: 'Lote 25',
    icon: TrendingDown,
  },
  {
    id: '2',
    type: 'Temperatura',
    expected: '22°C',
    actual: '25.2°C',
    deviation: '+3.2°C',
    severity: 'alto',
    date: '2024-02-04',
    galpao: 'Galpão C',
    lote: 'Lote 27',
    icon: Thermometer,
  },
  {
    id: '3',
    type: 'Consumo de Água',
    expected: '350ml/ave',
    actual: '320ml/ave',
    deviation: '-30ml',
    severity: 'médio',
    date: '2024-02-03',
    galpao: 'Galpão B',
    lote: 'Lote 26',
    icon: Droplets,
  },
  {
    id: '4',
    type: 'Conversão Alimentar',
    expected: '2.10',
    actual: '2.28',
    deviation: '+0.18',
    severity: 'médio',
    date: '2024-02-03',
    galpao: 'Galpão A',
    lote: 'Lote 25',
    icon: TrendingDown,
  },
  {
    id: '5',
    type: 'Mortalidade',
    expected: '0.8%',
    actual: '1.5%',
    deviation: '+0.7%',
    severity: 'alto',
    date: '2024-02-02',
    galpao: 'Galpão D',
    lote: 'Lote 28',
    icon: AlertCircle,
  },
]

const getSeverityColor = (severity: string) => {
  switch (severity) {
    case 'alto':
      return 'bg-red-100 text-red-800 border-red-300'
    case 'médio':
      return 'bg-yellow-100 text-yellow-800 border-yellow-300'
    case 'baixo':
      return 'bg-green-100 text-green-800 border-green-300'
    default:
      return 'bg-gray-100 text-gray-800'
  }
}

export default function DeviationsPage() {
  const [selectedSeverity, setSelectedSeverity] = useState<string | null>(null)
  const [resolved, setResolved] = useState<string[]>([])

  const filteredDeviations = selectedSeverity
    ? deviations.filter((d) => d.severity === selectedSeverity && !resolved.includes(d.id))
    : deviations.filter((d) => !resolved.includes(d.id))

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-50 to-orange-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900">Desvios Técnicos</h1>
          <p className="text-gray-600 mt-2">Monitore os desvios dos parâmetros técnicos esperados</p>
        </div>

        <div className="flex gap-2 mb-8">
          <Button
            variant={selectedSeverity === null ? 'default' : 'outline'}
            onClick={() => setSelectedSeverity(null)}
          >
            Todos
          </Button>
          <Button
            variant={selectedSeverity === 'alto' ? 'destructive' : 'outline'}
            onClick={() => setSelectedSeverity('alto')}
          >
            Alto
          </Button>
          <Button
            variant={selectedSeverity === 'médio' ? 'default' : 'outline'}
            onClick={() => setSelectedSeverity('médio')}
          >
            Médio
          </Button>
          <Button
            variant={selectedSeverity === 'baixo' ? 'default' : 'outline'}
            onClick={() => setSelectedSeverity('baixo')}
          >
            Baixo
          </Button>
        </div>

        <div className="space-y-4">
          {filteredDeviations.map((deviation) => {
            const Icon = deviation.icon
            return (
              <Card
                key={deviation.id}
                className={`border-2 ${
                  deviation.severity === 'alto' ? 'border-red-300' : 'border-gray-200'
                }`}
              >
                <CardContent className="pt-6">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-start gap-4 flex-1">
                      <div className={`p-3 rounded-lg ${
                        deviation.severity === 'alto' ? 'bg-red-100' : 'bg-yellow-100'
                      }`}>
                        <Icon className={`w-6 h-6 ${
                          deviation.severity === 'alto' ? 'text-red-600' : 'text-yellow-600'
                        }`} />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h3 className="font-semibold text-lg text-gray-900">{deviation.type}</h3>
                          <Badge className={getSeverityColor(deviation.severity)}>
                            {deviation.severity.toUpperCase()}
                          </Badge>
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
                          <div>
                            <p className="text-xs text-gray-600">Esperado</p>
                            <p className="font-semibold text-gray-900">{deviation.expected}</p>
                          </div>
                          <div>
                            <p className="text-xs text-gray-600">Atual</p>
                            <p className="font-semibold text-gray-900">{deviation.actual}</p>
                          </div>
                          <div>
                            <p className="text-xs text-gray-600">Desvio</p>
                            <p className={`font-semibold ${
                              deviation.deviation.startsWith('+') ? 'text-red-600' : 'text-orange-600'
                            }`}>
                              {deviation.deviation}
                            </p>
                          </div>
                          <div>
                            <p className="text-xs text-gray-600">Galpão / Lote</p>
                            <p className="font-semibold text-gray-900">{deviation.galpao} / {deviation.lote}</p>
                          </div>
                        </div>
                        <p className="text-xs text-gray-500 mt-2">Detectado em: {deviation.date}</p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setResolved([...resolved, deviation.id])}
                      >
                        Resolvido
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {filteredDeviations.length === 0 && (
          <Card>
            <CardContent className="pt-6 text-center">
              <p className="text-gray-500">Nenhum desvio encontrado</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
