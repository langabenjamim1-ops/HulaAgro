'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Calendar, User, Check } from 'lucide-react'

const decisions = [
  {
    id: '1',
    title: 'Aumento de Ventilação - Galpão C',
    description: 'Aumentado em 25% a taxa de ventilação para normalizar temperatura',
    date: '2024-02-04',
    time: '14:30',
    takenBy: 'João Silva',
    result: 'Temperatura normalizada para 22.5°C',
    success: true,
    galpao: 'Galpão C',
  },
  {
    id: '2',
    title: 'Troca de Ração - Lote 25',
    description: 'Alterada ração com aumento de proteína de 20% para 22%',
    date: '2024-02-03',
    time: '09:15',
    takenBy: 'Maria Santos',
    result: 'Conversão alimentar melhorou para 2.15',
    success: true,
    galpao: 'Galpão A',
  },
  {
    id: '3',
    title: 'Manutenção de Bebedouros - Galpão B',
    description: 'Realizada limpeza e desobstrução dos bebedouros',
    date: '2024-02-02',
    time: '11:45',
    takenBy: 'Pedro Costa',
    result: 'Consumo de água normalizado para 360ml/ave',
    success: true,
    galpao: 'Galpão B',
  },
  {
    id: '4',
    title: 'Aumento de Frequência de Limpeza - Galpão D',
    description: 'Frequência de limpeza aumentada de 1x para 2x diárias',
    date: '2024-02-02',
    time: '08:00',
    takenBy: 'Ana Oliveira',
    result: 'Mortalidade reduzida para 0.9% em 3 dias',
    success: true,
    galpao: 'Galpão D',
  },
  {
    id: '5',
    title: 'Ajuste de Programa de Luz - Galpão A',
    description: 'Programa de luz alterado para 16h diárias',
    date: '2024-02-01',
    time: '16:20',
    takenBy: 'João Silva',
    result: 'Taxa de postura aumentou para 93.5%',
    success: true,
    galpao: 'Galpão A',
  },
]

export default function DecisionsPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900">Histórico de Decisões</h1>
          <p className="text-gray-600 mt-2">Acompanhe todas as decisões técnicas e seu impacto na produção</p>
        </div>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Resumo</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <p className="text-sm text-gray-600">Total de Decisões</p>
                <p className="text-3xl font-bold text-gray-900">{decisions.length}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Taxa de Sucesso</p>
                <p className="text-3xl font-bold text-green-600">100%</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Última Decisão</p>
                <p className="text-lg font-semibold text-gray-900">{decisions[0].date}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Impacto Acumulado</p>
                <p className="text-lg font-semibold text-green-600">+8.5% Produção</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-4">
          {decisions.map((decision) => (
            <Card key={decision.id} className={`border-2 ${decision.success ? 'border-green-200' : 'border-gray-200'}`}>
              <CardContent className="pt-6">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-start gap-4 flex-1">
                    <div className="p-3 rounded-lg bg-green-100">
                      <Check className="w-6 h-6 text-green-600" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-lg text-gray-900">{decision.title}</h3>
                      <p className="text-gray-600 text-sm mt-1">{decision.description}</p>

                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
                        <div>
                          <p className="text-xs text-gray-600 flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            Data
                          </p>
                          <p className="font-semibold text-gray-900">
                            {decision.date} às {decision.time}
                          </p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-600 flex items-center gap-1">
                            <User className="w-3 h-3" />
                            Responsável
                          </p>
                          <p className="font-semibold text-gray-900">{decision.takenBy}</p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-600">Galpão</p>
                          <p className="font-semibold text-gray-900">{decision.galpao}</p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-600">Status</p>
                          <Badge className="bg-green-100 text-green-800">Bem-sucedida</Badge>
                        </div>
                      </div>

                      <div className="mt-4 p-3 bg-green-50 rounded-lg border border-green-200">
                        <p className="text-xs text-gray-600 font-semibold">RESULTADO</p>
                        <p className="text-sm text-green-700 font-semibold mt-1">{decision.result}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}
