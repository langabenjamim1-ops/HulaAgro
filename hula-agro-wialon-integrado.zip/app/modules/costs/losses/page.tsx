'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'
import { AlertTriangle, TrendingDown } from 'lucide-react'

const lossesData = [
  { dia: '1', mortalidade: 0.2, refugo: 0.1, custo: 150 },
  { dia: '7', mortalidade: 0.5, refugo: 0.2, custo: 280 },
  { dia: '14', mortalidade: 0.8, refugo: 0.3, custo: 380 },
  { dia: '21', mortalidade: 1.2, refugo: 0.5, custo: 520 },
  { dia: '28', mortalidade: 1.5, refugo: 0.7, custo: 680 },
  { dia: '35', mortalidade: 1.8, refugo: 0.9, custo: 820 },
  { dia: '42', mortalidade: 2.1, refugo: 1.0, custo: 950 },
]

const lossReasons = [
  { motivo: 'Problemas Respiratórios', mortes: 45, custo: 450, percentual: 35 },
  { motivo: 'Ascite', mortes: 25, custo: 250, percentual: 19 },
  { motivo: 'Lesões/Canibalism', mortes: 30, custo: 300, percentual: 23 },
  { motivo: 'Deficiências Nutricionais', mortes: 15, custo: 150, percentual: 12 },
  { motivo: 'Outros', mortes: 10, custo: 100, percentual: 8 },
]

export default function LossesPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-orange-50 to-slate-100 p-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-12">
          <h1 className="text-4xl font-bold text-slate-900 mb-2">Análise de Perdas</h1>
          <p className="text-slate-600">Impacto financeiro de mortalidade e refugos</p>
        </div>

        {/* Alertas */}
        <div className="bg-orange-50 border border-orange-200 rounded-lg p-4 mb-8 flex gap-4">
          <AlertTriangle className="w-6 h-6 text-orange-600 flex-shrink-0 mt-1" />
          <div>
            <p className="font-bold text-orange-900">Atenção: Mortalidade Acima do Normal</p>
            <p className="text-sm text-orange-700">Lote atual com 2.1% - esperado 1.5%. Investigue problemas respiratórios.</p>
          </div>
        </div>

        {/* KPIs */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card className="border-0 shadow-lg">
            <CardContent className="p-6">
              <p className="text-sm text-slate-600">Taxa Mortalidade</p>
              <p className="text-3xl font-bold text-slate-900 mt-2">2.1%</p>
              <p className="text-xs text-red-600 mt-2">+0.6% acima meta</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-lg">
            <CardContent className="p-6">
              <p className="text-sm text-slate-600">Perda por Dia</p>
              <p className="text-3xl font-bold text-slate-900 mt-2">R$ 1.250</p>
              <p className="text-xs text-slate-600 mt-2">Lote 5000 aves</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-lg">
            <CardContent className="p-6">
              <p className="text-sm text-slate-600">Perda Mensal Estimada</p>
              <p className="text-3xl font-bold text-slate-900 mt-2">R$ 37.500</p>
              <p className="text-xs text-red-600 mt-2">Impacto significativo</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-lg">
            <CardContent className="p-6">
              <p className="text-sm text-slate-600">Custo por Ave Perdida</p>
              <p className="text-3xl font-bold text-slate-900 mt-2">R$ 7,50</p>
              <p className="text-xs text-slate-600 mt-2">Perdido em criação</p>
            </CardContent>
          </Card>
        </div>

        {/* Gráfico de Evolução */}
        <Card className="border-0 shadow-lg mb-8">
          <CardHeader>
            <CardTitle>Evolução de Perdas Durante Criação</CardTitle>
            <CardDescription>Mortalidade, refugo e impacto financeiro acumulado</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={350}>
              <LineChart data={lossesData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="dia" label={{ value: 'Dias de Criação', position: 'insideBottomRight', offset: -5 }} />
                <YAxis yAxisId="left" label={{ value: 'Mortalidade (%)', angle: -90, position: 'insideLeft' }} />
                <YAxis yAxisId="right" orientation="right" label={{ value: 'Custo (R$)', angle: 90, position: 'insideRight' }} />
                <Tooltip />
                <Legend />
                <Line yAxisId="left" type="monotone" dataKey="mortalidade" stroke="#ef4444" strokeWidth={2} name="Mortalidade %" />
                <Line yAxisId="left" type="monotone" dataKey="refugo" stroke="#f59e0b" strokeWidth={2} name="Refugo %" />
                <Line yAxisId="right" type="monotone" dataKey="custo" stroke="#3b82f6" strokeWidth={2} name="Custo (R$)" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Causas */}
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle>Principais Causas de Perda</CardTitle>
            <CardDescription>Lote atual - Últimos 42 dias</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {lossReasons.map((reason) => (
                <div key={reason.motivo} className="p-4 border border-slate-200 rounded-lg">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <p className="font-semibold text-slate-900">{reason.motivo}</p>
                      <p className="text-sm text-slate-600">{reason.mortes} aves perdidas</p>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-bold text-red-600">R$ {reason.custo.toLocaleString()}</p>
                      <p className="text-xs text-slate-600">{reason.percentual}% do total</p>
                    </div>
                  </div>
                  <div className="w-full bg-slate-200 rounded-full h-2">
                    <div className="bg-gradient-to-r from-orange-400 to-red-500 h-2 rounded-full" style={{ width: `${reason.percentual * 3}%` }}></div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Recomendações */}
        <Card className="border-0 shadow-lg mt-8">
          <CardHeader>
            <CardTitle className="flex gap-2 items-center">
              <TrendingDown className="w-5 h-5 text-green-600" />
              Estratégias para Redução de Perdas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                <p className="font-semibold text-green-900 mb-2">Saúde Respiratória</p>
                <ul className="text-sm text-green-700 space-y-1">
                  <li>✓ Monitorar temperatura e umidade rigorosamente</li>
                  <li>✓ Aplicar programa de vacinação preventiva</li>
                  <li>✓ Garantir ventilação adequada dos galpões</li>
                </ul>
              </div>
              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <p className="font-semibold text-blue-900 mb-2">Nutrição Balanceada</p>
                <ul className="text-sm text-blue-700 space-y-1">
                  <li>✓ Revisar fórmula da ração com nutricionista</li>
                  <li>✓ Aumentar vitaminas do complexo B</li>
                  <li>✓ Verificar qualidade das matérias-primas</li>
                </ul>
              </div>
              <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                <p className="font-semibold text-purple-900 mb-2">Ambiência</p>
                <ul className="text-sm text-purple-700 space-y-1">
                  <li>✓ Ajustar densidade de aves nos galpões</li>
                  <li>✓ Melhorar sistema de bicos e comedouros</li>
                  <li>✓ Aplicar enriquecimento ambiental</li>
                </ul>
              </div>
              <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                <p className="font-semibold text-amber-900 mb-2">Monitoramento</p>
                <ul className="text-sm text-amber-700 space-y-1">
                  <li>✓ Realizar necropsias de aves mortas</li>
                  <li>✓ Manter registros diários detalhados</li>
                  <li>✓ Consultar veterinário regularmente</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
