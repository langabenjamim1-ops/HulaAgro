'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'

const feedData = [
  { mes: 'Jan', custo: 14200, consumo: 2400 },
  { mes: 'Fev', custo: 15100, consumo: 2410 },
  { mes: 'Mar', custo: 15800, consumo: 2290 },
  { mes: 'Abr', custo: 16200, consumo: 2000 },
  { mes: 'Mai', custo: 15650, consumo: 2181 },
  { mes: 'Jun', custo: 15420, consumo: 2500 },
]

const feedTypes = [
  { nome: 'Inicial', custo: 2100, consumo: 250, margem: 8.4 },
  { nome: 'Crescimento', custo: 4500, consumo: 800, margem: 5.6 },
  { nome: 'Final', custo: 5920, consumo: 1100, margem: 5.4 },
  { nome: 'Postura', custo: 2900, consumo: 350, margem: 8.3 },
]

export default function FeedCostsPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-green-50 to-slate-100 p-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-12">
          <h1 className="text-4xl font-bold text-slate-900 mb-2">Custos de Ração</h1>
          <p className="text-slate-600">Análise detalhada do maior custo operacional</p>
        </div>

        {/* KPIs */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card className="border-0 shadow-lg">
            <CardContent className="p-6">
              <p className="text-sm text-slate-600">Custo Mensal</p>
              <p className="text-3xl font-bold text-slate-900 mt-2">R$ 15.420</p>
              <p className="text-xs text-green-600 mt-2">-3.2% vs anterior</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-lg">
            <CardContent className="p-6">
              <p className="text-sm text-slate-600">Custo/kg Carcaça</p>
              <p className="text-3xl font-bold text-slate-900 mt-2">R$ 6,89</p>
              <p className="text-xs text-red-600 mt-2">+2.1% vs anterior</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-lg">
            <CardContent className="p-6">
              <p className="text-sm text-slate-600">Consumo Total</p>
              <p className="text-3xl font-bold text-slate-900 mt-2">2.500 kg</p>
              <p className="text-xs text-green-600 mt-2">+1.5% vs planejado</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-lg">
            <CardContent className="p-6">
              <p className="text-sm text-slate-600">CA (Conversão)</p>
              <p className="text-3xl font-bold text-slate-900 mt-2">1,89</p>
              <p className="text-xs text-orange-600 mt-2">Acima do esperado</p>
            </CardContent>
          </Card>
        </div>

        {/* Gráficos */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle>Custo Mensal vs Consumo</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={feedData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis dataKey="mes" />
                  <YAxis yAxisId="left" />
                  <YAxis yAxisId="right" orientation="right" />
                  <Tooltip />
                  <Legend />
                  <Line yAxisId="left" type="monotone" dataKey="custo" stroke="#3b82f6" strokeWidth={2} name="Custo (R$)" />
                  <Line yAxisId="right" type="monotone" dataKey="consumo" stroke="#10b981" strokeWidth={2} name="Consumo (kg)" />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle>Custo por Tipo de Ração</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={feedTypes}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis dataKey="nome" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="custo" fill="#3b82f6" name="Custo (R$)" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Tabela de Rações */}
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle>Detalhamento por Fase</CardTitle>
            <CardDescription>Custos e consumo por tipo de ração</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-slate-200">
                    <th className="text-left py-4 px-4 font-semibold text-slate-900">Tipo</th>
                    <th className="text-right py-4 px-4 font-semibold text-slate-900">Custo/kg</th>
                    <th className="text-right py-4 px-4 font-semibold text-slate-900">Consumo</th>
                    <th className="text-right py-4 px-4 font-semibold text-slate-900">Custo Total</th>
                    <th className="text-right py-4 px-4 font-semibold text-slate-900">% do Total</th>
                  </tr>
                </thead>
                <tbody>
                  {feedTypes.map((feed) => (
                    <tr key={feed.nome} className="border-b border-slate-100 hover:bg-blue-50">
                      <td className="py-4 px-4 text-slate-900 font-medium">{feed.nome}</td>
                      <td className="text-right py-4 px-4 text-slate-600">R$ 8,40</td>
                      <td className="text-right py-4 px-4 text-slate-600">{feed.consumo} kg</td>
                      <td className="text-right py-4 px-4 text-slate-900 font-semibold">R$ {feed.custo.toLocaleString()}</td>
                      <td className="text-right py-4 px-4">
                        <span className="inline-block px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-medium">
                          {((feed.custo / 15420) * 100).toFixed(1)}%
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
