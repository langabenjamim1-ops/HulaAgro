'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts'

const healthCosts = [
  { nome: 'Vacinas', valor: 800, percentual: 38 },
  { nome: 'Medicamentos', valor: 600, percentual: 29 },
  { nome: 'Desinfetantes', valor: 350, percentual: 17 },
  { nome: 'Consultorias', valor: 200, percentual: 10 },
  { nome: 'Análises Laboratoriais', valor: 150, percentual: 6 },
]

const colors = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6']

export default function HealthCostsPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-red-50 to-slate-100 p-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-12">
          <h1 className="text-4xl font-bold text-slate-900 mb-2">Custos Sanitários</h1>
          <p className="text-slate-600">Gestão de gastos com saúde e biossegurança</p>
        </div>

        {/* KPIs */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card className="border-0 shadow-lg">
            <CardContent className="p-6">
              <p className="text-sm text-slate-600">Custo Total/Mês</p>
              <p className="text-3xl font-bold text-slate-900 mt-2">R$ 2.100</p>
              <p className="text-xs text-green-600 mt-2">7.6% da receita</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-lg">
            <CardContent className="p-6">
              <p className="text-sm text-slate-600">Maior Gasto</p>
              <p className="text-3xl font-bold text-slate-900 mt-2">Vacinas</p>
              <p className="text-xs text-slate-600 mt-2">R$ 800/mês</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-lg">
            <CardContent className="p-6">
              <p className="text-sm text-slate-600">Custo/Ave</p>
              <p className="text-3xl font-bold text-slate-900 mt-2">R$ 0,42</p>
              <p className="text-xs text-slate-600 mt-2">Lote 5000 aves</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-lg">
            <CardContent className="p-6">
              <p className="text-sm text-slate-600">Status Sanitário</p>
              <p className="text-3xl font-bold text-green-600 mt-2">Ótimo</p>
              <p className="text-xs text-green-600 mt-2">0 problemas</p>
            </CardContent>
          </Card>
        </div>

        {/* Gráfico Pizza */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <Card className="border-0 shadow-lg lg:col-span-1">
            <CardHeader>
              <CardTitle>Distribuição de Custos</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={healthCosts}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ percentual }) => `${percentual}%`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="valor"
                  >
                    {healthCosts.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
                    ))}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Detalhes */}
          <Card className="border-0 shadow-lg lg:col-span-2">
            <CardHeader>
              <CardTitle>Detalhamento por Categoria</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {healthCosts.map((item, idx) => (
                  <div key={item.nome} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: colors[idx] }}></div>
                      <div>
                        <p className="font-medium text-slate-900">{item.nome}</p>
                        <p className="text-xs text-slate-600">{item.percentual}% do total</p>
                      </div>
                    </div>
                    <p className="font-bold text-slate-900">R$ {item.valor.toLocaleString()}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recomendações */}
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle>Calendário de Vacinação & Tratamentos</CardTitle>
            <CardDescription>Programação preventiva para 2024</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {[
                { dia: '5 dias', procedimento: 'Vacinação Newcastle + IBV', custo: 'R$ 120' },
                { dia: '10 dias', procedimento: 'Vacinação Gumboro', custo: 'R$ 100' },
                { dia: '21 dias', procedimento: 'Vacinação Reforço', custo: 'R$ 120' },
                { dia: '42 dias', procedimento: 'Análise Laboratorial + Ajustes', custo: 'R$ 250' },
              ].map((item) => (
                <div key={item.dia} className="flex justify-between items-center p-4 border border-slate-200 rounded-lg">
                  <div>
                    <p className="font-medium text-slate-900">{item.procedimento}</p>
                    <p className="text-sm text-slate-600">Idade: {item.dia}</p>
                  </div>
                  <p className="font-bold text-blue-600">{item.custo}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
