'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'

const operationalData = [
  { categoria: 'Energia', valor: 3200, percentual: 37 },
  { categoria: 'Água', valor: 1500, percentual: 17 },
  { categoria: 'Mão de Obra', valor: 2500, percentual: 29 },
  { categoria: 'Manutenção', valor: 900, percentual: 10 },
  { categoria: 'Combustível', valor: 350, percentual: 4 },
]

const monthlyData = [
  { mes: 'Jan', energia: 3100, agua: 1480, mao: 2500, manutencao: 850 },
  { mes: 'Fev', energia: 3200, agua: 1520, mao: 2500, manutencao: 900 },
  { mes: 'Mar', energia: 3150, agua: 1500, mao: 2500, manutencao: 920 },
  { mes: 'Abr', energia: 3200, agua: 1500, mao: 2500, manutencao: 900 },
]

export default function OperationalCostsPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100 p-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-12">
          <h1 className="text-4xl font-bold text-slate-900 mb-2">Custos Operacionais</h1>
          <p className="text-slate-600">Energia, água, mão de obra e manutenção</p>
        </div>

        {/* KPIs */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card className="border-0 shadow-lg">
            <CardContent className="p-6">
              <p className="text-sm text-slate-600">Custo Mensal</p>
              <p className="text-3xl font-bold text-slate-900 mt-2">R$ 8.450</p>
              <p className="text-xs text-green-600 mt-2">-2.1% vs anterior</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-lg">
            <CardContent className="p-6">
              <p className="text-sm text-slate-600">Maior Gasto</p>
              <p className="text-3xl font-bold text-slate-900 mt-2">Energia</p>
              <p className="text-xs text-slate-600 mt-2">37% dos custos</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-lg">
            <CardContent className="p-6">
              <p className="text-sm text-slate-600">Custo/Ave/Mês</p>
              <p className="text-3xl font-bold text-slate-900 mt-2">R$ 1,69</p>
              <p className="text-xs text-slate-600 mt-2">Lote 5000 aves</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-lg">
            <CardContent className="p-6">
              <p className="text-sm text-slate-600">Eficiência</p>
              <p className="text-3xl font-bold text-green-600 mt-2">Boa</p>
              <p className="text-xs text-green-600 mt-2">+15% otimização</p>
            </CardContent>
          </Card>
        </div>

        {/* Gráfico Mensal */}
        <Card className="border-0 shadow-lg mb-8">
          <CardHeader>
            <CardTitle>Custo Operacional Mensal</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={350}>
              <BarChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="mes" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="energia" stackId="a" fill="#3b82f6" name="Energia" />
                <Bar dataKey="agua" stackId="a" fill="#06b6d4" name="Água" />
                <Bar dataKey="mao" stackId="a" fill="#8b5cf6" name="Mão de Obra" />
                <Bar dataKey="manutencao" stackId="a" fill="#f59e0b" name="Manutenção" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Detalhamento */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle>Custos por Categoria</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {operationalData.map((item) => (
                  <div key={item.categoria}>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium text-slate-900">{item.categoria}</span>
                      <span className="font-bold text-slate-900">R$ {item.valor.toLocaleString()}</span>
                    </div>
                    <div className="w-full bg-slate-200 rounded-full h-2">
                      <div className="bg-gradient-to-r from-blue-400 to-blue-600 h-2 rounded-full" style={{ width: `${item.percentual * 3}%` }}></div>
                    </div>
                    <p className="text-xs text-slate-600 mt-1">{item.percentual}% do total</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle>Oportunidades de Economia</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                  <p className="font-medium text-green-900">Energia - Redução de 10%</p>
                  <p className="text-sm text-green-700">Instalar painéis solares - Economia: R$ 320/mês</p>
                </div>
                <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <p className="font-medium text-blue-900">Água - Sistema de Reuso</p>
                  <p className="text-sm text-blue-700">Implementar reciclagem - Economia: R$ 200/mês</p>
                </div>
                <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                  <p className="font-medium text-orange-900">Manutenção Preventiva</p>
                  <p className="text-sm text-orange-700">Calendário regular - Economia: R$ 150/mês</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
