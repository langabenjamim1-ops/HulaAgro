'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Textarea } from '@/components/ui/textarea'

export default function FeedTypesPage() {
  const [feeds, setFeeds] = useState([
    { id: 1, name: 'Ração Postura Fase 1', type: 'Postura', protein: 16, cost: 45.50 },
    { id: 2, name: 'Ração Postura Fase 2', type: 'Postura', protein: 14, cost: 42.00 },
    { id: 3, name: 'Ração Corte Inicial', type: 'Corte', protein: 22, cost: 55.00 },
  ])
  const [open, setOpen] = useState(false)
  const [formData, setFormData] = useState({ name: '', type: '', protein: '', cost: '' })

  const handleAdd = () => {
    if (formData.name && formData.type) {
      setFeeds([
        ...feeds,
        {
          id: Date.now(),
          name: formData.name,
          type: formData.type,
          protein: Number(formData.protein),
          cost: Number(formData.cost),
        },
      ])
      setFormData({ name: '', type: '', protein: '', cost: '' })
      setOpen(false)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Tipos de Ração</h1>
          <p className="text-gray-600 mt-2">Gerencie as fórmulas e tipos de ração</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button>+ Nova Ração</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Adicionar Tipo de Ração</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Nome</label>
                <Input
                  placeholder="Ex: Ração Postura Fase 1"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Tipo</label>
                <select
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  value={formData.type}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                >
                  <option value="">Selecionar tipo</option>
                  <option value="Postura">Postura</option>
                  <option value="Corte">Corte</option>
                  <option value="Recria">Recria</option>
                </select>
              </div>
              <div>
                <label className="text-sm font-medium">Proteína (%)</label>
                <Input
                  type="number"
                  placeholder="16"
                  value={formData.protein}
                  onChange={(e) => setFormData({ ...formData, protein: e.target.value })}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Custo (R$/kg)</label>
                <Input
                  type="number"
                  placeholder="45.50"
                  value={formData.cost}
                  onChange={(e) => setFormData({ ...formData, cost: e.target.value })}
                />
              </div>
              <Button onClick={handleAdd} className="w-full">Adicionar Ração</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-gray-100 border-b">
            <tr>
              <th className="text-left px-4 py-2">Nome</th>
              <th className="text-left px-4 py-2">Tipo</th>
              <th className="text-left px-4 py-2">Proteína</th>
              <th className="text-left px-4 py-2">Custo</th>
            </tr>
          </thead>
          <tbody>
            {feeds.map((feed) => (
              <tr key={feed.id} className="border-b hover:bg-gray-50">
                <td className="px-4 py-2 font-medium">{feed.name}</td>
                <td className="px-4 py-2">{feed.type}</td>
                <td className="px-4 py-2">{feed.protein}%</td>
                <td className="px-4 py-2">R$ {feed.cost.toFixed(2)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
