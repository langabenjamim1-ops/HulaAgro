'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'

export default function ProductionTypesPage() {
  const [types, setTypes] = useState([
    { id: 1, name: 'Postura', description: 'Produção de ovos para consumo' },
    { id: 2, name: 'Corte', description: 'Produção de carne' },
    { id: 3, name: 'Reprodução', description: 'Produção de ovos férteis' },
  ])
  const [open, setOpen] = useState(false)
  const [formData, setFormData] = useState({ name: '', description: '' })

  const handleAdd = () => {
    if (formData.name) {
      setTypes([...types, { id: Date.now(), ...formData }])
      setFormData({ name: '', description: '' })
      setOpen(false)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Tipos de Produção</h1>
          <p className="text-gray-600 mt-2">Configure os tipos de produção da sua granja</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button>+ Novo Tipo</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Adicionar Tipo de Produção</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Nome</label>
                <Input
                  placeholder="Ex: Postura"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Descrição</label>
                <Input
                  placeholder="Descrição do tipo"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                />
              </div>
              <Button onClick={handleAdd} className="w-full">Adicionar</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {types.map((t) => (
          <Card key={t.id}>
            <CardHeader>
              <CardTitle>{t.name}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">{t.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
