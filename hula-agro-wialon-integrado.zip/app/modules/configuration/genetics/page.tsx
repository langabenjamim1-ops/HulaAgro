'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Textarea } from '@/components/ui/textarea'

export default function GeneticsPage() {
  const [genetics, setGenetics] = useState([
    { id: 1, name: 'Lohmann Brown', type: 'Poedeira', description: 'Excelente produção de ovos' },
    { id: 2, name: 'Cobb 500', type: 'Corte', description: 'Crescimento rápido' },
  ])
  const [open, setOpen] = useState(false)
  const [formData, setFormData] = useState({ name: '', type: '', description: '' })

  const handleAdd = () => {
    if (formData.name && formData.type) {
      setGenetics([...genetics, { id: Date.now(), ...formData }])
      setFormData({ name: '', type: '', description: '' })
      setOpen(false)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Genética / Linhagens</h1>
          <p className="text-gray-600 mt-2">Gerencie as linhagens genéticas da sua granja</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button>+ Nova Linhagem</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Adicionar Nova Linhagem</DialogTitle>
              <DialogDescription>Cadastre uma nova linhagem genética</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Nome</label>
                <Input
                  placeholder="Ex: Lohmann Brown"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Tipo</label>
                <select
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  value={formData.type}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                >
                  <option value="">Selecionar tipo</option>
                  <option value="Poedeira">Poedeira</option>
                  <option value="Corte">Corte</option>
                  <option value="Reprodutor">Reprodutor</option>
                </select>
              </div>
              <div>
                <label className="text-sm font-medium">Descrição</label>
                <Textarea
                  placeholder="Características da linhagem"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  rows={2}
                />
              </div>
              <Button onClick={handleAdd} className="w-full">Adicionar Linhagem</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {genetics.map((g) => (
          <Card key={g.id}>
            <CardHeader>
              <CardTitle>{g.name}</CardTitle>
              <CardDescription>{g.type}</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">{g.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
