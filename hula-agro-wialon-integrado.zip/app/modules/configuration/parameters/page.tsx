'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

export default function ParametersPage() {
  const [parameters, setParameters] = useState({
    temperatureMin: 32,
    temperatureMax: 28,
    humidityMin: 60,
    humidityMax: 75,
    ventilationRate: 8,
    lightingHours: 16,
  })
  const [editing, setEditing] = useState(false)
  const [tempData, setTempData] = useState(parameters)

  const handleSave = () => {
    setParameters(tempData)
    setEditing(false)
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Parâmetros Técnicos</h1>
          <p className="text-gray-600 mt-2">Defina os parâmetros técnicos de funcionamento</p>
        </div>
        {!editing && <Button onClick={() => setEditing(true)}>Editar Parâmetros</Button>}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle>Temperatura</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {editing ? (
              <>
                <div>
                  <label className="text-sm font-medium">Mínima (°C)</label>
                  <Input
                    type="number"
                    value={tempData.temperatureMin}
                    onChange={(e) => setTempData({ ...tempData, temperatureMin: Number(e.target.value) })}
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Máxima (°C)</label>
                  <Input
                    type="number"
                    value={tempData.temperatureMax}
                    onChange={(e) => setTempData({ ...tempData, temperatureMax: Number(e.target.value) })}
                  />
                </div>
              </>
            ) : (
              <>
                <p className="text-sm">Min: {parameters.temperatureMin}°C / Max: {parameters.temperatureMax}°C</p>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Umidade Relativa</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {editing ? (
              <>
                <div>
                  <label className="text-sm font-medium">Mínima (%)</label>
                  <Input
                    type="number"
                    value={tempData.humidityMin}
                    onChange={(e) => setTempData({ ...tempData, humidityMin: Number(e.target.value) })}
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Máxima (%)</label>
                  <Input
                    type="number"
                    value={tempData.humidityMax}
                    onChange={(e) => setTempData({ ...tempData, humidityMax: Number(e.target.value) })}
                  />
                </div>
              </>
            ) : (
              <p className="text-sm">Min: {parameters.humidityMin}% / Max: {parameters.humidityMax}%</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Ventilação</CardTitle>
          </CardHeader>
          <CardContent>
            {editing ? (
              <div>
                <label className="text-sm font-medium">Taxa (m³/h por ave)</label>
                <Input
                  type="number"
                  value={tempData.ventilationRate}
                  onChange={(e) => setTempData({ ...tempData, ventilationRate: Number(e.target.value) })}
                />
              </div>
            ) : (
              <p className="text-sm">{parameters.ventilationRate} m³/h por ave</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Iluminação</CardTitle>
          </CardHeader>
          <CardContent>
            {editing ? (
              <div>
                <label className="text-sm font-medium">Horas de luz</label>
                <Input
                  type="number"
                  value={tempData.lightingHours}
                  onChange={(e) => setTempData({ ...tempData, lightingHours: Number(e.target.value) })}
                />
              </div>
            ) : (
              <p className="text-sm">{parameters.lightingHours} horas</p>
            )}
          </CardContent>
        </Card>
      </div>

      {editing && (
        <div className="flex gap-2">
          <Button onClick={handleSave} className="bg-green-600 hover:bg-green-700">Salvar</Button>
          <Button onClick={() => setEditing(false)} variant="outline">Cancelar</Button>
        </div>
      )}
    </div>
  )
}
