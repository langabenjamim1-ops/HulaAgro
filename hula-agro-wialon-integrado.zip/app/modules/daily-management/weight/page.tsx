'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'

export default function WeightPage() {
  const [records, setRecords] = useState([
    { id: 1, date: '2024-02-04', batch: 'Lote Postura 001', avgWeight: 1850, uniformity: 92 },
    { id: 2, date: '2024-02-03', batch: 'Lote Postura 001', avgWeight: 1820, uniformity: 90 },
    { id: 3, date: '2024-02-02', batch: 'Lote Postura 001', avgWeight: 1790, uniformity: 89 },
    { id: 4, date: '2024-02-01', batch: 'Lote Postura 001', avgWeight: 1760, uniformity: 88 },
  ])
  const [open, setOpen] = useState(false)
  const [formData, setFormData] = useState({ batch: '', avgWeight: '', uniformity: '' })

  const handleAdd = () => {
    if (formData.batch && formData.avgWeight) {
      setRecords([
        {
          id: Date.now(),
          date: new Date().toISOString().split('T')[0],
          batch: formData.batch,
          avgWeight: Number(formData.avgWeight),
          uniformity: Number(formData.uniformity),
        },
        ...records,
      ])
      setFormData({ batch: '', avgWeight: '', uniformity: '' })
      setOpen(false)
    }
  }

  const chartData = records.slice().reverse().map((r) => ({
    date: new Date(r.date).toLocaleDateString('pt-BR', { month: '2-digit', day: '2-digit' }),
    peso: r.avgWeight,
    uniformidade: r.uniformity,
  }))

  const latestRecord = records[0]
  const avgWeightAll = Math.round(records.reduce((sum, r) => sum + r.avgWeight, 0) / records.length)

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Peso Médio</h1>
          <p className="text-gray-600 mt-2">Registre e acompanhe os pesos das aves</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button>+ Registrar Pesagem</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Registrar Peso Médio</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Lote</label>
                <select
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  value={formData.batch}
                  onChange={(e) => setFormData({ ...formData, batch: e.target.value })}
                >
                  <option value="">Selecionar lote</option>
                  <option value="Lote Postura 001">Lote Postura 001</option>
                  <option value="Lote Postura 002">Lote Postura 002</option>
                  <option value="Lote Corte 001">Lote Corte 001</option>
                </select>
              </div>
              <div>
                <label className="text-sm font-medium">Peso Médio (gramas)</label>
                <Input
                  type="number"
                  placeholder="1850"
                  value={formData.avgWeight}
                  onChange={(e) => setFormData({ ...formData, avgWeight: e.target.value })}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Uniformidade (%)</label>
                <Input
                  type="number"
                  placeholder="92"
                  min="0"
                  max="100"
                  value={formData.uniformity}
                  onChange={(e) => setFormData({ ...formData, uniformity: e.target.value })}
                />
              </div>
              <Button onClick={handleAdd} className="w-full">Registrar</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Peso Atual</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-600">{latestRecord.avgWeight}g</div>
            <p className="text-sm text-gray-600 mt-1">{new Date(latestRecord.date).toLocaleDateString('pt-BR')}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Peso Médio</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">{avgWeightAll}g</div>
            <p className="text-sm text-gray-600 mt-1">últimos {records.length} dias</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Uniformidade</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-purple-600">{latestRecord.uniformity}%</div>
            <p className="text-sm text-gray-600 mt-1">{latestRecord.uniformity >= 90 ? 'Excelente' : 'Boa'}</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Evolução de Peso e Uniformidade</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis yAxisId="left" />
              <YAxis yAxisId="right" orientation="right" />
              <Tooltip />
              <Legend />
              <Line yAxisId="left" type="monotone" dataKey="peso" stroke="#3b82f6" name="Peso (g)" />
              <Line yAxisId="right" type="monotone" dataKey="uniformidade" stroke="#10b981" name="Uniformidade (%)" />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Histórico de Pesos</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-100 border-b">
                <tr>
                  <th className="text-left px-4 py-2">Data</th>
                  <th className="text-left px-4 py-2">Lote</th>
                  <th className="text-left px-4 py-2">Peso Médio (g)</th>
                  <th className="text-left px-4 py-2">Uniformidade (%)</th>
                </tr>
              </thead>
              <tbody>
                {records.map((record) => (
                  <tr key={record.id} className="border-b hover:bg-gray-50">
                    <td className="px-4 py-2">{new Date(record.date).toLocaleDateString('pt-BR')}</td>
                    <td className="px-4 py-2 font-medium">{record.batch}</td>
                    <td className="px-4 py-2">{record.avgWeight}g</td>
                    <td className="px-4 py-2">{record.uniformity}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
