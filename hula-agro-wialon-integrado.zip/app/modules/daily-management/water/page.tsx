'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'

export default function WaterPage() {
  const [records, setRecords] = useState([
    { id: 1, date: '2024-02-04', batch: 'Lote Postura 001', consumption: 2500, quality: 'Normal' },
    { id: 2, date: '2024-02-03', batch: 'Lote Postura 001', consumption: 2480, quality: 'Normal' },
    { id: 3, date: '2024-02-02', batch: 'Lote Postura 001', consumption: 2300, quality: 'Baixa' },
  ])
  const [open, setOpen] = useState(false)
  const [formData, setFormData] = useState({ batch: '', consumption: '', quality: '' })

  const handleAdd = () => {
    if (formData.batch && formData.consumption) {
      setRecords([
        {
          id: Date.now(),
          date: new Date().toISOString().split('T')[0],
          batch: formData.batch,
          consumption: Number(formData.consumption),
          quality: formData.quality,
        },
        ...records,
      ])
      setFormData({ batch: '', consumption: '', quality: '' })
      setOpen(false)
    }
  }

  const chartData = records.slice(0, 7).reverse().map((r) => ({
    date: new Date(r.date).toLocaleDateString('pt-BR', { month: '2-digit', day: '2-digit' }),
    consumo: r.consumption,
  }))

  const avgConsumption = Math.round(records.reduce((sum, r) => sum + r.consumption, 0) / records.length)
  const totalConsumption = records.reduce((sum, r) => sum + r.consumption, 0)

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Consumo de Água</h1>
          <p className="text-gray-600 mt-2">Monitore o consumo hídrico das aves</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button>+ Registrar Consumo</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Registrar Consumo de Água</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Lote</label>
                <select
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  value={formData.batch}
                  onChange={(e) => setFormData({ ...formData, batch: e.target.value })}
                >
                  <option value="">Selecionar lote</option>
                  <option value="Lote Postura 001">Lote Postura 001</option>
                  <option value="Lote Postura 002">Lote Postura 002</option>
                  <option value="Lote Corte 001">Lote Corte 001</option>
                </select>
              </div>
              <div>
                <label className="text-sm font-medium">Consumo (litros)</label>
                <Input
                  type="number"
                  placeholder="2500"
                  value={formData.consumption}
                  onChange={(e) => setFormData({ ...formData, consumption: e.target.value })}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Qualidade da Água</label>
                <select
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  value={formData.quality}
                  onChange={(e) => setFormData({ ...formData, quality: e.target.value })}
                >
                  <option value="">Selecionar qualidade</option>
                  <option value="Excelente">Excelente</option>
                  <option value="Normal">Normal</option>
                  <option value="Baixa">Baixa</option>
                  <option value="Crítica">Crítica</option>
                </select>
              </div>
              <Button onClick={handleAdd} className="w-full">Registrar</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Consumo Total</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-600">{totalConsumption.toLocaleString()} L</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Média Diária</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">{avgConsumption.toLocaleString()} L</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Registros</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-gray-600">{records.length}</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Tendência de Consumo</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="consumo" stroke="#3b82f6" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Histórico de Consumo</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-100 border-b">
                <tr>
                  <th className="text-left px-4 py-2">Data</th>
                  <th className="text-left px-4 py-2">Lote</th>
                  <th className="text-left px-4 py-2">Consumo (L)</th>
                  <th className="text-left px-4 py-2">Qualidade</th>
                </tr>
              </thead>
              <tbody>
                {records.map((record) => (
                  <tr key={record.id} className="border-b hover:bg-gray-50">
                    <td className="px-4 py-2">{new Date(record.date).toLocaleDateString('pt-BR')}</td>
                    <td className="px-4 py-2 font-medium">{record.batch}</td>
                    <td className="px-4 py-2">{record.consumption.toLocaleString()}</td>
                    <td className="px-4 py-2">{record.quality}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
