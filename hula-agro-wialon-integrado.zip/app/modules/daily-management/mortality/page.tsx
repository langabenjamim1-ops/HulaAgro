'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'

export default function MortalityPage() {
  const [records, setRecords] = useState([
    { id: 1, date: '2024-02-04', batch: 'Lote Postura 001', mortality: 3, cause: 'Asfixia' },
    { id: 2, date: '2024-02-03', batch: 'Lote Postura 001', mortality: 1, cause: 'Canibalismo' },
    { id: 3, date: '2024-02-02', batch: 'Lote Postura 001', mortality: 2, cause: 'Doença' },
  ])
  const [open, setOpen] = useState(false)
  const [formData, setFormData] = useState({ batch: '', mortality: '', cause: '' })

  const handleAdd = () => {
    if (formData.batch && formData.mortality) {
      setRecords([
        {
          id: Date.now(),
          date: new Date().toISOString().split('T')[0],
          batch: formData.batch,
          mortality: Number(formData.mortality),
          cause: formData.cause,
        },
        ...records,
      ])
      setFormData({ batch: '', mortality: '', cause: '' })
      setOpen(false)
    }
  }

  const chartData = records.slice(0, 7).reverse().map((r) => ({
    date: new Date(r.date).toLocaleDateString('pt-BR', { month: '2-digit', day: '2-digit' }),
    mortes: r.mortality,
  }))

  const totalMortality = records.reduce((sum, r) => sum + r.mortality, 0)
  const avgMortalityRate = (totalMortality / records.length).toFixed(1)

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Mortalidade</h1>
          <p className="text-gray-600 mt-2">Registre e acompanhe as perdas de aves</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button>+ Registrar Morte</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Registrar Mortalidade</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Lote</label>
                <select
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  value={formData.batch}
                  onChange={(e) => setFormData({ ...formData, batch: e.target.value })}
                >
                  <option value="">Selecionar lote</option>
                  <option value="Lote Postura 001">Lote Postura 001</option>
                  <option value="Lote Postura 002">Lote Postura 002</option>
                  <option value="Lote Corte 001">Lote Corte 001</option>
                </select>
              </div>
              <div>
                <label className="text-sm font-medium">Número de Aves Mortas</label>
                <Input
                  type="number"
                  placeholder="3"
                  value={formData.mortality}
                  onChange={(e) => setFormData({ ...formData, mortality: e.target.value })}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Causa Presumida</label>
                <select
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  value={formData.cause}
                  onChange={(e) => setFormData({ ...formData, cause: e.target.value })}
                >
                  <option value="">Selecionar causa</option>
                  <option value="Doença">Doença</option>
                  <option value="Canibalismo">Canibalismo</option>
                  <option value="Asfixia">Asfixia</option>
                  <option value="Parasitas">Parasitas</option>
                  <option value="Desconhecida">Desconhecida</option>
                </select>
              </div>
              <Button onClick={handleAdd} className="w-full">Registrar</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Total de Mortes (últimos dias)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-red-600">{totalMortality}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Taxa Média</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-orange-600">{avgMortalityRate} aves/dia</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Registros</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-600">{records.length}</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Tendência de Mortalidade</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="mortes" fill="#ef4444" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Histórico de Mortalidade</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-100 border-b">
                <tr>
                  <th className="text-left px-4 py-2">Data</th>
                  <th className="text-left px-4 py-2">Lote</th>
                  <th className="text-left px-4 py-2">Aves Mortas</th>
                  <th className="text-left px-4 py-2">Causa</th>
                </tr>
              </thead>
              <tbody>
                {records.map((record) => (
                  <tr key={record.id} className="border-b hover:bg-gray-50">
                    <td className="px-4 py-2">{new Date(record.date).toLocaleDateString('pt-BR')}</td>
                    <td className="px-4 py-2 font-medium">{record.batch}</td>
                    <td className="px-4 py-2 font-semibold text-red-600">{record.mortality}</td>
                    <td className="px-4 py-2">{record.cause}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
