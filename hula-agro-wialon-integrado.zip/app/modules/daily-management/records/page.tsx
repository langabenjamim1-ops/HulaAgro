'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'

export default function DailyRecordsPage() {
  const [records, setRecords] = useState([
    { id: 1, date: '2024-02-04', batch: 'Lote Postura 001', temperature: 28.5, humidity: 65, notes: 'Dia normal' },
    { id: 2, date: '2024-02-03', batch: 'Lote Postura 001', temperature: 29.0, humidity: 68, notes: 'Temperatura elevada' },
  ])
  const [open, setOpen] = useState(false)
  const [formData, setFormData] = useState({ batch: '', temperature: '', humidity: '', notes: '' })

  const handleAdd = () => {
    if (formData.batch && formData.temperature) {
      setRecords([
        {
          id: Date.now(),
          date: new Date().toISOString().split('T')[0],
          batch: formData.batch,
          temperature: Number(formData.temperature),
          humidity: Number(formData.humidity),
          notes: formData.notes,
        },
        ...records,
      ])
      setFormData({ batch: '', temperature: '', humidity: '', notes: '' })
      setOpen(false)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Registros Diários</h1>
          <p className="text-gray-600 mt-2">Registre as informações operacionais do dia</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button>+ Novo Registro</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Adicionar Registro Diário</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Lote</label>
                <select
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  value={formData.batch}
                  onChange={(e) => setFormData({ ...formData, batch: e.target.value })}
                >
                  <option value="">Selecionar lote</option>
                  <option value="Lote Postura 001">Lote Postura 001</option>
                  <option value="Lote Postura 002">Lote Postura 002</option>
                  <option value="Lote Corte 001">Lote Corte 001</option>
                </select>
              </div>
              <div>
                <label className="text-sm font-medium">Temperatura (°C)</label>
                <Input
                  type="number"
                  step="0.1"
                  placeholder="28.5"
                  value={formData.temperature}
                  onChange={(e) => setFormData({ ...formData, temperature: e.target.value })}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Umidade (%)</label>
                <Input
                  type="number"
                  placeholder="65"
                  value={formData.humidity}
                  onChange={(e) => setFormData({ ...formData, humidity: e.target.value })}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Observações</label>
                <Textarea
                  placeholder="Notas sobre o dia..."
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  rows={2}
                />
              </div>
              <Button onClick={handleAdd} className="w-full">Registrar Dia</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-gray-100 border-b">
            <tr>
              <th className="text-left px-4 py-2">Data</th>
              <th className="text-left px-4 py-2">Lote</th>
              <th className="text-left px-4 py-2">Temperatura</th>
              <th className="text-left px-4 py-2">Umidade</th>
              <th className="text-left px-4 py-2">Observações</th>
            </tr>
          </thead>
          <tbody>
            {records.map((record) => (
              <tr key={record.id} className="border-b hover:bg-gray-50">
                <td className="px-4 py-2">{new Date(record.date).toLocaleDateString('pt-BR')}</td>
                <td className="px-4 py-2 font-medium">{record.batch}</td>
                <td className="px-4 py-2">{record.temperature}°C</td>
                <td className="px-4 py-2">{record.humidity}%</td>
                <td className="px-4 py-2 text-gray-600">{record.notes}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
