'use client'

import { ChevronLeft } from 'lucide-react'
import Link from 'next/link'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'

const suppliers = [
  { id: 1, name: 'Ração Premium', category: 'Ração', status: 'Ativo', rating: 4.5, purchases: 24 },
  { id: 2, name: 'Medicamentos Silva', category: 'Medicamentos', status: 'Ativo', rating: 4.8, purchases: 18 },
  { id: 3, name: 'Equipamentos BR', category: 'Equipamentos', status: 'Ativo', rating: 4.2, purchases: 8 },
]

export default function SuppliersPage() {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <Link href="/modules/purchases" className="text-green-600 hover:text-green-700 flex items-center gap-2 mb-4">
            <ChevronLeft className="w-4 h-4" /> Voltar
          </Link>
          <h1 className="text-3xl font-bold text-gray-900">Gestão de Fornecedores</h1>
          <p className="text-gray-600 mt-2">Cadastro e avaliação de fornecedores</p>
        </div>
        <Button className="bg-green-600 hover:bg-green-700">+ Novo Fornecedor</Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {suppliers.map((supplier) => (
          <Card key={supplier.id} className="bg-white border-green-200">
            <CardContent className="pt-6">
              <h3 className="font-semibold text-gray-900">{supplier.name}</h3>
              <p className="text-sm text-gray-600 mt-2">{supplier.category}</p>
              <div className="mt-4 space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Avaliação</span>
                  <span className="text-sm font-semibold text-gray-900">{supplier.rating}/5 ⭐</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Compras</span>
                  <span className="text-sm font-semibold text-gray-900">{supplier.purchases}</span>
                </div>
              </div>
              <div className="mt-4 pt-4 border-t border-green-200">
                <Button variant="outline" size="sm" className="w-full bg-transparent">Ver Detalhes</Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
