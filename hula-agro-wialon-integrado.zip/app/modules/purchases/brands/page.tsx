'use client'

import { ChevronLeft } from 'lucide-react'
import Link from 'next/link'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'

const brands = [
  { id: 1, name: 'Ração Premium', type: 'Ração', products: 8, rating: 4.5 },
  { id: 2, name: 'Medicamentos Silva', type: 'Medicamentos', products: 24, rating: 4.8 },
  { id: 3, name: 'Equipamentos BR', type: 'Equipamentos', products: 15, rating: 4.2 },
  { id: 4, name: 'Vitaminas Plus', type: 'Suplementos', products: 12, rating: 4.6 },
]

export default function BrandsPage() {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <Link href="/modules/purchases" className="text-green-600 hover:text-green-700 flex items-center gap-2 mb-4">
            <ChevronLeft className="w-4 h-4" /> Voltar
          </Link>
          <h1 className="text-3xl font-bold text-gray-900">Gestão de Marcas</h1>
          <p className="text-gray-600 mt-2">Catálogo de marcas e fabricantes</p>
        </div>
        <Button className="bg-green-600 hover:bg-green-700">+ Nova Marca</Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {brands.map((brand) => (
          <Card key={brand.id} className="bg-white border-green-200">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-gray-900">{brand.name}</h3>
                  <p className="text-sm text-gray-600 mt-2">{brand.type} • {brand.products} produtos</p>
                  <p className="text-sm text-yellow-600 mt-1">Rating: {brand.rating}/5 ⭐</p>
                </div>
                <Button variant="outline" size="sm">Editar</Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
