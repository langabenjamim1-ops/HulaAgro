'use client'

import { ChevronLeft } from 'lucide-react'
import Link from 'next/link'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'

const categories = [
  { id: 1, name: 'Ração', products: 12, suppliers: 4, budget: 'R$ 50.000' },
  { id: 2, name: 'Medicamentos', products: 24, suppliers: 6, budget: 'R$ 15.000' },
  { id: 3, name: 'Equipamentos', products: 18, suppliers: 5, budget: 'R$ 80.000' },
  { id: 4, name: 'Suplementos', products: 8, suppliers: 3, budget: 'R$ 12.000' },
  { id: 5, name: 'Limpeza', products: 6, suppliers: 2, budget: 'R$ 5.000' },
]

export default function CategoriesPage() {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <Link href="/modules/purchases" className="text-green-600 hover:text-green-700 flex items-center gap-2 mb-4">
            <ChevronLeft className="w-4 h-4" /> Voltar
          </Link>
          <h1 className="text-3xl font-bold text-gray-900">Gestão de Categorias</h1>
          <p className="text-gray-600 mt-2">Organização e controle de categorias de produtos</p>
        </div>
        <Button className="bg-green-600 hover:bg-green-700">+ Nova Categoria</Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {categories.map((cat) => (
          <Card key={cat.id} className="bg-white border-green-200">
            <CardContent className="pt-6">
              <h3 className="font-semibold text-gray-900">{cat.name}</h3>
              <div className="mt-4 space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Produtos</span>
                  <span className="text-sm font-semibold text-gray-900">{cat.products}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Fornecedores</span>
                  <span className="text-sm font-semibold text-gray-900">{cat.suppliers}</span>
                </div>
                <div className="flex justify-between pt-2 border-t border-green-200">
                  <span className="text-sm text-gray-600">Orçamento</span>
                  <span className="text-sm font-semibold text-green-600">{cat.budget}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
