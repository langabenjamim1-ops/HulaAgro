'use client'

import { ChevronLeft } from 'lucide-react'
import Link from 'next/link'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'

const purchases = [
  { id: 1, supplier: 'Ração Premium', date: '2024-02-01', amount: 'R$ 5.000', items: 12, status: 'Recebida' },
  { id: 2, supplier: 'Medicamentos Silva', date: '2024-02-03', amount: 'R$ 1.200', items: 8, status: 'Em Trânsito' },
  { id: 3, supplier: 'Equipamentos BR', date: '2024-02-05', amount: 'R$ 8.500', items: 3, status: 'Pendente' },
]

export default function ManagementPage() {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <Link href="/modules/purchases" className="text-green-600 hover:text-green-700 flex items-center gap-2 mb-4">
            <ChevronLeft className="w-4 h-4" /> Voltar
          </Link>
          <h1 className="text-3xl font-bold text-gray-900">Gestão de Compras</h1>
          <p className="text-gray-600 mt-2">Controle de pedidos e compras</p>
        </div>
        <Button className="bg-green-600 hover:bg-green-700">+ Nova Compra</Button>
      </div>

      <div className="space-y-4">
        {purchases.map((purchase) => (
          <Card key={purchase.id} className="bg-white border-green-200">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-gray-900">{purchase.supplier}</h3>
                  <p className="text-sm text-gray-600 mt-2">{purchase.date} • {purchase.items} itens • {purchase.amount}</p>
                </div>
                <div className="flex items-center gap-4">
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                    purchase.status === 'Recebida' ? 'bg-green-100 text-green-800' :
                    purchase.status === 'Em Trânsito' ? 'bg-blue-100 text-blue-800' :
                    'bg-yellow-100 text-yellow-800'
                  }`}>
                    {purchase.status}
                  </span>
                  <Button variant="outline" size="sm">Detalhes</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
