'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'

export default function PackagingCostsPage() {
  const [packaging, setPackaging] = useState([
    {
      id: '1',
      type: 'Favo para Ovos',
      size: '30 ovos',
      cost: 1.50,
      unit: 'unidade',
      supplier: 'Embal Pack',
      quantity: 500,
    },
    {
      id: '2',
      type: 'Favo para Ovos',
      size: '60 ovos',
      cost: 2.80,
      unit: 'unidade',
      supplier: 'Embal Pack',
      quantity: 300,
    },
    {
      id: '3',
      type: 'Embalagem Frango',
      size: '1kg',
      cost: 0.45,
      unit: 'unidade',
      supplier: 'Flex Pack',
      quantity: 1000,
    },
    {
      id: '4',
      type: 'Embalagem Frango',
      size: '2kg',
      cost: 0.75,
      unit: 'unidade',
      supplier: 'Flex Pack',
      quantity: 800,
    },
  ])

  const [open, setOpen] = useState(false)
  const [formData, setFormData] = useState({
    type: 'Favo para Ovos',
    size: '',
    cost: '',
    supplier: '',
    quantity: '',
  })

  const handleAddPackaging = () => {
    if (formData.type && formData.size && formData.cost) {
      setPackaging([
        ...packaging,
        {
          id: Date.now().toString(),
          type: formData.type,
          size: formData.size,
          cost: parseFloat(formData.cost),
          unit: 'unidade',
          supplier: formData.supplier || 'Não informado',
          quantity: parseInt(formData.quantity) || 0,
        },
      ])
      setFormData({ type: 'Favo para Ovos', size: '', cost: '', supplier: '', quantity: '' })
      setOpen(false)
    }
  }

  const totalCostFavos = packaging
    .filter((p) => p.type === 'Favo para Ovos')
    .reduce((sum, p) => sum + p.cost * p.quantity, 0)

  const totalCostEmbalagem = packaging
    .filter((p) => p.type === 'Embalagem Frango')
    .reduce((sum, p) => sum + p.cost * p.quantity, 0)

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-amber-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900">Custos de Embalagem</h1>
          <p className="text-gray-600 mt-2">Gerencie os custos de favos para ovos e embalagem para frango</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Total Favo Ovos</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-600">
                R$ {totalCostFavos.toFixed(2)}
              </div>
              <p className="text-xs text-gray-500 mt-1">
                {packaging.filter((p) => p.type === 'Favo para Ovos').reduce((sum, p) => sum + p.quantity, 0)} unidades
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Total Embalagem Frango</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-600">
                R$ {totalCostEmbalagem.toFixed(2)}
              </div>
              <p className="text-xs text-gray-500 mt-1">
                {packaging.filter((p) => p.type === 'Embalagem Frango').reduce((sum, p) => sum + p.quantity, 0)} unidades
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Total Geral</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-purple-600">
                R$ {(totalCostFavos + totalCostEmbalagem).toFixed(2)}
              </div>
              <p className="text-xs text-gray-500 mt-1">
                {packaging.reduce((sum, p) => sum + p.quantity, 0)} unidades
              </p>
            </CardContent>
          </Card>
        </div>

        <Card className="mb-6">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Embalagens Cadastradas</CardTitle>
              <CardDescription>Listagem de todos os tipos de embalagem e seus custos</CardDescription>
            </div>
            <Dialog open={open} onOpenChange={setOpen}>
              <DialogTrigger asChild>
                <Button>+ Nova Embalagem</Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Adicionar Embalagem</DialogTitle>
                  <DialogDescription>Cadastre um novo tipo de embalagem com seu custo</DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium">Tipo de Embalagem</label>
                    <Select value={formData.type} onValueChange={(value) => setFormData({ ...formData, type: value })}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Favo para Ovos">Favo para Ovos</SelectItem>
                        <SelectItem value="Embalagem Frango">Embalagem Frango</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-sm font-medium">Tamanho/Especificação</label>
                    <Input
                      placeholder="Ex: 30 ovos, 1kg"
                      value={formData.size}
                      onChange={(e) => setFormData({ ...formData, size: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Custo (R$)</label>
                    <Input
                      type="number"
                      placeholder="0.00"
                      step="0.01"
                      value={formData.cost}
                      onChange={(e) => setFormData({ ...formData, cost: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Fornecedor</label>
                    <Input
                      placeholder="Nome do fornecedor"
                      value={formData.supplier}
                      onChange={(e) => setFormData({ ...formData, supplier: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Quantidade em Estoque</label>
                    <Input
                      type="number"
                      placeholder="0"
                      value={formData.quantity}
                      onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                    />
                  </div>
                  <Button onClick={handleAddPackaging} className="w-full">
                    Adicionar
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {packaging.map((item) => (
                <div key={item.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                  <div className="flex-1">
                    <div className="flex items-center gap-3">
                      <Badge variant={item.type === 'Favo para Ovos' ? 'default' : 'secondary'}>
                        {item.type}
                      </Badge>
                      <span className="font-semibold text-gray-900">{item.size}</span>
                    </div>
                    <p className="text-sm text-gray-600 mt-1">Fornecedor: {item.supplier}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-gray-900">R$ {item.cost.toFixed(2)}</p>
                    <p className="text-sm text-gray-500">{item.quantity} unidades</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Análise de Custos</CardTitle>
            <CardDescription>Comparativo de custos por tipo de embalagem</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold text-lg mb-4">Favo para Ovos</h3>
                {packaging
                  .filter((p) => p.type === 'Favo para Ovos')
                  .map((item) => (
                    <div key={item.id} className="flex justify-between text-sm mb-2">
                      <span className="text-gray-600">{item.size}</span>
                      <span className="font-medium">R$ {item.cost.toFixed(2)} c/u</span>
                    </div>
                  ))}
              </div>
              <div>
                <h3 className="font-semibold text-lg mb-4">Embalagem Frango</h3>
                {packaging
                  .filter((p) => p.type === 'Embalagem Frango')
                  .map((item) => (
                    <div key={item.id} className="flex justify-between text-sm mb-2">
                      <span className="text-gray-600">{item.size}</span>
                      <span className="font-medium">R$ {item.cost.toFixed(2)} c/u</span>
                    </div>
                  ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
