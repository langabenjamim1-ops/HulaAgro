'use client'

import { ChevronLeft } from 'lucide-react'
import Link from 'next/link'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'

const products = [
  { id: 1, name: 'Ração Poedeira Premium', category: 'Ração', supplier: 'Ração Premium', price: 'R$ 45/kg', stock: '2.500 kg' },
  { id: 2, name: 'Amoxicilina 500mg', category: 'Medicamento', supplier: 'Medicamentos Silva', price: 'R$ 120/frasco', stock: '50 frascos' },
  { id: 3, name: 'Bebedouro Automático', category: 'Equipamento', supplier: 'Equipamentos BR', price: 'R$ 850/unidade', stock: '12 un' },
]

export default function ProductsPage() {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <Link href="/modules/purchases" className="text-green-600 hover:text-green-700 flex items-center gap-2 mb-4">
            <ChevronLeft className="w-4 h-4" /> Voltar
          </Link>
          <h1 className="text-3xl font-bold text-gray-900">Gestão de Produtos</h1>
          <p className="text-gray-600 mt-2">Catálogo e controle de produtos</p>
        </div>
        <Button className="bg-green-600 hover:bg-green-700">+ Novo Produto</Button>
      </div>

      <div className="space-y-4">
        {products.map((product) => (
          <Card key={product.id} className="bg-white border-green-200">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-gray-900">{product.name}</h3>
                  <p className="text-sm text-gray-600 mt-2">{product.category} • {product.supplier}</p>
                  <p className="text-sm text-gray-600 mt-1">Preço: {product.price} • Estoque: {product.stock}</p>
                </div>
                <Button variant="outline" size="sm">Editar</Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
