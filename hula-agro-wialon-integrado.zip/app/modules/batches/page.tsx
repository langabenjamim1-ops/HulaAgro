'use client'

import Link from 'next/link'
import { ArrowLeft, Plus } from 'lucide-react'

export default function BatchesPage() {
  const submodules = [
    {
      title: 'Criar Lote',
      description: 'Registrar um novo lote de aves',
      href: '/modules/batches/create',
      icon: '➕',
    },
    {
      title: 'Lista de Lotes',
      description: 'Visualizar todos os lotes cadastrados',
      href: '/modules/batches/list',
      icon: '📚',
    },
    {
      title: 'Gestão de Galpões',
      description: 'Administrar galpões e sua ocupação',
      href: '/modules/batches/facilities',
      icon: '🏢',
    },
    {
      title: 'Associar Genética',
      description: 'Definir genética para cada lote',
      href: '/modules/batches/genetics',
      icon: '🧬',
    },
  ]

  return (
    <div className="w-full font-montserrat">
      {/* Header */}
      <div className="mb-8 flex items-start justify-between">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <Link href="/dashboard" className="p-1 hover:bg-gray-100 rounded transition-colors">
              <ArrowLeft className="w-5 h-5 text-gray-600" />
            </Link>
            <span className="text-3xl">📋</span>
          </div>
          <h1 className="text-2xl font-montserrat font-bold text-gray-900">Gestão de Lotes</h1>
          <p className="text-gray-600 text-sm mt-1">Gerencie os lotes de aves da sua granja</p>
        </div>
        <button className="px-4 py-2 bg-[#22C55E] text-white rounded hover:bg-[#16a34a] transition-colors font-montserrat font-semibold text-sm flex items-center gap-2">
          <Plus className="w-4 h-4" />
          Novo
        </button>
      </div>

      {/* Grid of Submodules */}
      <div className="grid grid-cols-4 gap-4">
        {submodules.map((module) => (
          <Link key={module.href} href={module.href} className="group">
            <div className="bg-white border border-gray-200 rounded-lg p-5 hover:shadow-md hover:border-[#22C55E] transition-all cursor-pointer h-full flex flex-col items-center text-center">
              <div className="text-5xl mb-3">{module.icon}</div>
              <h3 className="font-montserrat font-semibold text-gray-900 text-xs mb-1 leading-tight">
                {module.title}
              </h3>
              <p className="text-xs text-gray-500 font-montserrat leading-tight">
                {module.description}
              </p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  )
}
