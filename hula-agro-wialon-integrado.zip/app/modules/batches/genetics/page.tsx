'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { AlertCircle, Loader } from 'lucide-react'

interface GeneticRecord {
  id: string
  batch_id: string
  batch_name: string
  genetics_name: string
  created_at: string
  status: string
}

export default function AssociateGeneticsPage() {
  const [records, setRecords] = useState<GeneticRecord[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [selectedBatch, setSelectedBatch] = useState('')
  const [selectedGenetics, setSelectedGenetics] = useState('')
  const [isSaving, setIsSaving] = useState(false)

  useEffect(() => {
    fetchRecords()
  }, [])

  async function fetchRecords() {
    try {
      setLoading(true)
      setError(null)
      const response = await fetch('/api/genetics')
      if (!response.ok) throw new Error('Failed to fetch records')
      const data = await response.json()
      setRecords(Array.isArray(data) ? data : [])
    } catch (err) {
      console.error('[v0] Fetch error:', err)
      setError('Erro ao carregar registos')
      setRecords([])
    } finally {
      setLoading(false)
    }
  }

  async function handleAssign() {
    if (!selectedBatch || !selectedGenetics) return
    
    try {
      setIsSaving(true)
      const response = await fetch('/api/genetics', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          batch_name: selectedBatch,
          genetics_name: selectedGenetics,
          created_at: new Date().toISOString(),
          status: 'Ativo',
        }),
      })
      
      if (!response.ok) throw new Error('Failed to save')
      const newRecord = await response.json()
      setRecords([newRecord, ...records])
      setSelectedBatch('')
      setSelectedGenetics('')
    } catch (err) {
      console.error('[v0] Save error:', err)
      setError('Erro ao guardar associação')
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-green-900">Associar Genética a Lotes</h1>
        <p className="text-gray-600 mt-2">Defina a genética para cada lote</p>
      </div>

      {error && (
        <div className="flex gap-2 p-4 bg-red-50 border border-red-200 rounded-lg">
          <AlertCircle className="h-5 w-5 text-red-600 flex-shrink-0" />
          <span className="text-red-800">{error}</span>
        </div>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Nova Associação</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm font-medium">Selecione o Lote</label>
            <select
              className="w-full px-3 py-2 border border-gray-300 rounded-md"
              value={selectedBatch}
              onChange={(e) => setSelectedBatch(e.target.value)}
              disabled={isSaving}
            >
              <option value="">Selecionar lote</option>
              <option value="Lote Postura 001">Lote Postura 001</option>
              <option value="Lote Corte 001">Lote Corte 001</option>
              <option value="Lote Postura 002">Lote Postura 002</option>
            </select>
          </div>

          <div>
            <label className="text-sm font-medium">Selecione a Genética</label>
            <select
              className="w-full px-3 py-2 border border-gray-300 rounded-md"
              value={selectedGenetics}
              onChange={(e) => setSelectedGenetics(e.target.value)}
              disabled={isSaving}
            >
              <option value="">Selecionar genética</option>
              <option value="Lohmann Brown">Lohmann Brown</option>
              <option value="Cobb 500">Cobb 500</option>
              <option value="Embrapa">Embrapa</option>
            </select>
          </div>

          <Button 
            onClick={handleAssign} 
            className="w-full bg-green-600 hover:bg-green-700 disabled:opacity-50"
            disabled={isSaving || !selectedBatch || !selectedGenetics}
          >
            {isSaving && <Loader className="h-4 w-4 mr-2 animate-spin" />}
            {isSaving ? 'Guardando...' : 'Associar Genética'}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Associações Cadastradas</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center py-8">
              <Loader className="h-6 w-6 animate-spin text-green-600" />
            </div>
          ) : records.length === 0 ? (
            <p className="text-center text-gray-500 py-8">Nenhuma associação cadastrada</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-100 border-b">
                  <tr>
                    <th className="text-left px-4 py-2">Lote</th>
                    <th className="text-left px-4 py-2">Genética</th>
                    <th className="text-left px-4 py-2">Data</th>
                    <th className="text-left px-4 py-2">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {records.map((record) => (
                    <tr key={record.id} className="border-b hover:bg-gray-50">
                      <td className="px-4 py-2">{record.batch_name}</td>
                      <td className="px-4 py-2">{record.genetics_name}</td>
                      <td className="px-4 py-2">{new Date(record.created_at).toLocaleDateString('pt-BR')}</td>
                      <td className="px-4 py-2">
                        <span className="px-2 py-1 bg-green-100 text-green-800 rounded text-xs font-medium">
                          {record.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
