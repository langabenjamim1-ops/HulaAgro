'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'

export default function FacilitiesPage() {
  const [facilities, setFacilities] = useState([
    { id: 1, name: 'Galpão 1', capacity: 5000, occupied: 5000, type: 'Postura' },
    { id: 2, name: 'Galpão 2', capacity: 10000, occupied: 10000, type: 'Corte' },
    { id: 3, name: 'Galpão 3', capacity: 8000, occupied: 4500, type: 'Postura' },
  ])
  const [open, setOpen] = useState(false)
  const [formData, setFormData] = useState({ name: '', capacity: '', type: '' })

  const handleAdd = () => {
    if (formData.name && formData.capacity) {
      setFacilities([
        ...facilities,
        {
          id: Date.now(),
          name: formData.name,
          capacity: Number(formData.capacity),
          occupied: 0,
          type: formData.type,
        },
      ])
      setFormData({ name: '', capacity: '', type: '' })
      setOpen(false)
    }
  }

  const getOccupancyPercent = (occupied: number, capacity: number) => {
    return Math.round((occupied / capacity) * 100)
  }

  const getOccupancyColor = (percent: number) => {
    if (percent >= 90) return 'bg-red-500'
    if (percent >= 70) return 'bg-yellow-500'
    return 'bg-green-500'
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Gestão de Galpões</h1>
          <p className="text-gray-600 mt-2">Administre os galpões da sua granja</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button>+ Novo Galpão</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Adicionar Novo Galpão</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Nome</label>
                <Input
                  placeholder="Ex: Galpão 4"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Capacidade</label>
                <Input
                  type="number"
                  placeholder="5000"
                  value={formData.capacity}
                  onChange={(e) => setFormData({ ...formData, capacity: e.target.value })}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Tipo</label>
                <select
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  value={formData.type}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                >
                  <option value="">Selecionar tipo</option>
                  <option value="Postura">Postura</option>
                  <option value="Corte">Corte</option>
                  <option value="Misto">Misto</option>
                </select>
              </div>
              <Button onClick={handleAdd} className="w-full">Adicionar Galpão</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {facilities.map((facility) => {
          const occupancyPercent = getOccupancyPercent(facility.occupied, facility.capacity)
          return (
            <Card key={facility.id}>
              <CardHeader>
                <CardTitle className="text-lg">{facility.name}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Ocupação: {facility.occupied}/{facility.capacity} aves</span>
                    <span className="font-semibold">{occupancyPercent}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className={`h-2 rounded-full transition-all ${getOccupancyColor(occupancyPercent)}`}
                      style={{ width: `${Math.min(occupancyPercent, 100)}%` }}
                    />
                  </div>
                </div>
                <div className="text-sm text-gray-600">Tipo: {facility.type}</div>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
