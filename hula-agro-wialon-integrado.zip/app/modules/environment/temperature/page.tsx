'use client'

import { useState, useEffect } from 'react'
import { ChevronLeft, Loader } from 'lucide-react'
import Link from 'next/link'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'

interface TemperatureReading {
  id: string
  facility_id: string
  facility_name: string
  current_value: number
  min_threshold: number
  max_threshold: number
  recorded_at: string
  status: 'normal' | 'warning' | 'critical'
}

export default function TemperaturePage() {
  const [data, setData] = useState<TemperatureReading[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchTemperatureData()
  }, [])

  async function fetchTemperatureData() {
    try {
      setLoading(true)
      const response = await fetch('/api/environmental-monitoring?type=temperature')
      if (!response.ok) throw new Error('Failed to fetch')
      const readings = await response.json()
      
      // Group by facility and get latest reading
      const grouped = Array.isArray(readings) ? readings : []
      setData(grouped)
    } catch (error) {
      console.error('[v0] Fetch error:', error)
      setData([])
    } finally {
      setLoading(false)
    }
  }
  return (
    <div className="space-y-8">
      <div>
        <Link href="/modules/environment" className="text-green-600 hover:text-green-700 flex items-center gap-2 mb-4">
          <ChevronLeft className="w-4 h-4" /> Voltar
        </Link>
        <h1 className="text-3xl font-bold text-gray-900">Monitoramento de Temperatura</h1>
        <p className="text-gray-600 mt-2">Controle de temperatura em tempo real</p>
      </div>

      {loading ? (
        <div className="flex justify-center py-12">
          <Loader className="h-8 w-8 animate-spin text-green-600" />
        </div>
      ) : data.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-lg border">
          <p className="text-gray-500">Nenhum dados de temperatura disponíveis</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {data.map((reading) => (
            <Card key={reading.id} className="bg-white border-green-200">
              <CardContent className="pt-6">
                <h3 className="font-semibold text-gray-900">{reading.facility_name}</h3>
                <div className="mt-4 space-y-2">
                  <p className="text-3xl font-bold text-gray-900">{reading.current_value}°C</p>
                  <p className="text-sm text-gray-600">Min: {reading.min_threshold}°C • Max: {reading.max_threshold}°C</p>
                  <p className="text-sm">
                    <span className={`px-2 py-1 rounded-full ${
                      reading.status === 'normal' ? 'bg-green-100 text-green-800' : 
                      reading.status === 'warning' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-red-100 text-red-800'
                    }`}>
                      {reading.status === 'normal' ? 'Normal' : reading.status === 'warning' ? 'Alerta' : 'Crítico'}
                    </span>
                  </p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <div className="bg-white p-6 rounded-lg border border-green-200">
        <h3 className="font-semibold text-gray-900 mb-4">Histórico</h3>
        <p className="text-gray-600">Gráfico de temperatura será exibido aqui</p>
      </div>
    </div>
  )
}
