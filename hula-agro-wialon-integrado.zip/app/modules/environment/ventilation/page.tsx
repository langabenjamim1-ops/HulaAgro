'use client'

import { ChevronLeft } from 'lucide-react'
import Link from 'next/link'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'

const ventilationData = [
  { id: 1, galpao: 'Galpão 1', speed: '65%', status: 'Ativo', lastMaintenance: '2024-02-01' },
  { id: 2, galpao: 'Galpão 2', speed: '90%', status: 'Alta Velocidade', lastMaintenance: '2024-01-28' },
  { id: 3, galpao: 'Galpão 3', speed: '45%', status: 'Ativo', lastMaintenance: '2024-02-05' },
]

export default function VentilationPage() {
  return (
    <div className="space-y-8">
      <div>
        <Link href="/modules/environment" className="text-green-600 hover:text-green-700 flex items-center gap-2 mb-4">
          <ChevronLeft className="w-4 h-4" /> Voltar
        </Link>
        <h1 className="text-3xl font-bold text-gray-900">Sistema de Ventilação</h1>
        <p className="text-gray-600 mt-2">Controle do sistema de ventilação</p>
      </div>

      <div className="space-y-4">
        {ventilationData.map((data) => (
          <Card key={data.id} className="bg-white border-green-200">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-gray-900">{data.galpao}</h3>
                  <p className="text-sm text-gray-600 mt-2">Velocidade: {data.speed} • Status: {data.status}</p>
                  <p className="text-xs text-gray-500 mt-1">Última manutenção: {data.lastMaintenance}</p>
                </div>
                <Button variant="outline" size="sm">Ajustar</Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
