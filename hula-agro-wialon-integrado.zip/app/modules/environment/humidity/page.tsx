'use client'

import { ChevronLeft } from 'lucide-react'
import Link from 'next/link'
import { Card, CardContent } from '@/components/ui/card'

const humidityData = [
  { id: 1, galpao: 'Galpão 1', current: '65%', min: '60%', max: '75%', status: 'Normal' },
  { id: 2, galpao: 'Galpão 2', current: '82%', min: '60%', max: '75%', status: 'Crítico' },
  { id: 3, galpao: 'Galpão 3', current: '68%', min: '60%', max: '75%', status: 'Normal' },
]

export default function HumidityPage() {
  return (
    <div className="space-y-8">
      <div>
        <Link href="/modules/environment" className="text-green-600 hover:text-green-700 flex items-center gap-2 mb-4">
          <ChevronLeft className="w-4 h-4" /> Voltar
        </Link>
        <h1 className="text-3xl font-bold text-gray-900">Monitoramento de Umidade</h1>
        <p className="text-gray-600 mt-2">Controle de níveis de umidade relativa</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {humidityData.map((data) => (
          <Card key={data.id} className="bg-white border-green-200">
            <CardContent className="pt-6">
              <h3 className="font-semibold text-gray-900">{data.galpao}</h3>
              <div className="mt-4 space-y-2">
                <p className="text-3xl font-bold text-gray-900">{data.current}</p>
                <p className="text-sm text-gray-600">Min: {data.min} • Max: {data.max}</p>
                <p className="text-sm"><span className={`px-2 py-1 rounded-full ${data.status === 'Normal' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>{data.status}</span></p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
