'use client'

import { ChevronLeft } from 'lucide-react'
import Link from 'next/link'
import { Card, CardContent } from '@/components/ui/card'

const energyData = [
  { id: 1, galpao: 'Galpão 1', dailyUsage: '124 kWh', monthlyUsage: '3.720 kWh', cost: 'R$ 1.116' },
  { id: 2, galpao: 'Galpão 2', dailyUsage: '138 kWh', monthlyUsage: '4.140 kWh', cost: 'R$ 1.242' },
  { id: 3, galpao: 'Galpão 3', dailyUsage: '112 kWh', monthlyUsage: '3.360 kWh', cost: 'R$ 1.008' },
]

export default function EnergyPage() {
  return (
    <div className="space-y-8">
      <div>
        <Link href="/modules/environment" className="text-green-600 hover:text-green-700 flex items-center gap-2 mb-4">
          <ChevronLeft className="w-4 h-4" /> Voltar
        </Link>
        <h1 className="text-3xl font-bold text-gray-900">Consumo de Energia</h1>
        <p className="text-gray-600 mt-2">Análise de consumo energético por galpão</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {energyData.map((data) => (
          <Card key={data.id} className="bg-white border-green-200">
            <CardContent className="pt-6">
              <h3 className="font-semibold text-gray-900">{data.galpao}</h3>
              <div className="mt-4 space-y-2">
                <div>
                  <p className="text-xs text-gray-600">Consumo Diário</p>
                  <p className="text-2xl font-bold text-gray-900">{data.dailyUsage}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-600">Consumo Mensal</p>
                  <p className="text-lg font-semibold text-gray-900">{data.monthlyUsage}</p>
                </div>
                <div className="pt-2 border-t border-green-200">
                  <p className="text-xs text-gray-600">Custo Mensal</p>
                  <p className="text-xl font-bold text-green-600">{data.cost}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
