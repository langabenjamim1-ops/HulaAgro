'use client'

import Link from 'next/link'
import { ArrowLeft, Plus, AlertCircle, Clock, TrendingUp } from 'lucide-react'

const creditAlerts = [
  { id: 1, supplier: 'Ração Premium', amount: 'R$ 5.000', status: 'Vencido', days: 'Vencido há 2 dias' },
  { id: 2, supplier: 'Medicamentos Silva', amount: 'R$ 1.200', status: 'Atenção', days: 'Vence em 4 dias' },
  { id: 3, supplier: 'Equipamentos BR', amount: 'R$ 8.500', status: 'Aberto', days: 'Vence em 18 dias' },
]

export default function CreditAlertsPage() {
  return (
    <div className="w-full font-montserrat">
      <div className="mb-8 flex items-start justify-between">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <Link href="/dashboard" className="p-1 hover:bg-gray-100 rounded transition-colors">
              <ArrowLeft className="w-5 h-5 text-gray-600" />
            </Link>
            <span className="text-3xl">💳</span>
          </div>
          <h1 className="text-2xl font-montserrat font-bold text-gray-900">Alertas de Crédito</h1>
          <p className="text-gray-600 text-sm mt-1">Monitoramento de contas a pagar e atrasos</p>
        </div>
        <button className="px-4 py-2 bg-[#22C55E] text-white rounded hover:bg-[#16a34a] transition-colors font-montserrat font-semibold text-sm flex items-center gap-2">
          <Plus className="w-4 h-4" /> Novo
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-3 gap-4 mb-8">
        <div className="bg-white border border-gray-200 rounded-lg p-5">
          <div className="flex items-center justify-between mb-2">
            <span className="text-red-600"><AlertCircle className="w-5 h-5" /></span>
            <span className="text-2xl font-bold text-red-600">1</span>
          </div>
          <p className="text-xs text-gray-600 font-montserrat">Pagamentos Vencidos</p>
        </div>
        <div className="bg-white border border-gray-200 rounded-lg p-5">
          <div className="flex items-center justify-between mb-2">
            <span className="text-yellow-600"><Clock className="w-5 h-5" /></span>
            <span className="text-2xl font-bold text-yellow-600">1</span>
          </div>
          <p className="text-xs text-gray-600 font-montserrat">Atenção (próx. vencimento)</p>
        </div>
        <div className="bg-white border border-gray-200 rounded-lg p-5">
          <div className="flex items-center justify-between mb-2">
            <span className="text-green-600"><TrendingUp className="w-5 h-5" /></span>
            <span className="text-2xl font-bold text-green-600">R$ 14.700</span>
          </div>
          <p className="text-xs text-gray-600 font-montserrat">Total em Aberto</p>
        </div>
      </div>

      {/* Alerts List */}
      <div className="space-y-3">
        {creditAlerts.map((alert) => (
          <div key={alert.id} className="bg-white border border-gray-200 rounded-lg p-4 hover:shadow-md transition-all">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <h3 className="font-montserrat font-semibold text-gray-900 text-sm">{alert.supplier}</h3>
                <p className="text-xs text-gray-600 mt-0.5 font-montserrat">{alert.days}</p>
              </div>
              <div className="flex items-center gap-4">
                <span className="text-sm font-semibold text-gray-900 font-montserrat">{alert.amount}</span>
                <span className={`px-3 py-1 rounded text-xs font-semibold whitespace-nowrap ${
                  alert.status === 'Vencido' ? 'bg-red-100 text-red-800' :
                  alert.status === 'Atenção' ? 'bg-yellow-100 text-yellow-800' :
                  'bg-green-100 text-green-800'
                } font-montserrat`}>
                  {alert.status}
                </span>
                <button className="px-3 py-1 bg-[#22C55E] text-white rounded hover:bg-[#16a34a] transition-colors font-montserrat font-semibold text-xs whitespace-nowrap">
                  Pagar
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
