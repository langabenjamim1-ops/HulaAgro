'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

export default function CostsPage() {
  const costs = [
    { id: 1, feedType: 'Pré-inicial', pricePerKg: 2.85, consumption: 250, totalCost: 712.50 },
    { id: 2, feedType: 'Inicial', pricePerKg: 2.45, consumption: 500, totalCost: 1225.00 },
    { id: 3, feedType: 'Crescimento', pricePerKg: 2.15, consumption: 1500, totalCost: 3225.00 },
    { id: 4, feedType: 'Postura', pricePerKg: 2.35, consumption: 2000, totalCost: 4700.00 },
  ]

  const stats = [
    { label: 'Custo Total de Ração', value: 'R$ 9,862.50', color: 'text-red-600' },
    { label: 'Consumo Total', value: '4.25 ton', color: 'text-blue-600' },
    { label: 'Custo Médio/kg', value: 'R$ 2.32', color: 'text-orange-600' },
    { label: 'Custo por Ave', value: 'R$ 1.97', color: 'text-purple-600' },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Custo da Ração</h1>
        <p className="text-gray-600 mt-2">Análise de custos nutricionais</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {stats.map((stat, idx) => (
          <Card key={idx}>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">{stat.label}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className={`text-xl font-bold ${stat.color}`}>{stat.value}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Custo por Tipo de Ração</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-100 border-b">
                <tr>
                  <th className="text-left px-4 py-2">Tipo de Ração</th>
                  <th className="text-right px-4 py-2">Preço/kg</th>
                  <th className="text-right px-4 py-2">Consumo (kg)</th>
                  <th className="text-right px-4 py-2">Custo Total</th>
                </tr>
              </thead>
              <tbody>
                {costs.map((cost) => (
                  <tr key={cost.id} className="border-b hover:bg-gray-50">
                    <td className="px-4 py-2 font-medium">{cost.feedType}</td>
                    <td className="px-4 py-2 text-right">R$ {cost.pricePerKg.toFixed(2)}</td>
                    <td className="px-4 py-2 text-right">{cost.consumption}</td>
                    <td className="px-4 py-2 text-right font-semibold text-red-600">
                      R$ {cost.totalCost.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot className="bg-gray-50 border-t-2">
                <tr>
                  <td className="px-4 py-2 font-bold">TOTAL</td>
                  <td className="px-4 py-2"></td>
                  <td className="px-4 py-2 text-right font-bold">4250</td>
                  <td className="px-4 py-2 text-right font-bold text-red-600">
                    R$ {costs.reduce((sum, c) => sum + c.totalCost, 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
