'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'

export default function SilosPage() {
  const [silos, setSilos] = useState([
    { id: 1, name: 'Silo 1', feedType: 'Postura', capacity: 5000, current: 4200, lastFilled: '2024-02-01' },
    { id: 2, name: 'Silo 2', feedType: 'Crescimento', capacity: 10000, current: 7500, lastFilled: '2024-02-02' },
    { id: 3, name: 'Silo 3', feedType: 'Inicial', capacity: 3000, current: 800, lastFilled: '2024-01-28' },
  ])
  const [open, setOpen] = useState(false)
  const [formData, setFormData] = useState({ name: '', feedType: '', capacity: '', current: '' })

  const handleAdd = () => {
    if (formData.name && formData.capacity) {
      setSilos([
        ...silos,
        {
          id: Date.now(),
          name: formData.name,
          feedType: formData.feedType,
          capacity: Number(formData.capacity),
          current: Number(formData.current),
          lastFilled: new Date().toISOString().split('T')[0],
        },
      ])
      setFormData({ name: '', feedType: '', capacity: '', current: '' })
      setOpen(false)
    }
  }

  const getOccupancyPercent = (current: number, capacity: number) => {
    return Math.round((current / capacity) * 100)
  }

  const getOccupancyColor = (percent: number) => {
    if (percent <= 20) return 'bg-red-500'
    if (percent <= 50) return 'bg-yellow-500'
    return 'bg-green-500'
  }

  const getTotalCapacity = () => silos.reduce((sum, s) => sum + s.capacity, 0)
  const getTotalCurrent = () => silos.reduce((sum, s) => sum + s.current, 0)

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Controle de Silos</h1>
          <p className="text-gray-600 mt-2">Gerencie o estoque de ração</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button>+ Novo Silo</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Adicionar Novo Silo</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Nome</label>
                <Input
                  placeholder="Ex: Silo 4"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Tipo de Ração</label>
                <select
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  value={formData.feedType}
                  onChange={(e) => setFormData({ ...formData, feedType: e.target.value })}
                >
                  <option value="">Selecionar tipo</option>
                  <option value="Postura">Postura</option>
                  <option value="Crescimento">Crescimento</option>
                  <option value="Inicial">Inicial</option>
                </select>
              </div>
              <div>
                <label className="text-sm font-medium">Capacidade (kg)</label>
                <Input
                  type="number"
                  placeholder="5000"
                  value={formData.capacity}
                  onChange={(e) => setFormData({ ...formData, capacity: e.target.value })}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Quantidade Atual (kg)</label>
                <Input
                  type="number"
                  placeholder="4200"
                  value={formData.current}
                  onChange={(e) => setFormData({ ...formData, current: e.target.value })}
                />
              </div>
              <Button onClick={handleAdd} className="w-full">Adicionar Silo</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Capacidade Total</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{getTotalCapacity().toLocaleString()} kg</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Estoque Atual</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{getTotalCurrent().toLocaleString()} kg</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Disponibilidade</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-600">
              {Math.round((getTotalCurrent() / getTotalCapacity()) * 100)}%
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Espaço Livre</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-600">
              {(getTotalCapacity() - getTotalCurrent()).toLocaleString()} kg
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {silos.map((silo) => {
          const occupancyPercent = getOccupancyPercent(silo.current, silo.capacity)
          return (
            <Card key={silo.id}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle>{silo.name}</CardTitle>
                    <p className="text-sm text-gray-600 mt-1">{silo.feedType}</p>
                  </div>
                  <span className="text-sm text-gray-600">Última reposição: {new Date(silo.lastFilled).toLocaleDateString('pt-BR')}</span>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>{silo.current} / {silo.capacity} kg</span>
                    <span className="font-semibold">{occupancyPercent}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-3">
                    <div
                      className={`h-3 rounded-full transition-all ${getOccupancyColor(occupancyPercent)}`}
                      style={{ width: `${Math.min(occupancyPercent, 100)}%` }}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
