'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'

export default function PhasesPage() {
  const [phases, setPhases] = useState([
    { id: 1, name: 'Fase 1 (0-4 semanas)', age: '0-4', feedType: 'Pré-inicial', protein: 24, metabolizableEnergy: 2800 },
    { id: 2, name: 'Fase 2 (5-8 semanas)', age: '5-8', feedType: 'Inicial', protein: 22, metabolizableEnergy: 2750 },
    { id: 3, name: 'Fase 3 (9-12 semanas)', age: '9-12', feedType: 'Crescimento', protein: 18, metabolizableEnergy: 2700 },
  ])
  const [open, setOpen] = useState(false)
  const [formData, setFormData] = useState({ name: '', age: '', feedType: '', protein: '', metabolizableEnergy: '' })

  const handleAdd = () => {
    if (formData.name && formData.age) {
      setPhases([
        ...phases,
        {
          id: Date.now(),
          name: formData.name,
          age: formData.age,
          feedType: formData.feedType,
          protein: Number(formData.protein),
          metabolizableEnergy: Number(formData.metabolizableEnergy),
        },
      ])
      setFormData({ name: '', age: '', feedType: '', protein: '', metabolizableEnergy: '' })
      setOpen(false)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Fases de Criação</h1>
          <p className="text-gray-600 mt-2">Defina as fases nutricionais de desenvolvimento</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button>+ Nova Fase</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Adicionar Nova Fase</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Nome da Fase</label>
                <Input
                  placeholder="Ex: Fase 1"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Idade (semanas)</label>
                <Input
                  placeholder="Ex: 0-4"
                  value={formData.age}
                  onChange={(e) => setFormData({ ...formData, age: e.target.value })}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Tipo de Ração</label>
                <Input
                  placeholder="Ex: Pré-inicial"
                  value={formData.feedType}
                  onChange={(e) => setFormData({ ...formData, feedType: e.target.value })}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Proteína (%)</label>
                <Input
                  type="number"
                  placeholder="24"
                  value={formData.protein}
                  onChange={(e) => setFormData({ ...formData, protein: e.target.value })}
                />
              </div>
              <div>
                <label className="text-sm font-medium">Energia Metabolizável (kcal/kg)</label>
                <Input
                  type="number"
                  placeholder="2800"
                  value={formData.metabolizableEnergy}
                  onChange={(e) => setFormData({ ...formData, metabolizableEnergy: e.target.value })}
                />
              </div>
              <Button onClick={handleAdd} className="w-full">Adicionar Fase</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {phases.map((phase) => (
          <Card key={phase.id}>
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle>{phase.name}</CardTitle>
                  <p className="text-sm text-gray-600 mt-1">Ração: {phase.feedType}</p>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <p className="text-sm text-gray-600">Idade</p>
                  <p className="text-lg font-semibold">{phase.age} semanas</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Proteína</p>
                  <p className="text-lg font-semibold">{phase.protein}%</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Energia</p>
                  <p className="text-lg font-semibold">{phase.metabolizableEnergy} kcal/kg</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
