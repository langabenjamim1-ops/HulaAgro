'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'

export default function ConsumptionPage() {
  const consumptionData = [
    { week: '1', expected: 50, actual: 48 },
    { week: '2', expected: 120, actual: 118 },
    { week: '3', expected: 200, actual: 205 },
    { week: '4', expected: 280, actual: 275 },
    { week: '5', expected: 360, actual: 365 },
    { week: '6', expected: 440, actual: 438 },
    { week: '7', expected: 520, actual: 525 },
    { week: '8', expected: 600, actual: 595 },
  ]

  const stats = [
    { label: 'Consumo Total Esperado', value: '2970g', color: 'text-blue-600' },
    { label: 'Consumo Total Real', value: '2969g', color: 'text-green-600' },
    { label: 'Variação', value: '-0.03%', color: 'text-gray-600' },
    { label: 'Eficiência', value: '99.97%', color: 'text-green-600' },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Consumo de Ração</h1>
        <p className="text-gray-600 mt-2">Acompanhe o consumo esperado vs real</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {stats.map((stat, idx) => (
          <Card key={idx}>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">{stat.label}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${stat.color}`}>{stat.value}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Consumo por Semana (Lote Postura 001)</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={consumptionData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="week" label={{ value: 'Semana', position: 'insideBottomRight', offset: -5 }} />
              <YAxis label={{ value: 'Consumo (g)', angle: -90, position: 'insideLeft' }} />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="expected" stroke="#3b82f6" name="Esperado" />
              <Line type="monotone" dataKey="actual" stroke="#10b981" name="Real" />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Detalhes por Semana</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-100 border-b">
                <tr>
                  <th className="text-left px-4 py-2">Semana</th>
                  <th className="text-left px-4 py-2">Esperado</th>
                  <th className="text-left px-4 py-2">Real</th>
                  <th className="text-left px-4 py-2">Variação</th>
                </tr>
              </thead>
              <tbody>
                {consumptionData.map((row) => {
                  const variation = row.actual - row.expected
                  return (
                    <tr key={row.week} className="border-b hover:bg-gray-50">
                      <td className="px-4 py-2 font-medium">Semana {row.week}</td>
                      <td className="px-4 py-2">{row.expected}g</td>
                      <td className="px-4 py-2">{row.actual}g</td>
                      <td className={`px-4 py-2 font-semibold ${variation >= 0 ? 'text-red-600' : 'text-green-600'}`}>
                        {variation >= 0 ? '+' : ''}{variation}g
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
