export const farmAnalysisTools = [
  {
    name: 'get_flock_data',
    description: 'Get data about active flocks including bird count, dates, and status',
    input_schema: {
      type: 'object',
      properties: {
        flock_id: {
          type: 'string',
          description: 'Optional specific flock ID to query',
        },
      },
      required: [],
    },
  },
  {
    name: 'get_mortality_analysis',
    description: 'Analyze mortality rates and trends for flocks',
    input_schema: {
      type: 'object',
      properties: {
        batch_id: {
          type: 'string',
          description: 'Optional batch ID to analyze',
        },
        days: {
          type: 'number',
          description: 'Number of days to analyze (default: 30)',
        },
      },
      required: [],
    },
  },
  {
    name: 'get_feed_analysis',
    description: 'Calculate feed consumption, FCR, and feed requirements',
    input_schema: {
      type: 'object',
      properties: {
        batch_id: {
          type: 'string',
          description: 'Batch ID for feed analysis',
        },
        days_ahead: {
          type: 'number',
          description: 'Days to forecast feed needs',
        },
      },
      required: [],
    },
  },
  {
    name: 'get_inventory_status',
    description: 'Check current inventory levels and identify low stock items',
    input_schema: {
      type: 'object',
      properties: {
        alert_low_stock: {
          type: 'boolean',
          description: 'Only return items with low stock',
        },
      },
      required: [],
    },
  },
  {
    name: 'get_health_status',
    description: 'Get vaccination and health records for flocks',
    input_schema: {
      type: 'object',
      properties: {
        batch_id: {
          type: 'string',
          description: 'Batch ID for health check',
        },
      },
      required: [],
    },
  },
  {
    name: 'get_financial_analysis',
    description: 'Analyze revenue, expenses, and profitability',
    input_schema: {
      type: 'object',
      properties: {
        batch_id: {
          type: 'string',
          description: 'Batch ID for financial analysis',
        },
        period: {
          type: 'string',
          enum: ['week', 'month', 'all'],
          description: 'Time period to analyze',
        },
      },
      required: [],
    },
  },
  {
    name: 'generate_report',
    description: 'Generate comprehensive farm reports',
    input_schema: {
      type: 'object',
      properties: {
        report_type: {
          type: 'string',
          enum: ['daily', 'weekly', 'monthly', 'production', 'financial'],
          description: 'Type of report to generate',
        },
        format: {
          type: 'string',
          enum: ['text', 'pdf', 'excel'],
          description: 'Output format',
        },
      },
      required: ['report_type'],
    },
  },
  {
    name: 'get_smart_alerts',
    description: 'Get AI-generated alerts for farm issues',
    input_schema: {
      type: 'object',
      properties: {
        severity: {
          type: 'string',
          enum: ['critical', 'high', 'medium', 'low'],
          description: 'Minimum alert severity',
        },
      },
      required: [],
    },
  },
]
