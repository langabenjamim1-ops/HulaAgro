import { createClient } from '@supabase/supabase-js'

function getSupabase() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL || '',
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ''
  )
}

export async function getFlockData() {
  try {
    const supabase = getSupabase()
    const { data, error } = await supabase
      .from('batches')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(10)

    if (error) throw error
    return data || []
  } catch (error) {
    console.error('Error fetching flock data:', error)
    return []
  }
}

export async function getMortalityData(batchId?: string) {
  try {
    const supabase = getSupabase()
    let query = supabase.from('daily_records').select('*')
    if (batchId) {
      query = query.eq('batch_id', batchId)
    }
    const { data, error } = await query.order('record_date', { ascending: false }).limit(30)

    if (error) throw error
    return data || []
  } catch (error) {
    console.error('Error fetching mortality data:', error)
    return []
  }
}

export async function getFeedConsumption(batchId?: string) {
  try {
    const supabase = getSupabase()
    let query = supabase.from('daily_records').select('*')
    if (batchId) {
      query = query.eq('batch_id', batchId)
    }
    const { data, error } = await query.order('record_date', { ascending: false }).limit(30)

    if (error) throw error
    return data || []
  } catch (error) {
    console.error('Error fetching feed consumption:', error)
    return []
  }
}

export async function getInventoryLevels() {
  try {
    const supabase = getSupabase()
    const { data, error } = await supabase
      .from('supplies')
      .select('*')
      .order('created_at', { ascending: false })

    if (error) throw error
    return data || []
  } catch (error) {
    console.error('Error fetching inventory:', error)
    return []
  }
}

export async function getVaccinationRecords(batchId?: string) {
  try {
    const supabase = getSupabase()
    let query = supabase.from('health_records').select('*')
    if (batchId) {
      query = query.eq('batch_id', batchId)
    }
    const { data, error } = await query.order('record_date', { ascending: false })

    if (error) throw error
    return data || []
  } catch (error) {
    console.error('Error fetching vaccination records:', error)
    return []
  }
}

export async function getFinancialSummary() {
  try {
    const supabase = getSupabase()
    const { data, error } = await supabase
      .from('cost_records')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(100)

    if (error) throw error
    return data || []
  } catch (error) {
    console.error('Error fetching financial data:', error)
    return []
  }
}

export async function generateFarmSummary() {
  try {
    const [flocks, mortality, feed, inventory, financial] = await Promise.all([
      getFlockData(),
      getMortalityData(),
      getFeedConsumption(),
      getInventoryLevels(),
      getFinancialSummary(),
    ])

    return {
      flocks: flocks.length,
      activeBirds: flocks.reduce((sum: number, f: any) => sum + (f.initial_quantity || 0), 0),
      recentMortality: mortality.slice(0, 7),
      feedStatus: feed.slice(0, 7),
      inventory,
      financial: financial.slice(0, 10),
    }
  } catch (error) {
    console.error('Error generating farm summary:', error)
    return null
  }
}
