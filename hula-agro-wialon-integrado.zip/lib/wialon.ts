import { WialonUnit } from '@/lib/wialon-types'

const DEFAULT_HOST = 'https://hst-api.wialon.com'

type WialonResponse<T> = T & { error?: number }

function getHost() {
  return (process.env.WIALON_API_HOST || DEFAULT_HOST).replace(/\/+$/, '')
}

async function wialonRequest<T>(
  service: string,
  params: Record<string, unknown>,
  sid?: string
): Promise<WialonResponse<T>> {
  const url = new URL(`${getHost()}/wialon/ajax.html`)
  url.searchParams.set('svc', service)
  url.searchParams.set('params', JSON.stringify(params))
  if (sid) url.searchParams.set('sid', sid)

  const response = await fetch(url.toString(), {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
    cache: 'no-store',
  })

  if (!response.ok) {
    throw new Error(`Wialon HTTP ${response.status}`)
  }

  const data = (await response.json()) as WialonResponse<T>
  if (typeof data === 'object' && data !== null && 'error' in data && data.error) {
    throw new Error(`Wialon API error ${data.error}`)
  }

  return data
}

export async function getWialonSession() {
  const token = process.env.WIALON_TOKEN?.trim()
  if (!token) {
    throw new Error('WIALON_TOKEN não configurado')
  }

  const data = await wialonRequest<{
    eid: string
    user?: { nm?: string; id?: number }
  }>('token/login', { token, fl: 256 + 512 })

  if (!data.eid) {
    throw new Error('Wialon não devolveu uma sessão válida')
  }

  return data
}

export async function getWialonUnits(): Promise<WialonUnit[]> {
  const session = await getWialonSession()

  // 1 = general, 1024 = last position/message,
  // 4096 = sensors, 2097152 = connection status.
  const flags = 1 + 1024 + 4096 + 2097152

  const result = await wialonRequest<{
    items: Array<Record<string, any>>
  }>(
    'core/search_items',
    {
      spec: {
        itemsType: 'avl_unit',
        propName: 'sys_name',
        propValueMask: '*',
        sortType: 'sys_name',
      },
      force: 1,
      flags,
      from: 0,
      to: 0,
    },
    session.eid
  )

  const items = result.items || []
  if (!items.length) return []

  // calc_last returns the latest calculated sensor values and key indicators
  // for all requested units in a single request.
  const calculated = await wialonRequest<Array<Record<string, any>>>(
    'unit/calc_last',
    { itemIds: items.map((item) => Number(item.id)) },
    session.eid
  )

  const calcByUnit = new Map<number, Record<string, any>>(
    (calculated || []).map((item) => [Number(item.i), item])
  )

  return items.map((item) => {
    const id = Number(item.id)
    const calc = calcByUnit.get(id)
    const sensorsConfig = item.sens || {}
    const sensorValues = calc?.sensors || {}

    const sensors = Object.values(sensorsConfig).map((sensor: any) => {
      const value = sensorValues[String(sensor.id)]
      return {
        id: Number(sensor.id),
        name: String(sensor.n || `Sensor ${sensor.id}`),
        type: String(sensor.t || ''),
        unit: String(sensor.m || ''),
        parameter: String(sensor.p || ''),
        value: value?.value ?? null,
        formattedValue: value?.format?.value ?? null,
      }
    })

    return {
      id,
      name: String(item.nm || `Unidade ${id}`),
      position: item.pos
        ? {
            latitude: Number(item.pos.y),
            longitude: Number(item.pos.x),
            altitude: Number(item.pos.z ?? 0),
            speed: Number(item.pos.s ?? 0),
            course: Number(item.pos.c ?? 0),
            satellites: Number(item.pos.sc ?? 0),
            timestamp: Number(item.pos.t ?? 0),
          }
        : null,
      connected: Boolean(item.lmsg?.rt),
      lastMessageTimestamp: Number(item.pos?.t ?? 0),
      mileage: calc?.mileage?.format?.value ?? null,
      engineHours: calc?.engine_hours?.format?.value ?? null,
      sensors,
    } satisfies WialonUnit
  })
}
